ccwgApp.controller('ServiceApiActionController', ['$scope', '$routeParams', '$uibModal', 'serviceRest', 'envService', 
    function($scope, $routeParams, $uibModal, serviceRest, envService) {

  console.log("Route params : " + $routeParams.serviceId);
  $scope.service  = {};
  $scope.service.serviceApiActionEntityList = [];

  $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

  // Pagination attributes
  $scope.currentPage = envService.read('currentPage');    
  $scope.itemsPerPage = envService.read('itemsPerPage');

  // Active button attirbutes
  $scope.activeButtonStatus = 'on';

  $scope.checkSaveRevertValidity = function() {
    // Looping through service api actions to find out if any has been updated, if so enable Revert and Save buttons.
    var enable = false;
    $scope.service.serviceApiActionEntityList.forEach(function(serviceApiAction) {
      if(serviceApiAction.action == 'U') {
        enable = true;
      };
    });

    return enable;
  };

  $scope.revert = function() {
    console.log("Reverting service api actions back to original copy from server.")
    $scope.retrieveService($routeParams.serviceId);    
  };

  $scope.update = function() {
    var services = new Array();
    services.push($scope.service);
    serviceRest.postServices(services)
      .then(
        function(response) {
          $scope.retrieveService($routeParams.serviceId);
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };  

  $scope.activeFilter = function (serviceApiAction) {
      switch($scope.activeButtonStatus) {
        case 'disable': 
          return serviceApiAction;
        case 'off':
          return serviceApiAction.isActive == false;
        case 'on':
          return serviceApiAction.isActive == true;
      }
  };

  $scope.dirtyRecordFilter = function(serviceApiAction) {
    switch($scope.showDirtyRecordsOnly) {
        case 'off':
          return serviceApiAction;
        case 'on':
          return serviceApiAction.action == 'U';
      }

  };


  $scope.isActiveToggle = function(i) {
    // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
    $scope.service.serviceApiActionEntityList.some(function(serviceApiAction) {
      if(serviceApiAction.id === i.id) {
        serviceApiAction.action = 'U';
      };
    });    
  };

  $scope.addServiceApiActionOpen = function() {
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'html/serviceApiActions/editServiceApiActionModal.html',
      controller: 'AddServiceApiActionModalController',
      resolve: {
        service: function() {
          return $scope.service;
        }
      }
    });
  };

  $scope.editServiceApiActionOpen = function(i) {
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'html/serviceApiActions/editServiceApiActionModal.html',
      controller: 'EditServiceApiActionModalController',
      resolve: {
        service: function() {return $scope.service;},
        serviceApiAction: function() {return i;}
      }
    });
  };

  $scope.retrieveService = function(id) { 
    serviceRest.getServiceById(id)
    .then(
      function(response) {
        $scope.service = response.data;
        console.log($scope.service);
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );
    };

  $scope.retrieveService($routeParams.serviceId);
}]);