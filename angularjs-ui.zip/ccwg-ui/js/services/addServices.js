ccwgApp.controller('AddServicesController', ['$scope', '$http', 'envService', 'lookupService', function($scope, $http, envService, lookupService) {

    $scope.newServices = [];
    $scope.serviceProviders = [];
    $scope.serviceStates = [];
    $scope.evaluationPriorities = [];
    
    $scope.serviceProvider = null;
    $scope.serviceState = null;
    $scope.evaluationPriority = null;

    $scope.addService = function() {
      $scope.newServices.push({
        "cloudServiceProvider": $scope.serviceProvider, 
        "serviceNameShort": $scope.serviceNameShort,
        "serviceNameLong": $scope.serviceNameLong,
        "serviceState": $scope.serviceState,
        "serviceDescription": $scope.serviceDescription,
        "refPrimaryFinra": $scope.refPrimaryFinra,
        "refAlternateFinra1": $scope.refAlternateFinra1,
        "refPrimaryVendor": $scope.refPrimaryVendor,
        "refAlternateVendor1": $scope.refAlternateVendor1,
        "refAlternateVendor2": $scope.refAlternateVendor2,
        "evaluationPriority": $scope.evaluationPriority
      });
      console.log("Adding Service with name : " + $scope.serviceNameShort);
      $scope.serviceProvider = null;
      $scope.serviceNameShort = null;
      $scope.serviceNameLong = null;
      $scope.serviceState = null;
      $scope.serviceDescription = null;
      $scope.refPrimaryFinra = null;
      $scope.refAlternateFinra1 = null;
      $scope.refPrimaryVendor = null;
      $scope.refAlternateVendor1 = null;
      $scope.refAlternateVendor2 = null;
      $scope.evaluationPriority = null;
      $scope.myForm.$setUntouched();
    }; 

    $scope.removeService = function(i) {
      console.log("Entering removeService function.");
      $scope.newServices = $scope.newServices.filter(function(service) {
        return service.serviceNameShort !== i.serviceNameShort;
      });
    };     
    
    $scope.checkValidity = function() {
      return ($scope.newServices != undefined && 
        $scope.newServices.length > 0);
    };

    /* REST Call functions */

    $scope.successPOSTCallback = function(response) {
      $scope.newServices = [];
    };

    $scope.errorPOSTCallback = function(response) {
      alert( "failure message: " + JSON.stringify({data: response.data}));
    };     


    $scope.createServices = function() {
      $http({
        method: 'POST',
        url: envService.read('serviceUrl'),
        headers: {
          'Content-Type': 'application/json'
        },
        data: $scope.newServices
      }).then($scope.successPOSTCallback, $scope.errorPOSTCallback);
	};

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.serviceProviders = response.cloudServiceProviders;
        $scope.serviceStates = response.serviceStates;
        $scope.evaluationPriorities = response.evaluationPriorities;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  


}]);