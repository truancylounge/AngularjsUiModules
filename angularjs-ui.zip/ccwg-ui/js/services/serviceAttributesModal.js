ccwgApp.controller('ServiceAttributesModalController', ['$scope', '$uibModalInstance', 'service', function($scope, $uibModalInstance, service) {
  console.log("Entering Service Attributes modal Controller");

  $scope.serviceNameLong = service.serviceNameLong;
  $scope.serviceDescription = service.serviceDescription;
  $scope.refPrimaryFinra = service.refPrimaryFinra;
  $scope.refAlternateFinra1 = service.refAlternateFinra1;
  $scope.refPrimaryVendor = service.refPrimaryVendor;
  $scope.refAlternateVendor1 = service.refAlternateVendor1;
  $scope.refAlternateVendor2 = service.refAlternateVendor2;


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);