ccwgApp.controller('EditServiceModalController', ['$scope', '$uibModalInstance', 'editService', 'services', 'lookupService', function($scope, $uibModalInstance, editService, services, lookupService) {
  console.log("Entering EditService modal Controller");

  console.log(editService);

  $scope.serviceProviders = [];
  $scope.serviceStates = [];
  $scope.evaluationPriorities = [];  

  $scope.serviceNameShort = editService.serviceNameShort;
  $scope.serviceNameLong = editService.serviceNameLong;
  $scope.serviceDescription = editService.serviceDescription;
  $scope.refPrimaryFinra = editService.refPrimaryFinra;
  $scope.refAlternateFinra1 = editService.refAlternateFinra1;
  $scope.refPrimaryVendor = editService.refPrimaryVendor;
  $scope.refAlternateVendor1 = editService.refAlternateVendor1;
  $scope.refAlternateVendor2 = editService.refAlternateVendor2;
  $scope.serviceProvider = editService.cloudServiceProvider;
  $scope.serviceState = editService.serviceState;
  $scope.evaluationPriority = editService.evaluationPriority;

  $scope.editService = function() {
    // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
    services.some(function(service) {
      if(service.id === editService.id) {
        service.serviceNameShort = $scope.serviceNameShort;
        service.serviceNameLong = $scope.serviceNameLong;
        service.serviceDescription = $scope.serviceDescription;
        service.refPrimaryFinra = $scope.refPrimaryFinra;
        service.refAlternateFinra1 = $scope.refAlternateFinra1;
        service.refPrimaryVendor = $scope.refPrimaryVendor;
        service.refAlternateVendor1 = $scope.refAlternateVendor1;
        service.refAlternateVendor2 = $scope.refAlternateVendor2;
        service.cloudServiceProvider = $scope.serviceProvider;
        service.serviceState = $scope.serviceState;
        service.evaluationPriority = $scope.evaluationPriority;        
        service.action = 'U';
      };
    });       

    $uibModalInstance.close();

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.serviceProviders = response.cloudServiceProviders;
        $scope.serviceStates = response.serviceStates;
        $scope.evaluationPriorities = response.evaluationPriorities;  
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  


    
}]);