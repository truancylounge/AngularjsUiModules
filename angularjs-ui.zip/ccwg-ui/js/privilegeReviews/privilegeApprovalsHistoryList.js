ccwgApp.controller('PrivilegeApprovalsHistoryListController', ['$scope', '$rootScope', 'privilegeReviewService', 'serviceRest', 'envService', '$uibModal', 
  function($scope, $rootScope, privilegeReviewService, serviceRest, envService, $uibModal) {

  	$scope.privilegeApprovalsHistory = [];
    $scope.serviceApiActionEntities = [];


    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');


    $scope.privilegeReviewApprovalLogOpen = function(i) {

      console.log("Entering Privilege Review Approval log Modal");
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/privilegeReviews/privilegeApprovalsHistoryLogModal.html',
        controller: 'PrivilegeApprovalHistoryLogModalController',
        resolve: {
          logEntities: function(){ return i.privilegeReviewLogEntities;}
        }
      });    	

    }


    $scope.addRoleName = function(privilegeApproval) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeApproval.privilegeEntity.ccwgRoleOrgId) { 
          privilegeApproval.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };  
    
     $scope.addServiceApiActionName = function(privilegeApproval) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeApproval.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeApproval.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeApproval.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeApproval.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
        }          
      });
    };


  /**
    Initialize method which does the following
      (1) Loads Finalized Privilege Review Approvals History
  */
  $scope.initialize = function() { 
    // Retrieve Finalized Privilege Review Approvals History
    privilegeReviewService.getPrivilegeApprovalsHistory()
      .then(
        function(response) {
          $scope.privilegeApprovalsHistory = response.data;
          $scope.privilegeApprovalsHistory.forEach(function(privilegeApproval) {
            $scope.addRoleName(privilegeApproval); // Add a new property called RoleName based on ccwgRoleOrgId
            $scope.addServiceApiActionName(privilegeApproval); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
          });

          console.log($scope.privilegeApprovals);   
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  // Once the service api actions are loaded, start the initialization process.
  serviceRest.getServiceApiActions()
    .then(
      function(response) {
        $scope.serviceApiActionEntities = response.data;  
        $scope.initialize();
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
  );  


}]);