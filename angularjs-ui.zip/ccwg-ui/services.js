ccwgApp.factory('httpInterceptor', ['$q', '$location', '$sessionStorage', function($q, $location, $sessionStorage) {
  var errorJson;
  return {
    'response': function (response) {
      console.log('Response Interceptor');
      return response;
    },
    'request': function (config) {
      console.log('Request Interceptor');
      //config.headers['sAMAccountName'] = "K25850";
      //console.log(config);
      return config;
    },
    'responseError': function(response) {
      //console.log("Error Response Interceptor");
      
      errorJson = response.data;
      $location.path('/error');
        
      return response;
    },
    'getErrorJson': function() {
      return errorJson;
    }
  }
}]);

ccwgApp.service('lookupService', ['$http', '$q', 'envService', function($http, $q, envService) {
	var lookupService = {};

  lookupService.retrieveReferences = function() {

    var promise = $http({method: 'GET', url: envService.read('lookupUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        var references = {};
        references.cloudServiceProviders = [];
        references.serviceStates = [];
        references.evaluationPriorities = [];
        references.categoryTypes = [];
        references.evaluationTypes = [];
        references.targetTypes = [];
        references.environments = [];
        references.serviceEvaluationStatuses = [];
        references.apiGsRiskRankings = [];
        references.privilegesSettingValues = [];
        references.userRoles = [];
        references.privReviewResponses = [];

        response.data.forEach(function(reference) {
          switch(reference.refType) {
            case 'CloudServiceProvider': 
              references.cloudServiceProviders.push(reference.value);
              break;
            case 'serviceState':
              references.serviceStates.push(reference.value);
              break;
            case 'evaluationPriority':
              references.evaluationPriorities.push(reference.value);
              break;
            case 'categoryType':
              references.categoryTypes.push(reference.value);
              break;
            case 'evaluationType':
              references.evaluationTypes.push(reference.value);
              break;
            case 'targetType':
              references.targetTypes.push(reference.value);
              break;
            case 'environment':
              references.environments.push(reference.value);
              break;
            case 'serviceEvaluationStatus':
              references.serviceEvaluationStatuses.push(reference.value);
              break;
            case 'apiGsRiskRanking':
              references.apiGsRiskRankings.push(reference.value);
              break;
            case 'privilegesSettingValue':
              references.privilegesSettingValues.push(reference.value);
              break;
            case 'userRole':
              references.userRoles.push(reference.value);
              break;
            case 'privReviewResponse':
              references.privReviewResponses.push(reference.value);
              break;
              
          }
        });


        console.log("Cloud Service Providers retrieved: " + references.cloudServiceProviders);
        console.log("Service States retrieved: " + references.serviceStates);
        console.log("Evaluation Priorities retrieved: " + references.evaluationPriorities);

        console.log("Category Types retrieved: " + references.categoryTypes);
        console.log("Evaluation Types retrieved: " + references.evaluationTypes);
        console.log("Target Types retrieved: " + references.targetTypes);
        console.log("Environments retrieved: " + references.environments);
        console.log("Service Evaluation Statuses retrieved: " + references.serviceEvaluationStatuses);
        console.log("API GS Risk Rankings retrieved: " + references.apiGsRiskRankings);

        console.log("Privileges Setting values retrieved: " + references.privilegesSettingValues);
        console.log("User roles retrieved: " + references.userRoles);

        console.log("Privileges Review Responses retrieved: " + references.privReviewResponses);

        deferObject.resolve(references);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;    

  };

  return lookupService;

}]);

ccwgApp.service('roleService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var roleService = {}
  roleService.getRoles = function() {

    var promise = $http({method: 'GET', url: envService.read('roleUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  roleService.postRoles = function(rolesJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('roleUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: rolesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };
  return roleService;

}]);

ccwgApp.service('serviceRest', ['$http', '$q', 'envService', function($http, $q, envService) {

  var serviceRest = {}
  serviceRest.getServices = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  serviceRest.getServiceApiActions = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceApiActionUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  


  serviceRest.getAllActiveServiceNames = function() {

    var serviceNamesUrl = envService.read('serviceUrl') + "/names";

    var promise = $http({method: 'GET', url: serviceNamesUrl });
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  serviceRest.getServiceById = function(id) {

    var promise = $http({method: 'GET', url: envService.read('serviceUrl') + "/" + id});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  serviceRest.postServices = function(servicesJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('serviceUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: servicesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  return serviceRest;

}]);

ccwgApp.service('privilegeService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var privilegeService = {};

  privilegeService.getPrivilegesCount = function(roleIds, serviceIds, environments) {

    var rolesQueryString = "";
    var servicesQueryString = "";
    var envQueryString = "";

    roleIds.forEach(function(roleId) {
      rolesQueryString = rolesQueryString + "roles=" + roleId + "&";
    });
    // Remove the last &
    rolesQueryString = rolesQueryString.slice(0, -1);

    serviceIds.forEach(function(serviceId) {
      servicesQueryString = servicesQueryString + "services=" + serviceId + "&";
    });

    environments.forEach(function(env) {
      envQueryString = envQueryString + "envs=" + env + "&";
    });
    // Remove the last &
    //servicesQueryString = servicesQueryString.slice(0, -1);

    var queryString = "?";
    if(rolesQueryString !== "")
      queryString = queryString + rolesQueryString + "&";

    if(servicesQueryString !== "")
      queryString = queryString + servicesQueryString + "&";

    if(envQueryString !== "")
      queryString = queryString + envQueryString;

    var filterUrl = envService.read('privilegeCountUrl') + queryString;
    console.log("Filter Count Url: " + filterUrl );

    var promise = $http({method: 'GET', url: filterUrl });
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;    

  };

  privilegeService.getPrivilegesUsingFilter = function(roleIds, serviceIds, environments) {
    var rolesQueryString = "";
    var servicesQueryString = "";
    var envQueryString = "";

    roleIds.forEach(function(roleId) {
      rolesQueryString = rolesQueryString + "roles=" + roleId + "&";
    });
    // Remove the last &
    rolesQueryString = rolesQueryString.slice(0, -1);

    serviceIds.forEach(function(serviceId) {
      servicesQueryString = servicesQueryString + "services=" + serviceId + "&";
    });

    environments.forEach(function(env) {
      envQueryString = envQueryString + "envs=" + env + "&";
    });
    // Remove the last &
    //servicesQueryString = servicesQueryString.slice(0, -1);

    var queryString = "?";
    if(rolesQueryString !== "")
      queryString = queryString + rolesQueryString + "&";

    if(servicesQueryString !== "")
      queryString = queryString + servicesQueryString + "&";

    if(envQueryString !== "")
      queryString = queryString + envQueryString;

    var filterUrl = envService.read('privilegeUrl') + queryString;
    console.log("Filter Url: " + filterUrl );

    var promise = $http({method: 'GET', url: filterUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
    
  };

  privilegeService.getPrivileges = function(pageNumber, pageSize) {
    var paginatedUrl = envService.read('privilegeUrl') + "?pageNumber=" + pageNumber + "&pageSize=" + pageSize;

    var promise = $http({method: 'GET', url: paginatedUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeService.postPrivileges = function(privilegesJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  return privilegeService;

}]);


ccwgApp.service('userService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var userService = {};


  userService.getUsers = function() {
  
    var promise = $http({method: 'GET', url: envService.read('userUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.getApprovers = function() {
  
    var promise = $http({method: 'GET', url: envService.read('userUrl') +  "/approvers"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  userService.postUsers = function(usersJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('userUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: usersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  userService.getUserFilters = function(userId) {

    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";
  
    var promise = $http({method: 'GET', url: userFilterUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.postUserFilters = function(userFiltersJson, userId) {
    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";

    var promise = $http({ 
                          method: 'POST', 
                          url: userFilterUrl,
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: userFiltersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.deleteUserFilters = function(userFiltersJson, userId) {
    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";

    console.log(userFiltersJson);

    var promise = $http({ 
                          method: 'DELETE', 
                          url: userFilterUrl,
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: userFiltersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  return userService;

}]);



ccwgApp.service('privilegeReviewService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var privilegeReviewService = {};

  // Retrieves a list of unapproved privilege reviews for the specific user
  privilegeReviewService.getPrivilegeReviews = function() {
  
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };



    // Retrieves a list of historically approved/denied privilege reviews for the specific user
  privilegeReviewService.getHistoricPrivilegeReviews = function() {
  
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/history"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of all privilege approvals
  privilegeReviewService.getPrivilegeApprovals = function() {
  
    var promise = $http({method: 'GET', url: envService.read('privilegeApprovalUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  // Retrieves a list of history of all privilege approvals i.e privilege review approvals which have been finalized
  privilegeReviewService.getPrivilegeApprovalsHistory = function() {
  
    var promise = $http({method: 'GET', url: envService.read('privilegeApprovalUrl') + "/history"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  privilegeReviewService.postPrivilegeReviews = function(privilegeReviewsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeReviewUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegeReviewsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeReviewService.postPrivilegeApprovals = function(privilegeApprovalsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeApprovalUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegeApprovalsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  



  
  return privilegeReviewService;

}]);