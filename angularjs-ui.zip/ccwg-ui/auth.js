angular.module('Auth', ['ngResource', 'ngStorage', 'environment'])
.factory('authService', ['$http', '$q', 'envService', '$rootScope', '$sessionStorage', '$location', '$route',
          function($http, $q, envService, $rootScope, $sessionStorage, $location, $route) {

  var authService = {};

  /**
   *  Saves the current user in the root scope
   *  Call this in the app run() method
   */
  authService.init = function(){

      $http({
        method: 'GET',
        url: envService.read('healthCheckUrl')
      }).then(
          function(response){
            $sessionStorage.user = {};
            $sessionStorage.user.name = response.headers('X-CCWG-USER');
            $sessionStorage.user.permissions = $.map(response.headers('X-CCWG-ROLES').slice(1, -1).split(","), $.trim); // Remove first and last character and split ','
            $sessionStorage.user.currentPermission = 'ReadOnly'
            //console.log("User: " + $sessionStorage.user.name);
            //console.log("Permissions: " + $sessionStorage.user.permissions );

            // '$route' object has the current view of template, during refresh we need to perfomr Authorization.
            // After the first check '$routeChangeStart' event handles all authorization going forward.
            if (!authService.checkPermissionForView($route.current)){
                  event.preventDefault();
                  $location.path("/privError");
            }
            
            $rootScope.$on('$routeChangeStart', function (event, next) {
              if (!authService.checkPermissionForView(next)){
                  event.preventDefault();
                  $location.path("/privError");
              }
            });
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );
  };

  authService.isLoggedIn = function() {
    return $sessionStorage.user != null;
  };

  authService.currentUser = function(){
    return $sessionStorage.user;
  };

  authService.checkPermissionForView = function(view) {
      if (!view.requiresAuthentication) {
          return true;
      }
       
      return userHasPermissionForView(view);
  };

  var userHasPermissionForView = function(view){
      if(!authService.isLoggedIn()){
          return false;
      }
       
      if(!view.permissions || !view.permissions.length){
          return true;
      }
       
      return authService.userHasPermission(view.permissions);
  };

  authService.userHasPermission = function(permissions){
      if(!authService.isLoggedIn()){
          return false;
      }

      if(!$sessionStorage.user.permissions || !$sessionStorage.user.permissions.length) {
        return false;
      }       

      var found = false;
      angular.forEach(permissions, function(permission, index){
          if ($sessionStorage.user.currentPermission == permission){
              found = true;
              return;
          }                        
      });
       
      return found;
  };

  return authService;


}]);