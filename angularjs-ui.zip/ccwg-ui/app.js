// MODULE
var ccwgApp = angular.module('ccwgApp', ['ngRoute', 'ngResource', 'ngStorage', 'environment', 'ngAnimate', 'ui.bootstrap', 'angularjs-dropdown-multiselect', 'Auth']);

ccwgApp.controller('homeController', ['$scope', '$sessionStorage', function($scope, $sessionStorage) {
	$scope.name = 'CCWG Application Home'; 


	$scope.$watch(function() {return $sessionStorage.user}, function() {
		if($sessionStorage.user) {
			$scope.userRoles = $sessionStorage.user.permissions;
			$scope.userRole = $sessionStorage.user.currentPermission;
			$scope.userName = $sessionStorage.user.name;
		};
	} );


	$scope.updateUserRole = function() {
		console.log('Permission Changed');
		$sessionStorage.user.currentPermission = $scope.userRole;
	}

}]);