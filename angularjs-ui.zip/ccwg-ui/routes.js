// ROUTES
ccwgApp.config(function ($routeProvider) {
	$routeProvider

	.when('/', {
		templateUrl: 'html/home.html',
		controller: 'homeController'
	})

	.when('/roleList', {
		templateUrl: 'html/roles/roleList.html',
		controller: 'RoleListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/addRoles', {
		templateUrl: 'html/roles/addRoles.html',
		controller: 'AddRolesController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})

	.when('/serviceList', {
		templateUrl: 'html/services/serviceList.html',
		controller: 'ServiceListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/addServices', {
		templateUrl: 'html/services/addServices.html',
		controller: 'AddServicesController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/serviceEvaluations/:serviceId', {
		templateUrl: 'html/serviceEvaluations/serviceEvaluation.html',
		controller: 'ServiceEvaluationController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/serviceApiActions/:serviceId', {
		templateUrl: 'html/serviceApiActions/serviceApiAction.html',
		controller: 'ServiceApiActionController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})	

	.when('/privilegeList', {
		templateUrl: 'html/privileges/privilegesList.html',
		controller: 'PrivilegeListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})	

	.when('/privilegeReviewList', {
		templateUrl: 'html/privilegeReviews/privilegeReviewsList.html',
		controller: 'PrivilegeReviewsListController',
		requiresAuthentication: true,
        permissions: ["Approver"]
	})	

	.when('/privilegeApprovalList', {
		templateUrl: 'html/privilegeReviews/privilegeApprovalsList.html',
		controller: 'PrivilegeApprovalsListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})

	.when('/privilegeApprovalListHistory', {
		templateUrl: 'html/privilegeReviews/privilegeApprovalsHistoryList.html',
		controller: 'PrivilegeApprovalsHistoryListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})		

	.when('/admin', {
		templateUrl: 'html/admin/userList.html',
		controller: 'UserListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/privError', {
		templateUrl: 'html/error/privError.html'
	})	

	.when('/error', {
		templateUrl: 'html/error/error.html',
		controller: 'GenericErrorController',
		resolve: {
			errorJson: function(httpInterceptor) {
				console.log(httpInterceptor.getErrorJson());
				return httpInterceptor.getErrorJson();
			}
		}
	})	

});

ccwgApp.config(['$httpProvider', function($httpProvider) {
	//$httpProvider.defaults.useXDomain = true;
    //delete $httpProvider.defaults.headers.common['X-Requested-With'];
	$httpProvider.interceptors.push('httpInterceptor');

}]);

ccwgApp.config(function(envServiceProvider) {
	// set the domains and variables for each environment
	envServiceProvider.config({
		domains: {
			local: ['local'],
			development: ['dev'],
			production: ['prod']

		},
		vars: {
			local: {
				lookupUrl: 'http://localhost:9000/ccwg/lookups',
				roleUrl: 'http://localhost:9000/ccwg/roles',
				serviceUrl: 'http://localhost:9000/ccwg/services',
				serviceApiActionUrl: 'http://localhost:9000/ccwg/serviceApiActions',
				privilegeUrl: 'http://localhost:9000/ccwg/privileges',
				privilegeCountUrl: 'http://localhost:9000/ccwg/privileges/count',
				userUrl: 'http://localhost:9000/ccwg/users',
				healthCheckUrl: 'http://localhost:9000/ccwg/health',
				privilegeReviewUrl: 'http://localhost:9000/ccwg/privilegeReviews',
				privilegeApprovalUrl: 'http://localhost:9000/ccwg/privilegeReviews/approvals',
				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10


			},
			development: {
				lookupUrl: 'http://appsec.dev.finra.org/ccwg-1.0/lookups',
				roleUrl: 'http://appsec.dev.finra.org/ccwg-1.0/roles',
				serviceUrl: 'http://appsec.dev.finra.org/ccwg-1.0/services',
				serviceApiActionUrl: 'http://appsec.dev.finra.org/ccwg-1.0/serviceApiActions',
				privilegeUrl: 'http://appsec.dev.finra.org/ccwg-1.0/privileges',
				privilegeCountUrl: 'http://appsec.dev.finra.org/ccwg-1.0/privileges/count',
				userUrl: 'http://appsec.dev.finra.org/ccwg-1.0/users',
				healthCheckUrl: 'http://appsec.dev.finra.org/ccwg-1.0/health',
				privilegeReviewUrl: 'http://appsec.dev.finra.org/ccwg-1.0/privilegeReviews',
				privilegeApprovalUrl: 'http://appsec.dev.finra.org/ccwg-1.0/privilegeReviews/approvals',
				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10

			},
			productions: {
				roleUrl: 'http://produrl:9000/ccwg/roles',
				serviceUrl: 'http://produrl:9000/ccwg/services',
				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10

			}

		}
	});

	envServiceProvider.check();
});

ccwgApp.run(['$rootScope', '$location', 'authService', 'roleService', 'serviceRest', '$window', function ($rootScope, $location, authService, roleService, serviceRest, $window) {
	authService.init();


    // Retrieve role entities which can be used later to create privileges 
    roleService.getRoles()
      .then(
        function(response) {
          $rootScope.roleEntities = response.data;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
}]);