ccwgApp.controller('EditRoleModalController', ['$scope', '$uibModalInstance', 'editRole', 'roles', function($scope, $uibModalInstance, editRole, roles) {
  //editRole = this;
  console.log("Entering EditRole modal Controller");

  $scope.roleName = editRole.roleName;
  $scope.roleDescription = editRole.roleDescription;

  $scope.editRole = function() {
    // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
    roles.some(function(role) {
      if(role.id === editRole.id) {
        role.roleName = $scope.roleName;
        role.roleDescription = $scope.roleDescription;
        role.action = 'U';
      };
    });       

    $uibModalInstance.close();

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);