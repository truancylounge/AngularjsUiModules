ccwgApp.controller('AddRolesController', ['$scope', '$http', 'envService', function($scope, $http, envService) {

	$scope.newRoles = [];

    $scope.addRole = function() {
      $scope.newRoles.push({"roleName": $scope.roleName, "roleDescription": $scope.roleDescription});
      console.log("Adding Role with name : " + $scope.roleName);
      $scope.roleName = null;
      $scope.roleDescription = null;
      $scope.myForm.$setUntouched();
    }; 

    $scope.removeRole = function(i) {
      console.log("Entering removeRole function.");
      $scope.newRoles = $scope.newRoles.filter(function(role) {
        return role.roleName !== i.roleName;
      });
    };     
    
    $scope.checkValidity = function() {
      return ($scope.newRoles != undefined && 
        $scope.newRoles.length > 0);
    };

    /* REST Call functions */

    $scope.successPOSTCallback = function(response) {
      $scope.newRoles = [];
    };

    $scope.errorPOSTCallback = function(response) {
      alert( "failure message: " + JSON.stringify({data: response.data}));
    };     


    $scope.createRoles = function() {
      $http({
        method: 'POST',
        url: envService.read('roleUrl'),
        headers: {
          'Content-Type': 'application/json'
        },
        data: $scope.newRoles
      }).then($scope.successPOSTCallback, $scope.errorPOSTCallback);
	   };    
}]);