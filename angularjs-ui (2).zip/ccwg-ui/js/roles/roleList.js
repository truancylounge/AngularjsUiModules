ccwgApp.controller('RoleListController', ['$scope', '$http', '$uibModal', 'envService', 'roleService', 
        function($scope, $http, $uibModal, envService, roleService) {

    // Debug Environment variables 
    //$scope.environment = envService.get();
    //console.log('Current env: ' + $scope.environment);
    //$scope.vars = envService.read('all');
    //console.log($scope.vars);
    $scope.roles = [];
    $scope.sortType = 'roleName'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');    
    $scope.itemsPerPage = envService.read('itemsPerPage');

    // Active button attirbutes
    $scope.activeButtonStatus = 'on';

    $scope.activeClicked = function() {
      console.log("Active Button Status : " + $scope.activeButtonStatus);
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through roles to find out if roles has been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.roles != 'undefined' && $scope.roles instanceof Array) {
        $scope.roles.filter(Boolean).forEach(function(role) {
          if(role.action == 'U') {
            enable = true;
          };
        });
      };
      return enable;
    };

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.roles.some(function(role) {
        if(role.id === i.id) {
          role.action = 'U';
        };
      });    
    };

    $scope.activeFilter = function (role) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return role;
          case 'off':
            return role.isActive == false;
          case 'on':
            return role.isActive == true;
        }
    };

    $scope.dirtyRecordFilter = function(role) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return role;
          case 'on':
            return role.action == 'U';
        }

    };

    $scope.revertRoles = function() {
      console.log("Reverting roles back to original copy from server.")
      $scope.retrieveAllRoles();
    };


    $scope.editRoleOpen = function(i) {
      var modalInstance = $uibModal.open({
        templateUrl: 'html/roles/editRoleModal.html',
        controller: 'EditRoleModalController',
        resolve: {
          editRole: function(){ return i;},
          roles: function() { return $scope.roles;}
        }
      });
    };

    $scope.retrieveAllRoles = function() {
      roleService.getRoles()
        .then(
          function(response) {
            $scope.roles = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };        

    $scope.updateRoles = function() {

      roleService.postRoles($scope.roles)
              .then(
                function(response) {
                  $scope.retrieveAllRoles();
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
              );
     }; 

    $scope.retrieveAllRoles();



/* Watch example
    $scope.$watch('searchKeyword', function(newValue, oldValue) {
      console.log('Changed ');
      console.log('Old: ' + oldValue);
      console.log('New: ' + newValue);
    });
*/

//$('.bs-switch').bootstrapSwitch();   
    
}]);