ccwgApp.controller('EditUserModalController', ['$scope', '$uibModalInstance', 'lookupService', 'editUser', 'users',  function($scope, $uibModalInstance, lookupService, editUser, users) {

  $scope.userRoles = [];

  $scope.userId = editUser.userId;
  $scope.userRole = editUser.userRole;

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addUser = function() {
    users.some(function(user) {
      if(user.id == editUser.id) {
        user.userRole = $scope.userRole;
        user.action = 'U';
      };
    });

    $uibModalInstance.close();
  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.userRoles = response.userRoles;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  
    
}]);

ccwgApp.controller('AddUserModalController', ['$scope', '$uibModalInstance', 'lookupService', 'users',  function($scope, $uibModalInstance, lookupService, users) {

  $scope.userRoles = [];

  $scope.userId;
  $scope.userRole;

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addUser = function() {
    users.push({
      "userId": $scope.userId,
      "userRole": $scope.userRole,
      "action": 'U',
      "isActive": true
    });

    $uibModalInstance.close();
  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.userRoles = response.userRoles;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  

    
}]);