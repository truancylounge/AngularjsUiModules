ccwgApp.controller('UserListController', ['$scope', '$http', '$uibModal', 'envService', 'userService', 
        function($scope, $http, $uibModal, envService, userService) {


    $scope.users = [];
    $scope.sortType = 'userId'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');    
    $scope.itemsPerPage = envService.read('itemsPerPage');

    // Active button attirbutes
    $scope.activeButtonStatus = 'on';

    // Alert after Users have been saved
    $scope.showSuccessAlert = false;
    $scope.savedUsers = 0;
    $scope.alertTimeout = envService.read('alertTimeout');
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedUsers = 0;
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through users to find out if user has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.users.forEach(function(user) {
        if(user.action == 'U') {
          enable = true;
        };
      });

      return enable;
    }; 

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.users.some(function(user) {
        if(user.id === i.id) {
          user.action = 'U';
        };
      });    
    };    

    $scope.activeFilter = function (user) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return user;
          case 'off':
            return user.isActive == false;
          case 'on':
            return user.isActive == true;
        }
    }; 

    $scope.dirtyRecordFilter = function(user) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return user;
          case 'on':
            return user.action == 'U';
        }

    };

    $scope.editUserOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/admin/editUserModal.html',
        controller: 'EditUserModalController',
        resolve: {
          editUser: function(){ return i;},
          users: function() { return $scope.users;}
        }
      });
    };    

    $scope.addUserOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/admin/addUserModal.html',
        controller: 'AddUserModalController',
        resolve: {
          users: function() { return $scope.users;}
        }
      });
    };    

    $scope.revertUsers= function() {
      console.log("Reverting users back to original copy from server.")
      $scope.retrieveAllUsers();
    };

    $scope.retrieveAllUsers = function() {
      userService.getUsers()
        .then(
          function(response) {
            $scope.users = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };        

    $scope.updateUsers = function() {

      userService.postUsers($scope.users)
              .then(
                function(response) {
                  $scope.retrieveAllUsers();
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
              );
     }; 

    $scope.retrieveAllUsers();
 
    
}]);