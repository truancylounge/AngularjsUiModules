ccwgApp.controller('GenericErrorController', ['$scope', 'errorJson', function($scope, errorJson) {
  console.log("Entering Generic Error Controller");
  $scope.errorObject = errorJson;    
}]);