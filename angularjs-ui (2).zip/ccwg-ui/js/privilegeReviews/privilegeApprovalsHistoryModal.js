ccwgApp.controller('PrivilegeApprovalHistoryLogModalController', ['$scope', '$uibModalInstance', 'logEntities', function($scope, $uibModalInstance, logEntities) {
  console.log("Entering Privilege Approval Hisotry Log modal Controller");

  $scope.logEntities = logEntities;


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);