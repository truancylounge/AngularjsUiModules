ccwgApp.controller('PrivilegeReviewsListController', ['$scope', '$rootScope', 'privilegeReviewService', 'roleService', 'serviceRest', 'lookupService', 'envService', 
  function($scope, $rootScope, privilegeReviewService, roleService, serviceRest, lookupService, envService) {

    $scope.privilegeReviews = [];
    $scope.historicPrivilegeReviews = [];
    $scope.serviceApiActionEntities = [];

    $scope.responseTypes = [];
    $scope.enableActionChanges = false;

    // Alert after Priv Reviews have been saved
    $scope.showSuccessAlert = false;
    $scope.savedPrivReviewsCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedPrivReviewsCount = 0;
    };

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.activeButtonStatus = 'uncheck';

    $scope.activeClicked = function(activeButtonStatus, filteredPrivilegeReviews) {
      $scope.activeButtonStatus = activeButtonStatus;
      console.log($scope.activeButtonStatus);

        switch($scope.activeButtonStatus) {          
          case 'uncheck': 
            $scope.reviewComments = null;
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              privilegeReview.responseType = "";
              privilegeReview.reviewComment = null;
              privilegeReview.action = "I";
            });
            break;

          case 'approveAll':
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              privilegeReview.responseType = "Approved";
              privilegeReview.action = "U";
            });
            break;

          case 'rejectAll':
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              privilegeReview.responseType = "Reject";
              privilegeReview.action = "U";
            });
            break;
        }      

    };

    $scope.addingBulkComments = function(filteredPrivilegeReviews, reviewComments) {
      filteredPrivilegeReviews.forEach(function(privReview) {
        privReview.reviewComment = reviewComments;
      });
    };        

    $scope.enableEdits = function() {
      $scope.enableActionChanges = !$scope.enableActionChanges;      
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through privilegeReviews to find out if any have been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.privilegeReviews != 'undefined' && $scope.privilegeReviews instanceof Array) {
        $scope.privilegeReviews.filter(Boolean).forEach(function(privReview) {
          if(privReview.action == 'U') {
            enable = true;
          };
        });
      };
      return enable;
    }; 

    $scope.revertPrivReviews = function() {
      $scope.initialize();
    };

    $scope.savePrivReviews = function() {
      privilegeReviewService.postPrivilegeReviews($scope.privilegeReviews)
        .then(
          function(response) {
            console.log($scope.privilegeReviews);

            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.privilegeReviews.forEach(function(priv) {
              if(priv.action === 'U') 
                $scope.savedPrivReviewsCount++;
            });
            
            $scope.initialize();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );      
    };

    $scope.editResponseType = function(i) {
      i.action = "U";
    };

    $scope.addRoleName = function(privilegeReview) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeReview.privilegeEntity.ccwgRoleOrgId) { 
          privilegeReview.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };

    $scope.addServiceApiActionName = function(privilegeReview) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeReview.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeReview.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeReview.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeReview.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
        }          
      });
    };


  /**
    Initialize method which does the following
      (1) Loads UnApproved Privilege Reviews for specific user
      (2) Loads historic privilege reviews for specific user

  */
  $scope.initialize = function() {

    $scope.enableActionChanges = false;
    $scope.activeButtonStatus = 'uncheck';

    $scope.reviewComments = null;

    // Retrieve UnApproved Privilege Reviews for specific user 
    privilegeReviewService.getPrivilegeReviews()
      .then(
        function(response) {
          $scope.privilegeReviews = response.data;
          $scope.privilegeReviews.forEach(function(privilegeReview) {
            $scope.addRoleName(privilegeReview); // Add a new property called RoleName based on ccwgRoleOrgId
            $scope.addServiceApiActionName(privilegeReview); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
          });
    
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Retrieve historic privilege reviews for specific user
    privilegeReviewService.getHistoricPrivilegeReviews()
      .then(
        function(response) {
          $scope.historicPrivilegeReviews = response.data;
          $scope.historicPrivilegeReviews.forEach(function(historicPrivilegeReview) {
            $scope.addRoleName(historicPrivilegeReview); // Add a new property called RoleName based on ccwgRoleOrgId
            $scope.addServiceApiActionName(historicPrivilegeReview); // Add serviceApiActionName, serviceApiPrefix, serviceShortName
          });
          
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Adding envs creation here coz lookup service takes some time to load envs.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.responseTypes = response.privReviewResponses;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  // Once the service api actions are loaded, start the initialization process.
  serviceRest.getServiceApiActions()
    .then(
      function(response) {
        $scope.serviceApiActionEntities = response.data;  
        $scope.initialize();
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  
}]);