ccwgApp.controller('PrivilegeApprovalsListController', ['$scope', '$rootScope', 'privilegeReviewService', 'serviceRest', 'lookupService', 'userService', 'envService', 
  function($scope, $rootScope, privilegeReviewService, serviceRest, lookupService, userService, envService) {

    $scope.privilegeApprovals = [];
    $scope.serviceApiActionEntities = [];

    $scope.responseTypes = [];
    $scope.approvers = [];

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    $scope.enableActionChanges = false;

    // Alert after Priv Approvals have been saved
    $scope.showSuccessAlert = false;
    $scope.savedPrivApprovalCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedPrivApprovalCount = 0;
    };

    // Active button attirbutes
    $scope.activeButtonStatus = 'uncheck';

    $scope.activeClicked = function(filteredPrivilegeApprovals) {
      console.log($scope.activeButtonStatus);
        switch($scope.activeButtonStatus) {          
          case 'uncheck': 
            $scope.approvalComments = null;
            
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "";
              privilegeApproval.reviewComment = null;
              privilegeApproval.action = "I";              
            });
            
            break;

          case 'approveAll':
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "Approved";
              privilegeApproval.action = "U";
            });
            break;

          case 'rejectAll':
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "Reject";
              privilegeApproval.action = "U";
            });
            break;
        }      

    };

    $scope.addingBulkComments = function(filteredPrivilegeApprovals, approvalComments) {
      filteredPrivilegeApprovals.forEach(function(privApproval) {
        privApproval.reviewComment = approvalComments;
      });
    };    

    $scope.revertPrivApprovals = function() {
      $scope.initialize();
    };

    $scope.savePrivApprovals = function() {      
      var updatedPrivApprovals = [];
      $scope.privilegeApprovals.forEach(function(privApproval) {
        if(privApproval.action === "U") { updatedPrivApprovals.push(privApproval); }
      });

      $scope.savedPrivApprovalCount = updatedPrivApprovals.length;
      privilegeReviewService.postPrivilegeApprovals(updatedPrivApprovals)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.initialize();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );      
    };


    $scope.enableEdits = function() {
      $scope.enableActionChanges = !$scope.enableActionChanges;      
    };


    $scope.checkSaveRevertValidity = function() {
      // Looping through privilegeApprovals to find out if any have been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.privilegeApprovals !== 'undefined' && $scope.privilegeApprovals instanceof Array) {
        $scope.privilegeApprovals.filter(Boolean).forEach(function(privApproval) {
          if(privApproval.action == 'U') {
            enable = true;
          };
        });
      };
      return enable;
    }; 

    $scope.editResponseType = function(i) {
      console.log("Edit response type");
      i.action = "U";
    };


   
    $scope.addRoleName = function(privilegeApproval) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeApproval.privilegeEntity.ccwgRoleOrgId) { 
          privilegeApproval.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };

    $scope.addServiceApiActionName = function(privilegeApproval) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeApproval.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeApproval.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeApproval.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeApproval.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
        }          
      });
    };

    $scope.transposeApprovedUserActions = function(privilegeApproval) {
      privilegeApproval.privilegeReviewLogEntities.forEach(function(logEntry) {
        
        privilegeApproval[logEntry.reviewedBy] = {
          "responseType": logEntry.responseType,
          "reviewComment": logEntry.reviewComment
        };
      });
    }


  /**
    Initialize method which does the following
      (1) Loads Privilege Approvals
      (2) Loads Privilege Review Responses
      (3) Loads all users who are approvers

  */
  $scope.initialize = function() {

    $scope.enableActionChanges = false;
    $scope.activeButtonStatus = 'uncheck';
    $scope.approvalComments = null;

 
    // Retrieve All Privilege Approvals 
    privilegeReviewService.getPrivilegeApprovals()
      .then(
        function(response) {
          $scope.privilegeApprovals = response.data;
          $scope.privilegeApprovals.forEach(function(privilegeApproval) {
            $scope.addRoleName(privilegeApproval); // Add a new property called RoleName based on ccwgRoleOrgId
            $scope.addServiceApiActionName(privilegeApproval); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
            $scope.transposeApprovedUserActions(privilegeApproval);
          });

          console.log($scope.privilegeApprovals);   
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Retrieve privilege review responses.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.responseTypes = response.privReviewResponses;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    userService.getApprovers()
      .then(
        function(response) {
          $scope.approvers = response.data;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
        


  };

  // Once the service api actions are loaded, start the initialization process.
  serviceRest.getServiceApiActions()
    .then(
      function(response) {
        $scope.serviceApiActionEntities = response.data;  
        $scope.initialize();
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );  
}]);