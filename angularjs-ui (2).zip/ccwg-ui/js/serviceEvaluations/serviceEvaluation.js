ccwgApp.controller('ServiceEvaluationController', ['$scope', '$routeParams', '$uibModal', 'serviceRest', 
    function($scope, $routeParams, $uibModal, serviceRest) {

	$scope.service  = {};
	$scope.service.serviceEvaluationEntityList = [];

	  // Active button attirbutes
    $scope.activeButtonStatus = 'on';

    $scope.activeFilter = function (serviceEvaluation) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return serviceEvaluation;
          case 'off':
            return serviceEvaluation.isActive == false;
          case 'on':
            return serviceEvaluation.isActive == true;
        }
    };

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.service.serviceEvaluationEntityList.some(function(serviceEvaluation) {
        if(serviceEvaluation.id === i.id) {
          serviceEvaluation.action = 'U';
        };
      });    
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through service evaluations to find out if any has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.service.serviceEvaluationEntityList.forEach(function(serviceEvaluation) {
        if(serviceEvaluation.action == 'U') {
          enable = true;
        };
      });

      return enable;
    };   

    $scope.revert = function() {
      console.log("Reverting service evaluations back to original copy from server.")
      $scope.retrieveService($routeParams.serviceId);    
    };

    $scope.update = function() {
    	var services = new Array();
    	services.push($scope.service);
    	serviceRest.postServices(services)
    		.then(
    			function(response) {
    				$scope.retrieveService($routeParams.serviceId);
    			},
    			function(response) {
    				alert( "failure message: " + JSON.stringify({data: response.data}));
    			}
    		);
    };        

	$scope.retrieveService = function(id) {	
		serviceRest.getServiceById(id)
		.then(
		  function(response) {
		    $scope.service = response.data;
		    console.log($scope.service);
		  },
		  function(response) {
		    alert( "failure message: " + JSON.stringify({data: response.data}));
		  }
		);
    };

    $scope.retrieveService($routeParams.serviceId);  

    $scope.addServiceEvaluationOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/serviceEvaluations/editServiceEvaluationModal.html',
        controller: 'AddServiceEvaluationModalController',
        resolve: {
          service: function() {
            return $scope.service;
          }
        }
      });
    };

    $scope.editServiceEvaluationOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/serviceEvaluations/editServiceEvaluationModal.html',
        controller: 'EditServiceEvaluationModalController',
        resolve: {
          service: function() {return $scope.service;},
          serviceEvaluation: function() {return i;}
        }
      });
    };
}]);