ccwgApp.controller('ServiceListController', ['$scope', '$uibModal', '$location', 'serviceRest', 'envService',
      function($scope, $uibModal, $location, serviceRest, envService) {

    $scope.services = [];

    $scope.sortType = 'cloudServiceProvider'; // set the default sort type
    $scope.sortReverse  = false;  // set the default sort order
    
    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');

    // Active button attirbutes
    $scope.activeButtonStatus = 'on';

    $scope.showServiceEvaluations = function(service) {
      console.log("Navigate to Service Evaluation for Service with id : " + service.id);
      $location.path('/serviceEvaluations/'+ service.id);
    };

    $scope.showServiceApiActions = function(service) {
      console.log("Navigate to Service Api Action for Service with id : " + service.id);
      $location.path('/serviceApiActions/'+ service.id);
    };    

    $scope.retrieveAllServices = function() {
      serviceRest.getServices()
        .then(
          function(response) {
            $scope.services = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };

    $scope.activeClicked = function() {
      console.log("Active Button Status : " + $scope.activeButtonStatus);
    };

    $scope.activeFilter = function (service) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return service;
          case 'off':
            return service.isActive == false;
          case 'on':
            return service.isActive == true;
        }
    };

    $scope.dirtyRecordFilter = function(role) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return role;
          case 'on':
            return role.action == 'U';
        }

    };    

    $scope.serviceAttributesOpen = function(i) {
      console.log("Entering service Attributes Modal");
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/services/serviceAttributesModal.html',
        controller: 'ServiceAttributesModalController',
        resolve: {
          service: function(){ return i;}
        }
      });
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through services to find out if service has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.services.forEach(function(service) {
        if(service.action == 'U') {
          enable = true;
        };
      });

      return enable;
    };    

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.services.some(function(service) {
        if(service.id === i.id) {
          service.action = 'U';
        };
      });    
    };
    
    $scope.revertServices = function() {
      console.log("Reverting services back to original copy from server.")
      $scope.retrieveAllServices();
    };

    $scope.editServiceOpen = function(i, size) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/services/editServiceModal.html',
        controller: 'EditServiceModalController',
        size: size,
        resolve: {
          editService: function(){ return i;},
          services: function() { return $scope.services;}
        }
      });
    };


    $scope.updateServices = function() {
      serviceRest.postServices($scope.services)
        .then(
          function(response) {
            $scope.retrieveAllServices();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };

    $scope.retrieveAllServices(); // Call the serviceRest.getServices() GET method    
}]);