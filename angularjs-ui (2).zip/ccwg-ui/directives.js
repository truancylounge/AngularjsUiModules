// DIRECTIVES
ccwgApp.directive('bootstrapSwitch', [ function() {
    //console.log("Inside BootstrapSwitch Directive");
        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, element, attrs, ngModel) {
                element.bootstrapSwitch();

                element.on('switchChange.bootstrapSwitch', function(event, state) {
                    if (ngModel) {
                        scope.$apply(function() {
                            ngModel.$setViewValue(state);
                        });
                    }
                });

                scope.$watch(attrs.ngModel, function(newValue, oldValue) {
                  //console.log(attrs);
                    if (newValue) {
                        element.bootstrapSwitch('state', true, true);
                    } else {
                        element.bootstrapSwitch('state', false, true);
                    }
                });
            }
        };
    }
]);

ccwgApp.directive('magicSuggest', [function() {
    //console.log("Inside MagicSuggest Directive");
        return {
            restrict: 'E',
            replace: true,
            scope: {
                values: "=",
                defaultFilterValues: "=",
                selected: '&',
                msFunction: '='
            },
            compile: function(element, attrs) {
                console.log(attrs);
                var html = "<div id='" + (attrs.id || 'magicSelect' ) + "' ></div>";
                var newElem = $(html);
                element.replaceWith(newElem);
                
                // Link function
                return function(scope, element, attrs) {                    

                    var filter = element.magicSuggest({
                        placeholder: 'Type or click here',
                        allowFreeEntries: false,
                        data: scope.values,
                        value: scope.defaultFilterValues, // Sets default values
                        toggleOnClick: true,
                        //selectionStacked: true,
                        selectionPosition: 'bottom',
                        maxSelection: 20

                    });

                    scope.msFilterFunction = scope.msFunction || {};

                    scope.msFilterFunction.setValues = function(filteredValues) {
                        filter.clear();
                        filter.setValue(filteredValues);
                    };


                    $(filter).on('selectionchange', function(){
                        //console.log(this.getValue());
                        scope.selected({data: this.getValue()});                        
                    });
                }

            }

        };
    }
]);

ccwgApp.directive('permission', ['authService', '$sessionStorage', function(authService, $sessionStorage) {
    return {
       restrict: 'A',
       scope: {
          permission: '='
       },
       link: function (scope, elem, attrs) {        
            scope.$watch(function() {return $sessionStorage.user.currentPermission}, function() {
                if (authService.userHasPermission(scope.permission)) {
                    elem.show();
                } else {
                    elem.hide();
                }
            });                
        }
    }


}]);