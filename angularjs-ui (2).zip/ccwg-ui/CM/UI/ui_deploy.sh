#!/bin/bash

CURR_DIR=`pwd`
BUILD_ID=$1

TEMP_DIR="/tmp/APPSEC_TOMCAT_UI"
LOGFILE="/tmp/APPSEC_TOMCAT_UI.deploy.$BUILD_ID.log"

chmod -R 775 .

if [ -d $TEMP_DIR ]; then
	echo -e  ""
    echo -e "Deleting existing $TEMP_DIR" | tee -a $LOGFILE
	echo -e  ""
    rm -rf $TEMP_DIR
fi

if [ -f "$LOGFILE" ] ; then rm $LOGFILE ; fi

echo -e "------------------------------------------------------------------" | tee -a $LOGFILE
echo -e "Starting deployment ..." | tee -a $LOGFILE
echo -e "------------------------------------------------------------------" | tee -a $LOGFILE
echo -e "BUILD_ID 		: $BUILD_ID" | tee -a $LOGFILE
echo -e "COMPONENT		: APPSEC_TOMCAT_UI" | tee -a $LOGFILE
echo -e "TARGET_ENV		: {{TARGET_ENV}}" | tee -a $LOGFILE
echo -e "------------------------------------------------------------------" | tee -a $LOGFILE

mkdir $TEMP_DIR
chmod -R 775 $TEMP_DIR
cp $CURR_DIR/*.zip $TEMP_DIR
chmod -R 775 $TEMP_DIR

echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE
echo -e  "Listing contents of temp dir: $TEMP_DIR ..." | tee -a $LOGFILE
echo -e  ""
ls -al $TEMP_DIR >> $LOGFILE 2>&1
echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE

echo -e  ""
echo -e  "Extracting files to {{TARGET_DIR}}" | tee -a $LOGFILE
echo -e  ""
sudo -u {{APP_USER}} sh -c "mkdir -p -m 775 {{TARGET_DIR}}; cd {{TARGET_DIR}}; unzip -o $TEMP_DIR/*.zip" >> $LOGFILE 2>&1

chmod 777 $LOGFILE

if [ $? -eq 0 ]; then

	cd {{TARGET_DIR}}
	echo -e  ""
	echo -e  "Running sudo -u springs /usr/local/sse/tools/2.0/tcadmin undeploy {{INSTANCE}} -app ccwg" | tee -a $LOGFILE
	echo -e  ""
	
	sudo -u springs /usr/local/sse/tools/2.0/tcadmin undeploy {{INSTANCE}} -app ccwg >> $LOGFILE 2>&1
	
	echo -e  ""
	echo -e  "Running sudo -u springs /usr/local/sse/tools/2.0/tcadmin deploy {{INSTANCE}} -app ccwg" | tee -a $LOGFILE
	echo -e  ""

	sudo -u springs /usr/local/sse/tools/2.0/tcadmin deploy {{INSTANCE}} -app ccwg >> $LOGFILE 2>&1
	echo -e  ""
	if [ $? -eq 0 ]; then

		echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE
		echo -e  "!!DEPLOYMENT SUCCESSFUL!!" | tee -a $LOGFILE
		echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE
	
		cat $LOGFILE | mailx -s"DEPLOYMENT SUCCESSFUL - APPSEC_TOMCAT_UI:{{TARGET_ENV}}:$BUILD_ID" "{{NOTIFY}}"		
		cat $LOGFILE
	fi
else	
	echo -e  ""
	echo -e  "!!!DEPLOYMENT FAILED!!!" | tee -a $LOGFILE
	echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE
	cat $LOGFILE | mailx -s"DEPLOYMENT FAILURE - APPSEC_TOMCAT_UI:{{TARGET_ENV}}:$BUILD_ID" "{{NOTIFY}}"
	cat $LOGFILE
	exit 1
fi



echo -e  "------------------------------------------------------------------" | tee -a $LOGFILE
