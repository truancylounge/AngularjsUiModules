// MODULE
var ccwgApp = angular.module('ccwgApp', ['ngRoute', 'ngResource', 'ngStorage', 'environment', 'ngAnimate', 'ui.bootstrap', 'angularjs-dropdown-multiselect', 'Auth', 'angularFileUpload', 'angularSpinner', 'ngMessages', 'dndLists', 'frapontillo.bootstrap-switch','disableAll', 'ngclipboard']);

ccwgApp.controller('homeController', ['$scope', '$sessionStorage', '$window', 'envService', function($scope, $sessionStorage, $window, envService) {
	
	
	$scope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if(phase == '$apply' || phase == '$digest') {
        if(fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };

	$scope.$watch(function() {return $sessionStorage.user}, function() {
		if($sessionStorage.user) {
			$scope.userRoles = $sessionStorage.user.permissions;
			
			// Default userName is the userId
			$scope.user = $sessionStorage.user.name;
			$scope.userName = $sessionStorage.user.userName;		
		};
	});

	$scope.openHelp = function() {
		var win = window.open(envService.read('helpUrl'), '_blank');
  		win.focus();
	}

	$scope.openReleaseNotes = function() {
		var win = window.open(envService.read('releaseNotesUrl'), '_blank');
  		win.focus();
	}

	$scope.openSplunkDashboard = function() {
		var win = window.open(envService.read('splunkDashboardUrl'), '_blank');
  		win.focus();
	}

}]);