// DIRECTIVES
ccwgApp.directive('bootstrapSwitch', [ function() {
    //console.log("Inside BootstrapSwitch Directive");
        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, element, attrs, ngModel) {
                element.bootstrapSwitch();

                element.on('switchChange.bootstrapSwitch', function(event, state) {
                    if (ngModel) {
                        scope.$apply(function() {
                            ngModel.$setViewValue(state);
                        });
                    }
                });

                scope.$watch(attrs.ngModel, function(newValue, oldValue) {
                  //console.log(attrs);
                    if (newValue) {
                        element.bootstrapSwitch('state', true, true);
                    } else {
                        element.bootstrapSwitch('state', false, true);
                    }
                });
            }
        };
    }
]);

/**
    Postion scope allows us to either position selected elements inner or bottom.
*/
ccwgApp.directive('magicSuggest', [function() {
    //console.log("Inside MagicSuggest Directive");
        return {
            restrict: 'E',
            replace: true,
            scope: {
                values: "=",
                defaultFilterValues: "=",
                selected: '&',
                position: '@',
                modified: '&',
                placeholder: '@',
                maxItems: '=',
                disabled: '@'

            },
            compile: function(element, attrs) {
                //console.log(attrs);
                var html = "<div id='" + (attrs.id || 'magicSelect' ) + "' ></div>";
                var newElem = $(html);
                element.replaceWith(newElem);
                angular.element('.ms-sel-ctn').css('overflow-x', 'hidden');
                
                // Link function
                return function(scope, element, attrs) {         
                    var filter = element.magicSuggest({
                        placeholder: scope.placeholder || 'Type or click here',
                        allowFreeEntries: false,
                        data: scope.values,
                        value: scope.defaultFilterValues, // Sets default values
                        toggleOnClick: true,
                        //selectionStacked: true,
                        maxSelection: scope.maxItems || 200,
                        selectionPosition: scope.position || 'bottom',
                        disabled: scope.disabled || false
                    });

                    // Set's values in combo as they  change in the main js file
                    scope.$watchCollection('values', setValues);
                    console.log("Entering values");
                    function setValues() {
                        filter.clear();
                        filter.setData(scope.values || []);
                    }

                    // Set's selected values in combo as they change in main js file.
                    scope.$watchCollection('defaultFilterValues', setDefaultValues);

                    function setDefaultValues() {
                        console.log("Entering default values");
                        filter.clear();
                        filter.setValue(scope.defaultFilterValues);
                    }

                    $(filter).on('selectionchange', function(){
                        //console.log(this.getValue());
                        scope.selected({data: this.getValue()});                     
                    });

                    // If Drop down has been modified this event get's triggered
                    // Used to figure out if form is pristine or dirty
                    $(filter).on('focus', function(){
                        scope.modified();                     
                    });
                }

            }

        };
    }
]);

ccwgApp.directive('permission', ['authService', '$sessionStorage', function(authService, $sessionStorage) {
    return {
       restrict: 'A',
       scope: {
          permission: '='
       },
       link: function (scope, elem, attrs) {   
            console.log('Inside permission directive!!!!!');
            scope.$watch(function() {return $sessionStorage.user.permissions.length}, function() {
                if (authService.userHasPermission(scope.permission)) {
                    elem.show();
                } else {
                    elem.hide();
                }
            });     
                     
        }
    }


}]);


ccwgApp.directive('hoverClass', function () {
    return {
        restrict: 'A',
        scope: {
            hoverClass: '@'
        },
        link: function (scope, element) {
            element.on('mouseenter', function() {
                element.addClass(scope.hoverClass);
            });
            element.on('mouseleave', function() {
                element.removeClass(scope.hoverClass);
            });
        }
    };
});

ccwgApp.directive('clickedDisable', function() {
    return {
        restrict: 'A',
        link: function(scope, ele, attrs) {
            $(ele).click(function() {
                $(ele).attr('disabled', true);
            });
        }
    };
});