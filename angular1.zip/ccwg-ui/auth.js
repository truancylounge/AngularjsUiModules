angular.module('Auth', ['ngResource', 'ngStorage', 'environment'])
.factory('authService', ['$http', '$q', 'envService', '$rootScope', '$sessionStorage', '$location', '$route',
          function($http, $q, envService, $rootScope, $sessionStorage, $location, $route) {

  var authService = {};

  /**
   *  Saves the current user in the root scope
   *  Call this in the app run() method
   */
  authService.init = function(){

      $http({
        method: 'GET',
        url: envService.read('healthCheckUrl')
      }).then(
          function(response){
            $sessionStorage.user = {};
            $sessionStorage.user.name = response.headers('X-CCWG-USER');
            $sessionStorage.user.userName = response.headers('X-CCWG-USERNAME');
            $sessionStorage.user.permissions = $.map(response.headers('X-CCWG-ROLES').slice(1, -1).split(","), $.trim); // Remove first and last character and split ','
            $sessionStorage.user.auxRoles = $.map(response.headers('X-CCWG-AUX-ROLES').slice(1, -1).split(","), $.trim); // Remove first and last character and split ','
            //console.log("User: " + $sessionStorage.user.name);
            //console.log("Permissions: " + $sessionStorage.user.permissions );

            // '$route' object has the current view of template, during refresh we need to perfomr Authorization.
            // After the first check '$routeChangeStart' event handles all authorization going forward.
            if (!authService.checkPermissionForView($route.current)){
                  //event.preventDefault();
                  $location.path("/privError");
            }
            
            $rootScope.$on('$routeChangeStart', function (event, next) {
              if (!authService.checkPermissionForView(next)){
                  event.preventDefault();
                  $location.path("/privError");
              }
            });
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );    
  };

  authService.isLoggedIn = function() {
    return $sessionStorage.user != null;
  };

  authService.currentUser = function(){
    return $sessionStorage.user;
  };

  authService.checkPermissionForView = function(view) {
      if (!view.requiresAuthentication) {
          return true;
      }
       
      return userHasPermissionForView(view);
  };

  var userHasPermissionForView = function(view){
    var result = false;
      if(!authService.isLoggedIn()){
          return false;
      }      
       

      if(!view.permissions || !view.permissions.length){
          return true;
      }
       
      return authService.userHasPermission(view.permissions);
      /*
      // Temporary fix to allow "Admin" or Team-AppOps or Team-IAM roles to gain access to IAM Policy MGMT page.
      // This code will be removed once we implement the more long term solution 
      if(view.templateUrl === 'html/iamPolicy/iamPolicyMgmt.html') {
        // Access granted to Aux Role Team-AppOps
        if($.inArray("Team-AppOps", $sessionStorage.user.auxRoles) !== -1) {
          return true;
        }
        // Access granted to Aux Role Team-IAM
        if($.inArray("Team-IAM", $sessionStorage.user.auxRoles) !== -1) {
          return true;
        }

        // Access granted to Admin
        return authService.userHasPermission(view.permissions);

      } else { // Access as usual for all other pages
        if(!view.permissions || !view.permissions.length){
          return true;
        };

        result = authService.userHasPermission(view.permissions);
      }


      return result;
      */
  };

  authService.userHasPermission = function(permissions){
      if(!authService.isLoggedIn()){
          return false;
      }

      if(!$sessionStorage.user.permissions || !$sessionStorage.user.permissions.length) {
        return false;
      }       

      var found = false;
      angular.forEach(permissions, function(permission, index){

        if($.inArray(permission, $sessionStorage.user.permissions) !== -1) {
          found = true;
          return;
        }                    
      });
       
      return found;
  };

  return authService;


}]);