var gulp = require('gulp'),
    gutil = require('gulp-util'),
    jshint = require('gulp-jshint'),
    cachebust = require('gulp-cache-bust');

// create a default task and just log a message
gulp.task('default', ['logMessage', 'watch']);

gulp.task('logMessage', function(){
	return gutil.log('Gulp is Running!')
});

gulp.task('jshint', function() {
	return gulp.src('source/javascript/**/*.js')
		.pipe(jshint())
		.pipe(jshint.reporter('jshint-stylish'));
});

// If any js file changes, run cache buster
gulp.task('watch', function() {
	gulp.watch('js/**/*.js', ['cacheBuster']);
});

gulp.task('cacheBuster', function() {
	return gulp.src('ccwg.html')
		.pipe(cachebust({
			type: 'timestamp'
		}))
		.pipe(gulp.dest('.'));
});

