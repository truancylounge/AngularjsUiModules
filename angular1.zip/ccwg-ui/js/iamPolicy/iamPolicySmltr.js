ccwgApp.controller('IamPolicySmltrController', ['$scope', 'envService', '$uibModal', 'lookupService', 'roleService', '$sessionStorage', 'serviceRest', '$timeout', 'usSpinnerService', 'awsAccountService', 'iamPolicyService', '$q',
  function($scope, envService, $uibModal, lookupService, roleService, $sessionStorage, serviceRest, $timeout, usSpinnerService, awsAccountService, iamPolicyService, $q) {

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
  };  

  $scope.awsAccountEntities = [];

  // Attributes for filters
  $scope.envs = [];
  $scope.awsAccountNames = []; 
  $scope.iamRoles = [];

  $scope.selectedAwsAccountEntity = {};
  $scope.selectedAwsAccountEnvs = [];
  $scope.selectedAwsAccountNames = [];

  $scope.selectedEnvList = [];
  $scope.selectedIamRolesList = [];

  $scope.envsLoaded = false;
  $scope.awsAccountsLoaded = false;

  $scope.managedDetailedPolicyConfigs = [];
  $scope.inlineDetailedPolicyConfigs = [];
  $scope.alternateDetailedPolicyConfigs = [];
  

  $scope.data = {};
  $scope.data.alternateFilteredProposedPoliciesPolicyConfigs = [];
  
  // Resource/ Condition section attributes
  $scope.data.uniquePolicyNameSids = []; // Unique list of selected PolicyName + Sid
  $scope.data.selectedPolicyNameSid = ''; // Selected  PolicyName + Sid
  $scope.data.selectedPolicyNameSidResources = [];
  $scope.data.selectedPolicyNameSidCurrentResource;
  $scope.data.buttonResourceDisable = true;
  $scope.data.selectedPolicyNameSidConditions;
  $scope.data.policyNameSidConditionsArray = []; // Contains an array of conditions in a particular format {conditionOperator: '', conditionKey: '', conditionValues:''}
  $scope.data.buttonConditionDisable = true;
  $scope.data.addConditionOperator;
  $scope.data.addConditionKey;
  $scope.data.addConditionValues;

  $scope.data.alternateSearchKeyword = '';
  $scope.data.alternateConditionSearchKeyword = '';
  // Managed policies that exist today in AWS
  $scope.awsManagedPolicies = [];
  // Filtered Managed policies based on filter attributes
  $scope.filteredAwsManagedPolicies = [];
  // Inline policies that exist today in AWS
  $scope.awsInlinePolicies = [];
  // Filtered Inline policies based on filter attributes
  $scope.filteredAwsInlinePolicies = [];
  // Selected Aws policy, can be inline or managed policy
  $scope.selectedAwsPolicy;

  $scope.displayAwsAccountName;
  $scope.displayIamRoleName;
  $scope.displayEnv;
  $scope.displaySource;
  $scope.displayLastUpdatedDate;
  $scope.displayLastUpdatedBy;

  $scope.policyConfigValues = ['Allow', 'Deny', 'Undefined'];

  // Pagination attributes
  $scope.currentPage = envService.read('currentPage');
  $scope.itemsPerPage = envService.read('itemsPerPage');
  $scope.maxSize = envService.read('maxSize');

  // Pagination attributes Proposed Policies table
  $scope.currentPage1 = envService.read('currentPage');
  $scope.itemsPerPage1 = envService.read('itemsPerPage');
  $scope.maxSize1 = envService.read('maxSize');

  $scope.showSidebar = true;

  $scope.showIamSmltrFilterSpinner = false;
  $scope.proposedPoliciesSpinner = false;
  $scope.showAwsPoliciesSpinner = false;

  $scope.alternateNumberOfCompliants = 0;
  $scope.alternateNumberOfType1Violations = 0;
  $scope.alternateNumberOfType2Violations = 0;

  // Api Action Filter Attributes
  $scope.apiActionFilterValues = [];
  $scope.selectedApiActionsList = [];
  $scope.selectedApiActionValues = function(data) {
    $scope.safeApply(function() {
      $scope.selectedApiActionsList = data;
    });    
  };

  // Alternate Statement Filter Values
  $scope.alternateStatementFilterValues = [];
  $scope.selectedAlternateStatementsList = [];
  $scope.selectedAlternateStatementValues = function(data) {
    $scope.safeApply(function() {
      $scope.selectedAlternateStatementsList = data;
    }); 
  };

  // Alternate Resource Filter Values
  $scope.alternateResourceFilterValues = [];
  $scope.selectedAlternateResourcesList = [];
  $scope.selectedAlternateResourceValues = function(data) {
    $scope.safeApply(function() {
      $scope.selectedAlternateResourcesList = data;
    });    
  };

  // Alternate Status Filter Values
  $scope.alternateStatusFilterValues = ['type1', 'type2', 'compliant'];
  $scope.selectedAlternateStatusList = [];
  $scope.selectedAlternateStatusValues = function(data) {
    $scope.safeApply(function() {
      $scope.selectedAlternateStatusList = data;
    });    
  };

  /*
    As the Api Action filter value changes, the managed and inline policies need to be updated as well.
  */
  $scope.$watchCollection('selectedApiActionsList', function() {
      console.log('Api Action filter changed: ', $scope.selectedApiActionsList  );
      $scope.performCurrentPolicyApiActionPolicyFiltering();
  });

  /*
    Watch change to data.alternateFilteredProposedPoliciesPolicyConfigs and as the selection changes, modify the data.uniquePolicyNameSids
    The Resource and Condition Block get's populated by this watch method
  */
  $scope.$watchCollection('data.alternateFilteredProposedPoliciesPolicyConfigs', function() {
    $scope.initiateAlternateResourceConditionPopulation();    
  });

  // Validation messages for Left Filter
  $scope.leftFilterValidation = {
    awsAccountInvalid: true,
    iamRoleFilterInvalid: true
  };

  $scope.isRunPolicySimulatorDisabled = function() {
    return $scope.leftFilterValidation.iamRoleFilterInvalid ||
              $scope.selectedAwsAccountNames.length === 0;
  };

  $scope.selectedIamRoles = function(data) {
    $scope.selectedIamRolesList = data;

      // Check if atleast one role has been selected, if not flag as validation error
      if($scope.selectedIamRolesList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.iamRoleFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.iamRoleFilterInvalid = false;
         });
      }
  };

  $scope.updateAwsAccountName = function(data) {

    $scope.safeApply(function() {
      $scope.selectedAwsAccountNames = data;
      // Set default invalid to true
      $scope.leftFilterValidation.awsAccountInvalid = true;

      $scope.selectedAwsAccountEnvs = [];
      $scope.selectedIamRolesList = [];
      $scope.leftFilterValidation.iamRoleFilterInvalid = true;
      // Figure out the selected Aws Account Entity by splitting the string by :
      // The selected Aws Account Entity is used to display the Env and also to fetch deltas
      if($scope.selectedAwsAccountNames.length > 0) {
        // Setting invalid to false
        $scope.leftFilterValidation.awsAccountInvalid = false;
        var awsOrg = $scope.selectedAwsAccountNames[0].split(":", 3)[0];
        var awsAccountName = $scope.selectedAwsAccountNames[0].split(":", 3)[1];
        var awsAccountArn = $scope.selectedAwsAccountNames[0].split(":", 3)[2];
      
        // Figuring out Aws Account Entity
        $scope.awsAccountEntities.forEach(function(awsAccount) {
          if(awsAccountName === awsAccount.accountName && awsOrg === awsAccount.org && awsAccountArn === awsAccount.accountArn) {
            $scope.selectedAwsAccountEntity = awsAccount;
            $scope.selectedAwsAccountEnvs.push(awsAccount.environment);
            $scope.iamRoles = awsAccount.awsRoles;
            //console.log('selected entity: ', $scope.selectedAwsAccountEntity);
          }
        });
      }      
    });  
  };

  //Setting for ng-dropdown-multiselect directive
  // Table Column filters
  $scope.multiSelectSettings = {
      //closeOnSelect: true,
      //closeOnDeselect: true,
      scrollableHeight: '300px',
      scrollable: true,
      externalIdProp: '',
      buttonClasses: 'btn btn-primary btn-xs'
  };

  /*
   Function takes collection & field name of an element in collection and returns unique list of field values
   This is a generic function to create column filter values.
  */
  $scope.getGenericFieldValues = function(genericCollection, fieldName) {
    var uniqueFieldValues = [];
    // Split the fieldName by dot to retrieve object values
    var innerFields = fieldName.split(".");

    if(innerFields.length === 1) {
      genericCollection.forEach(function(i) {
        if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
          uniqueFieldValues.push(i[fieldName]);
        }
      });
    } else if (innerFields.length === 2) { // To retrieve 'privilegeApproval.privilegeEntity.serviceNameShort'
      genericCollection.forEach(function(i) {
        if(uniqueFieldValues.indexOf(i[innerFields[0]][innerFields[1]]) === -1) {
          uniqueFieldValues.push(i[innerFields[0]][innerFields[1]]);
        }
      });
    }    
    
    return uniqueFieldValues.sort();
  };

  /*
    Creates generic column map for $scope.serviceNameColumnIdMap, $scope.apiPrefixColumnIdMap  etc
    Function takes unique column values & column map
  */
  $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
    var id = 1;
    genericColumnValues.forEach(function(value) {
      genericColumnMap[value] = id++;
    });
  };

  /*
    Create Generic Column Filter values.
    Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
  */
  $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
    genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
    genericColumnValues.forEach(function(value) {
      genericColumnData.push({
        id: genericColumnIdMap[value],
        label: value
      });
    });
  };

  /* Column Filter section - End */  

  $scope.clearApiActionFilterAttributes = function() {
    $scope.selectedApiActionsList = [];
  };

  $scope.performCurrentPolicyApiActionPolicyFiltering = function() {
    angular.copy($scope.awsManagedPolicies, $scope.filteredAwsManagedPolicies );
    angular.copy($scope.awsInlinePolicies, $scope.filteredAwsInlinePolicies );
    // If no api actions are selected do nothing.
    // Else filter the managed and inline policies and display only the selected api actions   
    if($scope.selectedApiActionsList.length > 0) {     
      $scope.filteredAwsManagedPolicies = $scope.getFilteredManagedPolicies($scope.selectedApiActionsList);
      $scope.filteredAwsInlinePolicies = $scope.getFilteredInlinePolicies($scope.selectedApiActionsList);
    }

    // If we have managed policies, select the first one if not select an inline policy.
    if($scope.filteredAwsManagedPolicies.length > 0) {
      $scope.selectedAwsPolicy = $scope.filteredAwsManagedPolicies[0];
    } else {
      $scope.selectedAwsPolicy = $scope.filteredAwsInlinePolicies[0];
    }
  };

  $scope.getFilteredManagedPolicies = function(apiActions) {
    var filteredManagedPolicies = [];
    $scope.filteredAwsManagedPolicies.forEach(function(policy) {
      var managedPolicy = JSON.parse(policy.secondElement);

      var policyStatements = [];

      managedPolicy.Statement.forEach(function(statement) {
        var actions = statement.Action;
        var filteredActions = [];
        actions.forEach(function(action) {
          if($.inArray(action.split(":")[0], apiActions) !== -1) {
            // Api Action prefix exists
            filteredActions.push(action);
          }
        });

        if(filteredActions.length > 0) {
          statement.Action = filteredActions;
          policyStatements.push(statement);
        }
      });

      // Check if policyStatements exists, if not then the Policy should not be added as after filtering there aren't any api action prefixes.
      if(policyStatements.length > 0) {
        managedPolicy.Statement = policyStatements;
        policy.secondElement = JSON.stringify(managedPolicy, null, " ");
        filteredManagedPolicies.push(policy);
      }      
    });

    return filteredManagedPolicies;
  };

  $scope.getFilteredInlinePolicies = function(apiActions) {
    var filteredInlinePolicies = [];
    $scope.filteredAwsInlinePolicies.forEach(function(policy) {
      var inlinePolicy = JSON.parse(policy.secondElement);
      var policyStatements = [];

      inlinePolicy.Statement.forEach(function(statement) {
        var actions = statement.Action;
        var filteredActions = [];
        actions.forEach(function(action) {
          if($.inArray(action.split(":")[0], apiActions) !== -1) {
            // Api Action prefix exists
            filteredActions.push(action);
          }
        });

        if(filteredActions.length > 0) {
          statement.Action = filteredActions;
          policyStatements.push(statement);
        }
      });

      // Check if policyStatements exists, if not then the Policy should not be added as after filtering there aren't any api action prefixes.
      if(policyStatements.length > 0) {
        inlinePolicy.Statement = policyStatements;
        policy.secondElement = JSON.stringify(inlinePolicy, null, " ");
        filteredInlinePolicies.push(policy);
      }
    });
    return filteredInlinePolicies;
  };

  $scope.changeSelectedAwsPolicy = function(i) {
    $scope.selectedAwsPolicy = i;
  };

  /*
    Function iterates over Managed and Inline policies and creates a unique list of Api Action Prefixes.
  */
  $scope.addApiActionFilterValues = function(iamPolicies) {
    iamPolicies.forEach(function(policy) {
      var iamPolicy = JSON.parse(policy.secondElement);
      // Loop through statement array and retrieve api action prefixes
      iamPolicy.Statement.forEach(function(statement) {
        statement.Action.forEach(function(action) {
          if($scope.apiActionFilterValues.indexOf(action.split(":")[0]) === -1) {
            $scope.apiActionFilterValues.push(action.split(":")[0]);
          }          
        });
      });
    });
    $scope.apiActionFilterValues.sort();
  };

  /*
    Function iterates over Managed and Inline policies and creates a unique list of Alternate Resources.
  */
  $scope.addAlternateResourceFilterValues = function(detailedPolicyConfigs) {

    detailedPolicyConfigs.forEach(function(config) {
      if(config.resources !== null && config.resources.length > 0) {
        config.resources.forEach(function(resource) {
          if($.inArray(resource, $scope.alternateResourceFilterValues) === -1) {
            $scope.alternateResourceFilterValues.push(resource);
          }
        });
      }
    });

    $scope.alternateResourceFilterValues.sort();
  };

  /*
    Function iterates over Managed and Inline policies and creates a unique list of Alternate Statements.
  */
  $scope.addAlternateStatementFilterValues = function(detailedPolicyConfigs) {

    detailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if($.inArray(policyNameSid, $scope.alternateStatementFilterValues) === -1) {
        $scope.alternateStatementFilterValues.push(policyNameSid);
      }
    });

    $scope.alternateStatementFilterValues.sort();
  };

  $scope.alternateResourceColumnFilter = function(i) {

    var doesEntrySatisfyCriteria = false;    

    if($scope.selectedAlternateResourcesList.length === 0) {
      doesEntrySatisfyCriteria = true;
    } else {
      
      if(i.resources === null || i.resources === undefined) {
       return doesEntrySatisfyCriteria;
      }

      i.resources.forEach(function(resource) {
        if($.inArray(resource, $scope.selectedAlternateResourcesList) !== -1) {
          doesEntrySatisfyCriteria = true;
        }
      });      
    }
    return doesEntrySatisfyCriteria;
  };

  $scope.alternateStatementColumnFilter = function(i) {

    var doesEntrySatisfyCriteria = false;

    if($scope.selectedAlternateStatementsList.length === 0) {
      doesEntrySatisfyCriteria = true;
    } else {
      var policyNameSid = i.policyName + ":" + i.sid;
      if($.inArray(policyNameSid, $scope.selectedAlternateStatementsList) !== -1) {
          doesEntrySatisfyCriteria = true;
      }    
    }
    return doesEntrySatisfyCriteria;
  };



  $scope.alternateDeviationColumnFilter = function(i) {
    if($scope.selectedAlternateStatusList.length === 0) {
      return i;
    } else {
      if($.inArray(i.deviation, $scope.selectedAlternateStatusList) !== -1) {
        return i;
      }            
    }
  };

  $scope.alternateConditionColumnFilter = function(i) {
    var conditionString = JSON.stringify(i.condition);
    if($scope.data.alternateConditionSearchKeyword === '') {
      return i;
    } else {
      if(conditionString.indexOf($scope.data.alternateConditionSearchKeyword) !== -1) {
        return i;
      }            
    }
  };

  $scope.alternatePolicyApiActionFilter = function(i) {
    if($scope.selectedApiActionsList.length === 0) {
      return i;
    } else { 
      if($.inArray(i.actionName.split(":")[0], $scope.selectedApiActionsList) !== -1) {
        return i;
      }
    }
  };

  $scope.generateConsolidatedPolicy = function() {
    var modalInstance = $uibModal.open({
      templateUrl: 'html/iamPolicy/consolidatedPolicyModal.html',
      controller: 'ConsolidatedPolicyModalController',
      resolve: {
        alternateDetailedPolicyConfigs: function() { return $scope.alternateDetailedPolicyConfigs;}
      }
    });
  };

  // Returns resource Value as "*", "Restricted", "None" based on config's Resources value
  // Called from Html file
  $scope.getResourceColumnValue = function(resources) {
    if(resources === null || resources === undefined) {
      return 'None'
    } else if(resources.length === 1 && resources[0] === '*') {
      return '*';
    } else if(resources.length > 0) {
      return 'Restricted';
    };
  };

  // Returns condition Value as "Exists", "None" based on config's Condition value
  $scope.getConditionColumnValue = function(condition) {
    if(condition === null || condition === undefined) {
      return 'None';
    } else return 'Exists';
  };

  $scope.editPolicyConfigOpen = function(i) {
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'html/iamPolicy/editPolicyConfigModal.html',
      controller: 'EditPolicyModalConfigController',
      resolve: {
        editPolicyConfig: function(){ return i;}
      }
    });
  };

  $scope.editPolicyConfig = function(i) {
    i.action = "U";
  };

  /* Resource/Condition Info - Start  */

  $scope.retrievePolicyNameSid = function(i) {
    $scope.data.selectedPolicyNameSid = i;
    $scope.data.selectedPolicyNameSidResources = $scope.retrievePolicyConfigResource($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs);
    //console.log("Selected Resources: ", $scope.data.selectedPolicyNameSidResources);
    $scope.data.selectedPolicyNameSidConditions = JSON.stringify($scope.retrievePolicyConfigCondition($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs), null, " ");
    $scope.data.policyNameSidConditionsArray = $scope.retrievePolicyNameSidConditions($scope.retrievePolicyConfigCondition($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs));
    console.log("PolicyNameSidConditions: ", $scope.data.policyNameSidConditionsArray);
  };

  $scope.retrievePolicyNameSidConditions = function(conditions) {
    var policyNameSidConditions = [];
    if(conditions !== null) {
      Object.keys(conditions).forEach(function(conditionOperator) {
        var conditionKeyValues = conditions[conditionOperator];
        var conditionKey = Object.keys(conditionKeyValues)[0];
        var conditionValues = conditionKeyValues[conditionKey];

        var policyNameSidCondition = {
          "conditionOperator": conditionOperator,
          "conditionKey": conditionKey,
          "conditionValues": conditionValues
        };

        policyNameSidConditions.push(policyNameSidCondition);
      });
    }

    return policyNameSidConditions;
  };

  $scope.addResource = function() {
    if($scope.data.selectedPolicyNameSidResources.indexOf($scope.data.selectedPolicyNameSidCurrentResource) === -1) {
      $scope.data.selectedPolicyNameSidResources.unshift($scope.data.selectedPolicyNameSidCurrentResource);
    }
    
    $scope.data.selectedPolicyNameSidCurrentResource = '';
    $scope.data.buttonResourceDisable = false;
  };

  $scope.deleteResource = function(index) {
    $scope.data.selectedPolicyNameSidResources.splice(index, 1);
    $scope.data.buttonResourceDisable = false;
  };

  $scope.editResource = function(index) {
    $scope.data.selectedPolicyNameSidCurrentResource = $scope.data.selectedPolicyNameSidResources[index];
    $scope.data.buttonResourceDisable = false;
  };

  $scope.addNewCondition = function() {
    var policyNameSidCondition = {
      "conditionOperator": $scope.data.addConditionOperator,
      "conditionKey": $scope.data.addConditionKey,
      "conditionValues": $scope.data.addConditionValues.split(",")
    };
    $scope.data.policyNameSidConditionsArray.unshift(policyNameSidCondition);
    // Adding current condition to existing condition json string
    var conditions = JSON.parse($scope.data.selectedPolicyNameSidConditions) || {};
    conditions[$scope.data.addConditionOperator] = {};
    conditions[$scope.data.addConditionOperator][$scope.data.addConditionKey] = $scope.data.addConditionValues.split(",");
    $scope.data.selectedPolicyNameSidConditions = JSON.stringify(conditions, null, " ");    

    $scope.data.addConditionOperator = $scope.data.addConditionKey = $scope.data.addConditionValues = ''; 
    $scope.data.buttonConditionDisable = false;   
  };

  $scope.deleteCondition = function(index) {
    var deletedCondition = $scope.data.policyNameSidConditionsArray.splice(index, 1);
    // Removing current condition to existing condition json string
    var conditions = JSON.parse($scope.data.selectedPolicyNameSidConditions);
    delete conditions[deletedCondition[0].conditionOperator];
    $scope.data.selectedPolicyNameSidConditions = JSON.stringify(conditions, null, " ");

    $scope.data.buttonConditionDisable = false;
  };

  $scope.revertAlternateResourceCondition = function() {
    $scope.initiateAlternateResourceConditionPopulation();
  };

  $scope.saveAlternateResourceCondition = function() {
    $scope.addAlternatePolicyConfigResource($scope.data.selectedPolicyNameSid, $scope.data.selectedPolicyNameSidResources);
    $scope.addAlternatePolicyConfigCondition($scope.data.selectedPolicyNameSid, JSON.parse($scope.data.selectedPolicyNameSidConditions));

    $scope.initiateAlternateResourceConditionPopulation();
  };

  // Takes a combination of policyName:Sid & detailed policy configs and return's resource for that statement.
  $scope.retrievePolicyConfigResource = function(policyNameSid, detailedPolicyConfigs) {
    var resources = [];
    detailedPolicyConfigs.some(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === $scope.data.selectedPolicyNameSid) {
        return resources = angular.copy(policyConfig.resources); // Short Circuit when match found.
      }
    });

    return resources;
  };

  // Takes a combination of policyName:Sid and return's condition for that statement.
  $scope.retrievePolicyConfigCondition = function(policyNameSid, detailedPolicyConfigs) {
    var condition = {};
    detailedPolicyConfigs.some(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === $scope.data.selectedPolicyNameSid) {
        return condition = angular.copy(policyConfig.condition); // Short Circuit when match found.
      }
    });

    /* Only For Testing Purposes */
    /*
    condition = {
      "DateGreaterThan" : {
         "aws:CurrentTime" : "2013-08-16T12:00:00Z"
       },
      "DateLessThan": {
         "aws:CurrentTime" : "2013-08-16T15:00:00Z"
       },
       "IpAddress" : {
          "aws:SourceIp" : ["192.0.2.0/24", "203.0.113.0/24"]
      }
    };
    */

    return condition;
  };

  // Takes a combination of policyName:Sid + resources and add's the resources to all policy configs that have the policyName +sid.
  $scope.addPolicyConfigResource = function(selectedPolicyNameSid, resources) {

    // Rather than doing this for just filteredProposedDetailedPolicyConfigs, we run it through the entire dataset of managed and inline policy configs.
    $scope.managedDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.resources = resources;
        policyConfig.action = "U";
      }
    });

    $scope.inlineDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.resources = resources;
        policyConfig.action = "U";
      }
    });
  };
  // Takes a combination of policyName:Sid + resources and add's the conditions to all policy configs that have the policyName +sid.
  $scope.addPolicyConfigCondition = function(selectedPolicyNameSid, conditions) {
    // Rather than doing this for just filteredProposedDetailedPolicyConfigs, we run it through the entire dataset of managed and inline policy configs.
    $scope.managedDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.condition = conditions;
        policyConfig.action = "U";
      }
    });

    $scope.inlineDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.condition = conditions;
        policyConfig.action = "U";
      }
    });
  };

  // Takes a combination of policyName:Sid + resources and add's the resources to all policy configs that have the policyName +sid.
  $scope.addAlternatePolicyConfigResource = function(selectedPolicyNameSid, resources) {

    $scope.alternateDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.resources = resources;
        policyConfig.action = "U";
      }
    });
  };
  // Takes a combination of policyName:Sid + resources and add's the conditions to all policy configs that have the policyName +sid.
  $scope.addAlternatePolicyConfigCondition = function(selectedPolicyNameSid, conditions) {
    $scope.alternateDetailedPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if(policyNameSid === selectedPolicyNameSid) {
        policyConfig.condition = conditions;
        policyConfig.action = "U";
      }
    });
  };

  $scope.initiateAlternateResourceConditionPopulation = function() {
    $scope.data.uniquePolicyNameSids = [];
    $scope.data.buttonResourceDisable = true;
    $scope.data.buttonConditionDisable = true;

    $scope.data.alternateFilteredProposedPoliciesPolicyConfigs.forEach(function(policyConfig) {
      var policyNameSid = policyConfig.policyName + ":" + policyConfig.sid;
      if($.inArray(policyNameSid, $scope.data.uniquePolicyNameSids) === -1) {
        $scope.data.uniquePolicyNameSids.push(policyConfig.policyName + ":" + policyConfig.sid);
      }
    });
    $scope.data.selectedPolicyNameSid = $scope.data.uniquePolicyNameSids[0];
    $scope.data.selectedPolicyNameSidResources = $scope.retrievePolicyConfigResource($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs);
    $scope.data.selectedPolicyNameSidConditions = JSON.stringify($scope.retrievePolicyConfigCondition($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs), null, " ");
    $scope.data.policyNameSidConditionsArray = $scope.retrievePolicyNameSidConditions($scope.retrievePolicyConfigCondition($scope.data.selectedPolicyNameSid, $scope.alternateDetailedPolicyConfigs));
  };

  $scope.savePolicyConfigWorkingCopy = function() {
    console.log("Saving IAM Policy config working copy.");
    $scope.proposedPoliciesSpinner = true;
    // Converting condition from object to string to be compatible with back end apis
    // If we dont put the if condition in the block then condition for null is being stored as string "null"
    $scope.alternateDetailedPolicyConfigs.forEach(function(policyConfig) {
      if(policyConfig.condition !== null) {
        policyConfig.condition = JSON.stringify(policyConfig.condition);
      }  
      policyConfig.ccwgFinraAwsAccountsId = $scope.selectedAwsAccountEntity.id;
    });

    iamPolicyService.postDetailedPolicyConfigsWC($scope.alternateDetailedPolicyConfigs)
      .then(
        function(response) {
          $scope.alternateDetailedPolicyConfigs = response.data;

          if($scope.alternateDetailedPolicyConfigs.length > 0) {
            $scope.displaySource = 'Local';
            $scope.displayLastUpdatedDate = $scope.alternateDetailedPolicyConfigs[0].updatedDate;
            $scope.displayLastUpdatedBy = $scope.getUserName($scope.alternateDetailedPolicyConfigs[0].updatedBy);
          }

          $scope.alternateDetailedPolicyConfigs.forEach(function(config) {
            if(config.condition !== null) {
              config.condition = JSON.parse(config.condition);
            }
          });

          $scope.proposedPoliciesSpinner = false;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };
  /* Resource/Condition Info - End  */

  $scope.runIamPolicySimulator = function() {
    console.log("Running IAM Policy Simulator");
    $scope.managedDetailedPolicyConfigs = [];
    $scope.inlineDetailedPolicyConfigs = [];
    $scope.alternateDetailedPolicyConfigs = [];

    $scope.awsManagedPolicies = [];
    $scope.filteredAwsManagedPolicies = [];
    $scope.awsInlinePolicies = [];
    $scope.filteredAwsInlinePolicies = [];

    $scope.selectedAwsPolicy = {};

    $scope.apiActionFilterValues = [];

    $scope.alternateResourceFilterValues = [];
    $scope.alternateNumberOfCompliants = 0;
    $scope.alternateNumberOfType1Violations = 0;
    $scope.alternateNumberOfType2Violations = 0;
    $scope.alternateStatementFilterValues = [];

    $scope.displayAwsAccountName = $scope.selectedAwsAccountNames[0];
    $scope.displayIamRoleName = $scope.selectedIamRolesList[0];
    $scope.displayEnv = $scope.selectedAwsAccountEntity.environment;

    $scope.proposedPoliciesSpinner = true;
    $scope.showAwsPoliciesSpinner = true;

    $scope.retrieveDetailedPolicyConfigs(false);

    // Method retrieves managed policies from AWS for Current Policy Tab
    iamPolicyService.getManagdPolicies($scope.selectedIamRolesList[0], $scope.selectedAwsAccountEntity.id)
    .then(
        function(response) {
          $scope.awsManagedPolicies = response.data;
          angular.copy($scope.awsManagedPolicies, $scope.filteredAwsManagedPolicies );
          $scope.selectedAwsPolicy = $scope.filteredAwsManagedPolicies[0];
          //console.log('Selected Managed policy:', JSON.parse($scope.selectedAwsPolicy.secondElement) );
          $scope.addApiActionFilterValues($scope.filteredAwsManagedPolicies);
          // Managed policies take longer time to retrieve, hence I am ending the spinner once we get managed policies
          // If this api is faster than Inline then we may have to change the logic.
          $scope.showAwsPoliciesSpinner = false;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
    );

    // Method retrieves inline policies from AWS for Current Policy Tab
    iamPolicyService.getInlinePolicies($scope.selectedIamRolesList[0], $scope.selectedAwsAccountEntity.id)
    .then(
        function(response) {
          $scope.awsInlinePolicies = response.data;
          angular.copy($scope.awsInlinePolicies, $scope.filteredAwsInlinePolicies );
          $scope.addApiActionFilterValues($scope.filteredAwsInlinePolicies);
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
    );
  };

  $scope.retrievePolicyConfigFromAws = function() {
    $scope.proposedPoliciesSpinner = true;
    
    $scope.alternateDetailedPolicyConfigs = [];
    $scope.alternateNumberOfCompliants = 0;
    $scope.alternateNumberOfType1Violations = 0;
    $scope.alternateNumberOfType2Violations = 0;
    
    $scope.retrieveDetailedPolicyConfigs(true);
    
  };

  /**
    Only perform the below transformations if AWS is source, if its a local copy this has already been done. 

    (a) Add publish Action to the configs, for type2 deviations it is gs action else it is iamAction
    (b) Condition parsing to object
    (c) Add policyName & sid to type2 deviations
  */
  $scope.transformDetailePolicyConfigs = function(detailedPolicyConfigs) {

    detailedPolicyConfigs.forEach(function(config) {
      if(config.condition !== null) {
        config.condition = JSON.parse(config.condition);
      }
      if(config.deviation === 'type2') {
        config.policyName = 'CCP_SYSTEM';
        config.sid = 'Non_Compliant_Type2';
        config.resources = ['*'];
        config.publishAction = config.gsAction;
      } else {
        config.publishAction = config.iamAction;
      }
    });
  };

  /**
    Calculate count for Type1, Type2 & Compliant violations
    We call this method once for Managed policy configs and once for Inline Policy configs.
  */
  $scope.incrementViolationCount = function(detailedPolicyConfigs) {
    detailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type2') {
        $scope.alternateNumberOfType2Violations++;
      } else if(config.deviation === 'type1') {
        $scope.alternateNumberOfType1Violations++;
      } else {
        $scope.alternateNumberOfCompliants++;
      }
    });
  };

  /**
    Retrieve Managed and Inline policy configs.
    If a local copy exists, then it will be returned unless a fresh copy from cloud is explicitly requested
  */
  $scope.retrieveDetailedPolicyConfigs = function(fromCloud) {
    iamPolicyService.getManagedDetailedPolicyConfigs($scope.selectedIamRolesList[0], $scope.selectedAwsAccountEntity.id, fromCloud)
      .then(
          function(response) {
            $scope.managedDetailedPolicyConfigs = response.data;
            
            // Only perform transformation if source is AWS, it's already done for Local and there are changes we don't want to overwrite
            if($scope.managedDetailedPolicyConfigs.length > 0 && $scope.managedDetailedPolicyConfigs[0].source === 'AWS') {
              $scope.transformDetailePolicyConfigs($scope.managedDetailedPolicyConfigs);  
              $scope.displaySource = 'AWS';
            } else {
              $scope.displaySource = 'Local';
              $scope.displayLastUpdatedDate = $scope.managedDetailedPolicyConfigs[0].updatedDate;
              $scope.displayLastUpdatedBy = $scope.getUserName($scope.managedDetailedPolicyConfigs[0].updatedBy);
            }
            
            $scope.alternateDetailedPolicyConfigs.push.apply($scope.alternateDetailedPolicyConfigs, angular.copy($scope.managedDetailedPolicyConfigs));
            $scope.addAlternateResourceFilterValues($scope.managedDetailedPolicyConfigs);
            $scope.addAlternateStatementFilterValues($scope.managedDetailedPolicyConfigs);

            $scope.incrementViolationCount($scope.managedDetailedPolicyConfigs);


            $scope.proposedPoliciesSpinner = false;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );

    iamPolicyService.getInlineDetailedPolicyConfigs($scope.selectedIamRolesList[0], $scope.selectedAwsAccountEntity.id, fromCloud)
      .then(
          function(response) {
            $scope.inlineDetailedPolicyConfigs = response.data;

            // Only perform transformation if source is AWS, it's already done for Local and there are changes we don't want to overwrite
            if($scope.inlineDetailedPolicyConfigs.length > 0 && $scope.inlineDetailedPolicyConfigs[0].source === 'AWS') {
              $scope.transformDetailePolicyConfigs($scope.inlineDetailedPolicyConfigs);  
            }

            $scope.alternateDetailedPolicyConfigs.push.apply($scope.alternateDetailedPolicyConfigs, angular.copy($scope.inlineDetailedPolicyConfigs));
            $scope.addAlternateResourceFilterValues($scope.inlineDetailedPolicyConfigs);
            $scope.addAlternateStatementFilterValues($scope.inlineDetailedPolicyConfigs);

            $scope.incrementViolationCount($scope.inlineDetailedPolicyConfigs);
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );
  };

  /**
    Initialize method which does the following
      (1) Retrieves IAM AWS Accounts
  */
  $scope.initialize = function() {

    $scope.showIamSmltrFilterSpinner = true;

    awsAccountService.getIamAwsAccounts()
        .then(
            function(response) {
              $scope.awsAccountEntities = response.data;
              $scope.awsAccountEntities.forEach(function(awsAccount) {
                if(awsAccount.isActive === true) {
                  $scope.awsAccountNames.push(awsAccount.org + ":" + awsAccount.accountName + ":" + awsAccount.accountArn);
                }                
              });
              $scope.awsAccountsLoaded = true;
              $scope.showIamSmltrFilterSpinner = false;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
      );
  };


  $scope.initialize();

}]);