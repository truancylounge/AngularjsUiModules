ccwgApp.controller('IamPolicyMgmtController', ['$scope', 'envService', 'lookupService', 'roleService', '$sessionStorage', 'serviceRest', '$timeout', 'usSpinnerService', 'awsAccountService', 'iamPolicyService', '$q',
  function($scope, envService, lookupService, roleService, $sessionStorage, serviceRest, $timeout, usSpinnerService, awsAccountService, iamPolicyService, $q) {

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
  };  

  $scope.roleEntities = [];
  $scope.serviceEntities = [];
  $scope.awsAccountEntities = [];

  // Attributes for filters
  $scope.services = [];
  $scope.roles = [];
  $scope.envs = [];
  $scope.awsAccountNames = []; 

  // IAM Policy Configurations
  $scope.iamPolicyConfigurations = [];
  $scope.noOfManagedPolicies;
  $scope.policyArnSize;

  $scope.compositePolicyGeneration = true;


  $scope.selectedAwsAccountEntity = {};
  $scope.selectedAwsAccountEnvs = [];
  $scope.selectedAwsAccountNames = [];

  $scope.selectedRolesList = [];
  $scope.selectedServicesList = []; 
  $scope.selectedEnvList = [];

  $scope.rolesLoaded = false;
  $scope.servicesLoaded = false;
  $scope.envsLoaded = false;
  $scope.awsAccountsLoaded = false;

  $scope.showIamMgmtFilterSpinner = false;

  $scope.policyArnPrefix = "arn:aws::iam::";

  $scope.selectedFilesIds = [];

  // Validation messages for Left Filter
  $scope.leftFilterValidation = {
    awsAccountInvalid: true,
    roleFilterInvalid: true,
    serviceFilterInvalid: true
  };

  $scope.selectedPoliciesJson = [];
  // Array of selected policies from the filter
  $scope.iamPolicies = [];

  $scope.selectedRoles = function(data) {
    $scope.selectedRolesList = data;

      // Check if atleast one role has been selected, if not flag as validation error
      if($scope.selectedRolesList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.roleFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.roleFilterInvalid = false;
         });
      }
  };

  $scope.selectedServices = function(data) {
    $scope.selectedServicesList = data;

    // Check if atleast one Service has been selected, if not flag as validation error
      if($scope.selectedServicesList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.serviceFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.serviceFilterInvalid = false;
         });
      }
  };

  $scope.updateAwsAccountName = function(data) {

    $scope.safeApply(function() {
      $scope.selectedAwsAccountNames = data;
      // Set default invalid to true
      $scope.leftFilterValidation.awsAccountInvalid = true;

      $scope.selectedAwsAccountEnvs = [];
      // Figure out the selected Aws Account Entity by splitting the string by :
      // The selected Aws Account Entity is used to display the Env and also to fetch deltas
      if($scope.selectedAwsAccountNames.length > 0) {
        // Setting invalid to false
        $scope.leftFilterValidation.awsAccountInvalid = false;
        var awsOrg = $scope.selectedAwsAccountNames[0].split(":", 3)[0];
        var awsAccountName = $scope.selectedAwsAccountNames[0].split(":", 3)[1];
        var awsAccountArn = $scope.selectedAwsAccountNames[0].split(":", 3)[2];
      
        // Figuring out Aws Account Entity
        $scope.awsAccountEntities.forEach(function(awsAccount) {
          if(awsAccountName === awsAccount.accountName && awsOrg === awsAccount.org && awsAccountArn === awsAccount.accountArn) {
            $scope.selectedAwsAccountEntity = awsAccount;
            $scope.selectedAwsAccountEnvs.push(awsAccount.environment);
            //console.log('selected entity: ', $scope.selectedAwsAccountEntity);
          }
        });
      }      
    });  
  };

  $scope.isRetrievePoliciesDisabled = function() {
    return $scope.leftFilterValidation.serviceFilterInvalid ||
            $scope.leftFilterValidation.roleFilterInvalid ||
              $scope.selectedAwsAccountNames.length === 0;
  }

  $scope.isCompositePolicyGenerationDisabled = function() {
    // No of managed policies are less than selected services, hence we need to consolidate policies
    // hence composite policy generation is set to true and the checkbox is disabled
    if($scope.noOfManagedPolicies < $scope.selectedServicesList.length) {
      $scope.compositePolicyGeneration = true;
    } else {
      return false;
    }
  };

  /**
    If $scope.compositePolicyGeneration == false, then number of services selected doesn't exceed the $scope.noOfManagedPolicies config value
    We run this method to retrieve each policy of role + service + aws account id, independantly
  */
  $scope.atomicIamPolicyRetrieval = function() {
    var promises = [];
    $scope.iamPolicies = [];
    $scope.selectedPoliciesJson = [];

    $scope.selectedRolesList.forEach(function(roleName) {
      var roleId;

      $scope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.roleName === roleName) {
          roleId = roleEntity.id;
        }
      });

      $scope.selectedServicesList.forEach(function(serviceName) {
        var serviceId;
        $scope.serviceEntities.forEach(function(serviceEntity) {
          if(serviceEntity.serviceNameShort === serviceName.split(":")[0]) {
            serviceId = serviceEntity.id;
          };
        });
        promises.push(iamPolicyService.getIamPolicy(roleId, serviceId, $scope.selectedAwsAccountEntity.id));

      });
    });

    $q.all(promises).then(function(response) {
      for(i = 0; i < promises.length; i++) {
        $scope.iamPolicies.push(response[i].data);
      };
      $scope.showIamMgmtFilterSpinner = false;
    },
    function(response) {
      alert( "failure message: " + JSON.stringify({data: response.data}));
    });
  };

  /**
    If $scope.compositePolicyGeneration == true, then number of services selected exceed the $scope.noOfManagedPolicies config value
    We run this method to retrieve composite policies for each Role
  */
  $scope.compositeIamPolicyRetrieval = function() {
    var promises = [];
    $scope.iamPolicies = [];
    $scope.selectedPoliciesJson = [];

    var serviceIds = [];
    $scope.selectedServicesList.forEach(function(serviceName) {
      $scope.serviceEntities.forEach(function(serviceEntity) {
        if(serviceEntity.serviceNameShort === serviceName.split(":")[0]) {
          serviceIds.push(serviceEntity.id);
        };
      });
    });

    $scope.selectedRolesList.forEach(function(roleName) {
      var roleId;

      $scope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.roleName === roleName) {
          roleId = roleEntity.id;
        }
      });      

      promises.push(iamPolicyService.getIamPoliciesByRoleId(roleId, serviceIds, $scope.selectedAwsAccountEntity.id));
    });

    $q.all(promises).then(function(response) {
      for(i = 0; i < promises.length; i++) {
        response[i].data.forEach(function(policy) {
          $scope.iamPolicies.push(policy);
        });        
      };
      $scope.showIamMgmtFilterSpinner = false;
    },
    function(response) {
      alert( "failure message: " + JSON.stringify({data: response.data}));
    });
  };

  /*
    Method used to populate the IAM Policies table
    Retrieves all the policies by running multiple promises
  */
  $scope.retrieveIamPolicies = function() {
    //console.log("Selected Roles list: ", $scope.selectedRolesList);
    //console.log("Selected Services List: ", $scope.selectedServicesList);
    //console.log("Selected Aws Account Entity: ", $scope.selectedAwsAccountEntity);
    //console.log("Composite Policy Generation: ", $scope.compositePolicyGeneration);
    $scope.showIamMgmtFilterSpinner = true;
    
    if($scope.compositePolicyGeneration === true) {
      console.log("Composite policy retrieval");
      $scope.compositeIamPolicyRetrieval();

    } else {
      console.log("Atomic Policy Retrieval");
      $scope.atomicIamPolicyRetrieval();
    }
  };

  /*
    Makes to create zip files and display json policies on the page
  */
  $scope.downloadIamPolicies = function() {
    var zip = new JSZip();
    $scope.selectedPoliciesJson = [];
    //zip.file("policy1.json", JSON.stringify(response[0].data, null, " ") );
    //zip.file("policy2.json", JSON.stringify(response[1].data, null, " ") );
    $scope.selectedFilesIds.forEach(function(Id) {
      $scope.iamPolicies.forEach(function(policy) {
        if(policy.Id === Id) {
          var fileName = policy.filename + ".json";
          // Creating json policy by removing filename property & stringifying
          var policyJson = angular.copy(policy);
          delete policyJson.filename;
          delete policyJson.checked;
          //console.log("Policy: ", policy);
          //console.log("PolicyJson: ", policyJson);
          $scope.selectedPoliciesJson.push(JSON.stringify(policyJson, null, " ")) ;
          zip.file(fileName, JSON.stringify(policyJson));
        }
      });
    });

    var blob = zip.generate({type:"blob"});
    saveAs(blob, "ccp_policies.zip");

    // Reset the checkbox modals
    $scope.selectedFilesIds = [];
    $scope.iamPolicies.forEach(function(policy) {
      policy.checked = false;
    });

    console.log("Selected Policies JSON: ", $scope.selectedPoliciesJson);

  };

  $scope.isDownloadButtonValid = function() {
      return $scope.selectedFilesIds.length > 0 ? true : false
  };

  $scope.retrievePolicyId = function(i) {
    return JSON.parse(i).Id;
  }

  $scope.updateSelected = function(action, Id) {
      // Selected file id doesn't exist in the selected list, add the id
      if(action === 'add' & $scope.selectedFilesIds.indexOf(Id) === -1) {
          $scope.selectedFilesIds.push(Id)
      };

      if(action === 'remove' && $scope.selectedFilesIds.indexOf(Id) !== -1) {
          $scope.selectedFilesIds.splice($scope.selectedFilesIds.indexOf(Id), 1);
      }
  };

  $scope.selectedFileEntry = function($event, i) {
      var action = ($event.target.checked ? 'add' : 'remove');
      $scope.updateSelected(action, i.Id);
  };

  $scope.selectAll = function() {    
    $scope.iamPolicies.forEach(function(i) {
      i.checked = true;
      $scope.updateSelected('add', i.Id);
    });
  };

  /**
    Initialize method which does the following
      (1) Retrieves RoleEntities and populates $scope.roles
      (2) Retrieves ServiceEntities and populates $scope.services
      (3) Retrieves AWS Accounts
  */
  $scope.initialize = function() {   

    $scope.iamPolicies = [];
    // Reset the checkbox modals
    $scope.selectedFilesIds = [];
    $scope.selectedPoliciesJson = [];

    //$scope.showIamMgmtFilterSpinner = true; 

    // Retrieve role entities which can be used later to create privileges 
    roleService.getRoles()
      .then(
        function(response) {          
          $scope.roleEntities = response.data;
          $scope.roleEntities.forEach(function(roleEntity) {
            if(roleEntity.isActive === true) {
              $scope.roles.push(roleEntity.roleName);
            }            
          });
          $scope.rolesLoaded = true;

          // Sorting the Roles Filter values to be alphabetic
          $scope.roles.sort();
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    serviceRest.getServices()
      .then(
        function(response) {          
          $scope.serviceEntities = response.data;
          $scope.serviceEntities.forEach(function(serviceEntity) {
            if(serviceEntity.isActive === true) {
              $scope.services.push(serviceEntity.serviceNameShort + ":" + serviceEntity.serviceNameLong);
            }            
          });    
          $scope.servicesLoaded = true; 
          // Sorting the Service Filter values to be alphabetic
          $scope.services.sort();  
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );  

    // Adding envs creation here coz lookup service takes some time to load envs.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.iamPolicyConfigurations = response.iamPolicyConfigurations;
          $scope.iamPolicyConfigurations.forEach(function(configuration) {
            if(configuration.tkey === 'NO_OF_POLICIES') {
              $scope.noOfManagedPolicies = configuration.value;
            } 
            if(configuration.tkey ===
             'POLICY_ARN_SIZE') {
              $scope.policyArnSize = configuration.value;
            } 
          });

          console.log('IAM Policy Configurations: ', $scope.noOfManagedPolicies, $scope.policyArnSize  );

          $scope.envs = response.environments;
          $scope.envsLoaded = true;

        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }

      );

    awsAccountService.getAwsAccounts()
        .then(
            function(response) {
              //console.log('AwsAccounts Retrieved: ', response.data);
              $scope.awsAccountEntities = response.data;
              $scope.awsAccountEntities.forEach(function(awsAccount) {
                if(awsAccount.isActive === true) {
                  $scope.awsAccountNames.push(awsAccount.org + ":" + awsAccount.accountName + ":" + awsAccount.accountArn);
                }                
              });
              $scope.awsAccountsLoaded = true;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
      );
  };
















  $scope.initialize();

}]);