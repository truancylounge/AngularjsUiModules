ccwgApp.controller('ConsolidatedPolicyModalController', ['$scope', '$uibModalInstance', 'alternateDetailedPolicyConfigs', 'iamPolicyUtil', 
  function($scope, $uibModalInstance, alternateDetailedPolicyConfigs, iamPolicyUtil) {

    $scope.consolidatedPolicy = JSON.stringify(iamPolicyUtil.generateConsolidatedPolicy(alternateDetailedPolicyConfigs), null, " ");

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };
    
}]);


ccwgApp.controller('EditPolicyModalConfigController', ['$scope', '$uibModalInstance', 'editPolicyConfig', 
  function($scope, $uibModalInstance, editPolicyConfig) {
    $scope.policyName = editPolicyConfig.policyName;
    $scope.sid = editPolicyConfig.sid;
    $scope.resources = editPolicyConfig.resources;
    $scope.condition =  JSON.stringify(editPolicyConfig.condition, null, " ");
   
    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    }; 
}]);