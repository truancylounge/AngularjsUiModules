ccwgApp.controller('AddServiceEvaluationModalController', ['$scope', '$uibModalInstance', 'lookupService', 'service', function($scope, $uibModalInstance, lookupService, service) {

  console.log(service);
  $scope.titleSegment = "Add";

  $scope.categoryTypes = [];
  $scope.evaluationTypes = [];
  $scope.targetTypes = [];
  $scope.environments = [];
  $scope.serviceEvaluationStatuses = []; 


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addServiceEvaluation = function() {
    service.serviceEvaluationEntityList.push({
      "categoryType": $scope.categoryType, 
      "evaluationType": $scope.evaluationType,
      "targetType": $scope.targetType,
      "environment": $scope.environment,
      "serviceEvaluationStatus": $scope.serviceEvaluationStatus,
      "jiraTaskId": $scope.jiraTaskId,
      "refDeliverable": $scope.refDeliverable,
      "isActive": true,
      "action": 'I'
    });

    $uibModalInstance.close();    

  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.categoryTypes = response.categoryTypes;
        $scope.evaluationTypes = response.evaluationTypes;
        $scope.targetTypes = response.targetTypes;
        $scope.environments = response.environments;
        $scope.serviceEvaluationStatuses = response.serviceEvaluationStatuses;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );    
}]);