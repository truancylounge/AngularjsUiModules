ccwgApp.controller('ServiceEvaluationController', ['$scope', '$routeParams', '$uibModal', 'serviceRest', 'envService', '$sessionStorage',
    function($scope, $routeParams, $uibModal, serviceRest, envService, $sessionStorage) {

  	$scope.service  = {};
  	$scope.service.serviceEvaluationEntityList = [];

  	 // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after services have been saved
    $scope.showSuccessAlert = false;
    $scope.savedEvaluationsCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedEvaluationsCount = 0;
    };

    $scope.getUserName = function(userId) {
        var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

        return userName;
    };    

    $scope.activeFilter = function (serviceEvaluation) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return serviceEvaluation;
          case 'off':
            return serviceEvaluation.isActive == false;
          case 'on':
            return serviceEvaluation.isActive == true;
        }
    };

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.service.serviceEvaluationEntityList.some(function(serviceEvaluation) {
        if(serviceEvaluation.id === i.id) {
          serviceEvaluation.action = 'U';
        };
      });    
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through service evaluations to find out if any has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.service.serviceEvaluationEntityList.forEach(function(serviceEvaluation) {
        if(serviceEvaluation.action === 'U' || serviceEvaluation.action === 'I') {
          enable = true;
        };
      });

      return enable;
    };   

    $scope.revert = function() {
      console.log("Reverting service evaluations back to original copy from server.")
      $scope.retrieveService($routeParams.serviceId);    
    };

    $scope.update = function() {
    	var services = new Array();
      $scope.service.action = 'U';
    	services.push($scope.service);
    	serviceRest.postServices(services)
    		.then(
    			function(response) {

            // Setting the Alert params
            $scope.showSuccessAlert = true;
            services[0].serviceEvaluationEntityList.forEach(function(evaluationEntity) {
              if(evaluationEntity.action === 'I' || evaluationEntity.action === 'U') {
                $scope.savedEvaluationsCount++;
              }
            });

    				$scope.retrieveService($routeParams.serviceId);
    			},
    			function(response) {
    				alert( "failure message: " + JSON.stringify({data: response.data}));
    			}
    		);
    };        

	$scope.retrieveService = function(id) {	
		serviceRest.getServiceById(id)
		.then(
		  function(response) {
		    $scope.service = response.data;
		    //console.log($scope.service);
        // If User has Admin roles, show all the Service Evaluation else, show only unArchived service evaluations
        if($.inArray('Admin', $sessionStorage.user.permissions) === -1) {
          $scope.service.serviceEvaluationEntityList.forEach(function(evaluation, index) {
            if(evaluation.isActive !== true) {
              $scope.service.serviceEvaluationEntityList.splice(index, 1);
            }
          });
        } 
		  },
		  function(response) {
		    alert( "failure message: " + JSON.stringify({data: response.data}));
		  }
		);
    };

    $scope.retrieveService($routeParams.serviceId);  

    $scope.addServiceEvaluationOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/serviceEvaluations/editServiceEvaluationModal.html',
        controller: 'AddServiceEvaluationModalController',
        resolve: {
          service: function() {
            return $scope.service;
          }
        }
      });
    };

    $scope.editServiceEvaluationOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/serviceEvaluations/editServiceEvaluationModal.html',
        controller: 'EditServiceEvaluationModalController',
        resolve: {
          service: function() {return $scope.service;},
          serviceEvaluation: function() {return i;}
        }
      });
    };
}]);