ccwgApp.controller('EditServiceEvaluationModalController', ['$scope', '$uibModalInstance', 'lookupService', 'service', 'serviceEvaluation', function($scope, $uibModalInstance, lookupService, service, serviceEvaluation) {

  console.log("service" + service);
  console.log("service evaluation" + serviceEvaluation);

  $scope.titleSegment = "Edit";

  $scope.categoryTypes = [];
  $scope.evaluationTypes = [];
  $scope.targetTypes = [];
  $scope.environments = [];
  $scope.serviceEvaluationStatuses = [];

  $scope.categoryType = serviceEvaluation.categoryType;
  $scope.evaluationType = serviceEvaluation.evaluationType;
  $scope.targetType = serviceEvaluation.targetType;
  $scope.environment = serviceEvaluation.environment;
  $scope.serviceEvaluationStatus = serviceEvaluation.serviceEvaluationStatus;
  $scope.jiraTaskId = serviceEvaluation.jiraTaskId;
  $scope.refDeliverable = serviceEvaluation.refDeliverable;


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addServiceEvaluation = function() {
    service.serviceEvaluationEntityList.some(function(serviceEvaluationEntity) {
      if(serviceEvaluationEntity.id == serviceEvaluation.id) {
        serviceEvaluationEntity.categoryType = $scope.categoryType;
        serviceEvaluationEntity.evaluationType = $scope.evaluationType;
        serviceEvaluationEntity.targetType = $scope.targetType;
        serviceEvaluationEntity.environment = $scope.environment;
        serviceEvaluationEntity.serviceEvaluationStatus = $scope.serviceEvaluationStatus;
        serviceEvaluationEntity.jiraTaskId = $scope.jiraTaskId;
        serviceEvaluationEntity.refDeliverable = $scope.refDeliverable;
        serviceEvaluationEntity.action = 'U';
      };
    });

    $uibModalInstance.close();
  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.categoryTypes = response.categoryTypes;
        $scope.evaluationTypes = response.evaluationTypes;
        $scope.targetTypes = response.targetTypes;
        $scope.environments = response.environments;
        $scope.serviceEvaluationStatuses = response.serviceEvaluationStatuses;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );

    
}]);