ccwgApp.controller('EditAwsAccountModalController', ['$scope', '$uibModalInstance', 'editAwsAccount', 'awsAccounts', 'environments', 'orgs',
        function($scope, $uibModalInstance, editAwsAccount, awsAccounts, environments, orgs) {

  $scope.environments = environments;
  $scope.orgs = orgs;

  $scope.accountName = editAwsAccount.accountName;
  $scope.accountArn = editAwsAccount.accountArn;
  $scope.description = editAwsAccount.description;
  $scope.environment = editAwsAccount.environment;
  $scope.awsLoginRole = editAwsAccount.awsLoginRole;
  $scope.org = editAwsAccount.org;
  

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.editAwsAccount = function() {
    awsAccounts.some(function(awsAccount) {
      if(awsAccount.id === editAwsAccount.id) {
        awsAccount.accountName = $scope.accountName;
        awsAccount.accountArn = $scope.accountArn;
        awsAccount.description = $scope.description;
        awsAccount.environment = $scope.environment;
        awsAccount.awsLoginRole = $scope.awsLoginRole;
        awsAccount.org = $scope.org;
        awsAccount.action = 'U';
      };
    });

    $uibModalInstance.close();
  };
}]);

ccwgApp.controller('AddAwsAccountModalController', ['$scope', '$uibModalInstance', 'awsAccounts', 'environments', 'orgs', 
  function($scope, $uibModalInstance, awsAccounts, environments, orgs) {

  $scope.environments = environments;
  $scope.orgs = orgs;

  $scope.accountName;
  $scope.accountArn;
  $scope.description;
  $scope.environment;
  $scope.awsLoginRole;
  $scope.org;

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addAwsAccount = function() {
    awsAccounts.push({
      "accountName": $scope.accountName,
      "accountArn": $scope.accountArn,
      "description": $scope.description,
      "environment": $scope.environment,
      "awsLoginRole": $scope.awsLoginRole,
      "org": $scope.org,
      "action": 'I',
      "isActive": true
    });

    $uibModalInstance.close();
  };    
}]);

ccwgApp.controller('AwsAccountAttributesModalController', ['$scope', '$uibModalInstance', 'awsAccount',  
  function($scope, $uibModalInstance, awsAccount) {

  $scope.awsAccount = awsAccount;

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
  
}]);
