ccwgApp.controller('AwsAccountListController', ['$scope', '$http', '$uibModal', 'envService', 'awsAccountService', '$sessionStorage', 'lookupService',
        function($scope, $http, $uibModal, envService, awsAccountService, $sessionStorage, lookupService) {

    $scope.awsAccounts = [];
    $scope.environments = [];
    $scope.orgs = [];

    $scope.sortType = 'updatedDate'; // set the default sort type
    $scope.sortReverse  = true;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after Tags have been saved
    $scope.showSuccessAlert = false;
    $scope.savedAwsAccounts = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showAwsAccountsSpinner = false;

    /*
      Watch change to Filtered AWS Accounts results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('filteredAwsAccounts', function() {
      console.log('Filtered Aws Accounts changed WATCHH METHOD!!!!');
      $scope.updateColumnFilterValuesOnChange(); 
    });

    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettings = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };

    // Help's us figure out which filter made the change
    // One of Column Filters AccountName/ Org/ AwsLoginRole/ Env
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModified = {
      'accountName': false,
      'org': false,
      'loginRole': false,
      'env': false
    };

    // Creating a map between account name and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.accountNameColumnIdMap = {};
    $scope.orgColumnIdMap = {};
    $scope.loginRoleColumnIdMap = {};
    $scope.envColumnIdMap = {};

    $scope.clearColumnFilterAttributes = function() {
      console.log('Clear column filter attirbutes');
      $scope.selectedTableAccountNames = [];
      $scope.selectedTableOrgs = [];
      $scope.selectedTableLoginRoles = [];
      $scope.selectedTableEnvs = [];
      $scope.searchKeyword = '';
    };

    // Column Account Names filter attributes
    $scope.selectedTableAccountNames = [];
    $scope.accountNamesData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.accountNameEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableAccountNames.length > 0) {
          $scope.columnFilterModified = {'accountName': true,'org': false,'loginRole': false,'env': false};
        } else {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': false,'env': false};
        }      
      }
    };

    $scope.columnAccountNameFilter = function(i) {
      var accountNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableAccountNames.length > 0) {
        $scope.selectedTableAccountNames.forEach(function(selectedEntry) {
          accountNames.push(selectedEntry.label);
        });

        if($.inArray(i.accountName, accountNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Org filter attributes
    $scope.selectedTableOrgs = [];
    $scope.orgsData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.orgEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableOrgs.length > 0) {
          $scope.columnFilterModified = {'accountName': false,'org': true,'loginRole': false,'env': false};
        } else {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': false,'env': false};
        }      
      }
    };

    $scope.columnOrgFilter = function(i) {
      var orgs = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableOrgs.length > 0) {
        $scope.selectedTableOrgs.forEach(function(selectedEntry) {
          orgs.push(selectedEntry.label);
        });

        if($.inArray(i.org, orgs) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Login Roles filter attributes
    $scope.selectedTableLoginRoles = [];
    $scope.loginRolesData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.loginRoleEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableLoginRoles.length > 0) {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': true,'env': false};
        } else {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': false,'env': false};
        }      
      }
    };

    $scope.columnLoginRoleFilter = function(i) {
      var loginRoles = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableLoginRoles.length > 0) {
        $scope.selectedTableLoginRoles.forEach(function(selectedEntry) {
          loginRoles.push(selectedEntry.label);
        });

        if($.inArray(i.awsLoginRole, loginRoles) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Env filter attributes
    $scope.selectedTableEnvs = [];
    $scope.envsData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.envEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableEnvs.length > 0) {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': false,'env': true};
        } else {
          $scope.columnFilterModified = {'accountName': false,'org': false,'loginRole': false,'env': false};
        }      
      }
    };

    $scope.columnEnvFilter = function(i) {
      var envs = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableEnvs.length > 0) {
        $scope.selectedTableEnvs.forEach(function(selectedEntry) {
          envs.push(selectedEntry.label);
        });

        if($.inArray(i.environment, envs) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Creates data for Column Filters from $scope.awsAccounts
    $scope.createColumnTableFilter = function() {
      // Setting serviceData array for service column table filter
      var uniqueAccountNames = $scope.getGenericFieldValues($scope.awsAccounts, 'accountName');
      $scope.createGenericColumnMap(uniqueAccountNames, $scope.accountNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueAccountNames, $scope.accountNamesData, $scope.accountNameColumnIdMap);

      var uniqueOrgs = $scope.getGenericFieldValues($scope.awsAccounts, 'org');
      $scope.createGenericColumnMap(uniqueOrgs, $scope.orgColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueOrgs, $scope.orgsData, $scope.orgColumnIdMap);

      var uniqueLoginRoles = $scope.getGenericFieldValues($scope.awsAccounts, 'awsLoginRole');
      $scope.createGenericColumnMap(uniqueLoginRoles, $scope.loginRoleColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueLoginRoles, $scope.loginRolesData, $scope.loginRoleColumnIdMap);

      var uniqueEnvs = $scope.getGenericFieldValues($scope.awsAccounts, 'environment');
      $scope.createGenericColumnMap(uniqueEnvs, $scope.envColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueEnvs, $scope.envsData, $scope.envColumnIdMap);
    };

    /*
     Function takes collection & field name of an element in collection and returns unique list of field values
     This is a generic function to create column filter values.
    */
    $scope.getGenericFieldValues = function(genericCollection, fieldName) {
      var uniqueFieldValues = [];
      // Split the fieldName by dot to retrieve object values
      var innerFields = fieldName.split(".");

      if(innerFields.length === 1) {
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
            uniqueFieldValues.push(i[fieldName]);
          }
        });
      } else if (innerFields.length === 2) { // To retrieve 'privilegeApproval.privilegeEntity.serviceNameShort'
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[innerFields[0]][innerFields[1]]) === -1) {
            uniqueFieldValues.push(i[innerFields[0]][innerFields[1]]);
          }
        });
      }    
      
      return uniqueFieldValues.sort();
    };

    /*
      Creates generic column map for $scope.accountNameColumnIdMap etc
      Function takes unique column values & column map
    */
    $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
      var id = 1;
      genericColumnValues.forEach(function(value) {
        genericColumnMap[value] = id++;
      });
    };

    /*
      Create Generic Column Filter values.
      Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
    */
    $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
      genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
      genericColumnValues.forEach(function(value) {
        genericColumnData.push({
          id: genericColumnIdMap[value],
          label: value
        });
      });
    };

    /**
      Method get's called when table rows are filtered and this needs readjustment of the column values
    */
    $scope.updateColumnFilterValuesOnChange = function() {
      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do $scope.accountNamesData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModified.accountName === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredAwsAccounts, 'accountName'), 
          $scope.accountNamesData, $scope.accountNameColumnIdMap);
      };

      if($scope.columnFilterModified.org === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredAwsAccounts, 'org'), 
          $scope.orgsData, $scope.orgColumnIdMap);
      };

      if($scope.columnFilterModified.loginRole === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredAwsAccounts, 'awsLoginRole'), 
          $scope.loginRolesData, $scope.loginRoleColumnIdMap);
      };

      if($scope.columnFilterModified.env === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredAwsAccounts, 'environment'), 
          $scope.envsData, $scope.envColumnIdMap);
      };      
    };

    /* Column Filter section - End */
    
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedAwsAccounts = 0;
    };

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }
      return userName;
    };

    $scope.activeFilter = function (awsAccount) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return awsAccount;
          case 'off':
            return awsAccount.isActive == false;
          case 'on':
            return awsAccount.isActive == true;
        }
    }; 

    $scope.dirtyRecordFilter = function(awsAccount) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return awsAccount;
          case 'on':
            return (awsAccount.action === 'U' || awsAccount.action === 'I');
        }
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through Aws Accounts to find out if an account has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.awsAccounts.forEach(function(awsAccount) {
        if(awsAccount.action === 'U' || awsAccount.action === 'I') {
          enable = true;
        };
      });

      return enable;
    }; 

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.awsAccounts.some(function(awsAccount) {
        if(awsAccount.id === i.id) {
          awsAccount.action = 'U';
        };
      });    
    };   

    // Edit Aws Account Modal
    $scope.editAwsAccountOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/accounts/editAwsAccountModal.html',
        controller: 'EditAwsAccountModalController',
        resolve: {
          editAwsAccount: function(){ return i;},
          awsAccounts: function() { return $scope.awsAccounts;},
          environments: function() {return $scope.environments;},
          orgs: function(){return $scope.orgs;}
        }
      });
    };

    // Add Aws Account Modal
    $scope.addAwsAccountOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/accounts/addAwsAccountModal.html',
        controller: 'AddAwsAccountModalController',
        resolve: {
          awsAccounts: function() { return $scope.awsAccounts;},
          environments: function() {return $scope.environments;},
          orgs: function(){return $scope.orgs;}
        }
      });
    };

    // AWS Account Details Modal
    $scope.awsAccountAttributesOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/accounts/awsAccountAttributesModal.html',
        controller: 'AwsAccountAttributesModalController',
        resolve: {
          awsAccount: function(){ return i;}
        }
      });

    }

    $scope.revertAwsAccounts= function() {
      console.log("Retrieving fresh copy of Aws Accounts from Server.")
      $scope.retrieveAllAwsAccounts();
    }; 

    // Post Aws Accounts 
    $scope.postAwsAccounts = function() {
      var updatedAwsAccounts = $scope.awsAccounts.filter(function(awsAccount) {
        return awsAccount.action === 'I' || awsAccount.action === 'U';
      });

      awsAccountService.postAwsAccounts(updatedAwsAccounts)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.savedAwsAccounts = updatedAwsAccounts.length;

            $scope.retrieveAllAwsAccounts();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };


    // Retrieve Aws Accounts/ Initialize page section
    $scope.retrieveAllAwsAccounts = function() {
      $scope.showAwsAccountsSpinner = true;

      awsAccountService.getAwsAccounts()
        .then(
            function(response) {
              $scope.awsAccounts = response.data;
              $scope.createColumnTableFilter();
              $scope.showAwsAccountsSpinner = false;

            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
        );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            $scope.environments = response.environments;
            $scope.orgs = response.orgs;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );  

    };

    $scope.retrieveAllAwsAccounts();    
}]);