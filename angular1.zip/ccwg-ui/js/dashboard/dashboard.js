ccwgApp.controller('dashboardController', ['$scope', 'envService', 'dashboardService', 'privilegeReviewService', '$sessionStorage', '$uibModal', 'tagService', 'usSpinnerService',
  function($scope, envService, dashboardService, privilegeReviewService, $sessionStorage, $uibModal, tagService, usSpinnerService) {

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };
  // By default don't show the announcement section. 
  // Only show this section to Users who have Auxiliary Role --> NewsReader
  $scope.showAnnouncementSection = false;
  $scope.$watch(function() { if($sessionStorage.user) return $sessionStorage.user.auxiliaryRoles}, function() {
    if($sessionStorage.user && $.inArray('NewsReader', $sessionStorage.user.auxiliaryRoles) != -1 ) {
      $scope.showAnnouncementSection = true;   
    };
  });

/*
  $scope.safeApply(function() {
    if($.inArray('NewsReader', $sessionStorage.user.auxiliaryRoles) != -1) {
        $scope.showAnnouncementSection = true;
    }
  });
  */

  // Privilege Configuration Summary Objects 
	$scope.privilegeSummary = [];

  // Stat Summary Objects
  $scope.statSummary = [];
	$scope.statSummaryDisplay = true;
	$scope.faChevronDown = false;

  // Announcement Section Objects
  $scope.announcements = [];
  $scope.sublistAnnouncements = [];
  $scope.dashboardTags = [];
  $scope.optionalTags = [];
  $scope.selectedOptionalTags = [];
  $scope.announcementsDisplay = true;
  $scope.faChevronDownAnnouncements = false;
  $scope.activeDashboardTag = 'All';

  // Tooltip message for Privilege Summary headers
  $scope.approvedTooltip = "Count of API Actions, associated with the respective request, which have been fully approved (e.g. met CCWG Quorum requirements) and published by the CCP Admin.";
  $scope.rejectedTooltip = "Count of API Actions, associated with the respective request, which have been rejected by at least one CCWG Approver. ";
  $scope.pendingTooltip = "Count of API Actions, associated with the respective request, which have neither been fully Approved or Rejected.";

  // Initialize show spinner attributes.
  $scope.showStatSummarySpinner = false;
  $scope.showAnnouncementSpinner = false;
  $scope.showPrivSummarySpinner = false;

	$scope.expandCollapseStatSummary = function() {
		$scope.statSummaryDisplay = !$scope.statSummaryDisplay;
		$scope.faChevronDown = !$scope.faChevronDown;
	}  

  $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
  };

	// Toolbar icon actions for Privilege
	$scope.faChevronDownPrivilege = false;
	$scope.privilegeSummaryDisplay = true;	
  $scope.privilegeSummaryCurrentPage = envService.read('currentPage');
  $scope.itemsPerPage = 4;
  $scope.maxSize = 3;

  // Announcement Pagination Options
  $scope.announcementsPerPage = 10;
  $scope.announcementsCurrentPage = envService.read('currentPage');

  // Announcement date picker optionas
  $scope.dateFormat = 'dd-MMMM-yyyy';
  $scope.startDateOptions = {
    formatYear: 'yy',
    showWeeks: false,
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(2010, 1, 22),
    startingDay: 1
  };

  $scope.endDateOptions = {
    formatYear: 'yy',
    showWeeks: false,
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(2010, 1, 22),
    startingDay: 1
  };

  $scope.startDateCalender = {
    opened: false
  };

  $scope.endDateCalender = {
    opened: false
  };

  $scope.startDate = null;
  $scope.endDate = null;

  $scope.startDateOpen = function() {
    $scope.startDateCalender.opened = true;
  };

  $scope.endDateOpen = function() {
    $scope.endDateCalender.opened = true;
  };

  // Makes sure End date calender cannot select a date before start date if its set
  $scope.startDateSelected = function() {
    $scope.endDateOptions.minDate = $scope.startDate;
  };

  // Makes sure Start date calender cannot select a date after end date if its set
  $scope.endDateSelected = function() {
    $scope.startDateOptions.maxDate = $scope.endDate;
  }

  // Retrieves the Announcements between startDate and End Date
  $scope.retrieveAnnouncements = function() {
    $scope.retrieveAnnouncementDashboard($scope.startDate, $scope.endDate);
  };

	$scope.expandCollapsePrivilegeSummary = function() {
		$scope.privilegeSummaryDisplay = !$scope.privilegeSummaryDisplay;
		$scope.faChevronDownPrivilege = !$scope.faChevronDownPrivilege;
	}

  /* Stats summary open is a modal to display list of New/ Updates entities*/
  $scope.statSummaryOpen = function(i, title) {
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'html/announcements/statSummaryModal.html',
      controller: 'DashboardModalController',
      resolve: {
        entries: function(){ return i;},
        title: function() {return title;}
      }
    });
  };

  /** Announcement Dashboard Section - Start **/

  /* Announcement Additional Info open is a modal to display Additional notes of the announcement*/
  $scope.additionalInfoOpen = function(i) {
    console.log('Entering Additional Info');
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'html/announcements/announcementAdditionalInfoModal.html',
      controller: 'AdditionalInfoModalController',
      resolve: {
        announcement: function(){ return i;}
      }
    });
  };

  $scope.directToReferenceUrl = function(i) {
    console.log('Inside Redirect', i);
    var win = window.open(i.reference, '_blank');
    win.focus();

  };

  $scope.expandCollapseAnnouncementDisplay = function() {
    $scope.announcementsDisplay = !$scope.announcementsDisplay;
    $scope.faChevronDownAnnouncements = !$scope.faChevronDownAnnouncements;
  };

  $scope.getAnnouncementCount = function(tagName) {
    var count = 0;

    $scope.announcements.forEach(function(announcement) {
      if(announcement.categoryTags.includes(tagName)) {
          count++;
        }
    });

    return count;
  }

  $scope.retrieveSublistAnnouncements = function(dashboardTagName) {
    $scope.activeDashboardTag = dashboardTagName;
    $scope.sublistAnnouncements = [];
    if(dashboardTagName === 'All') {
      Array.prototype.push.apply($scope.sublistAnnouncements, angular.copy($scope.announcements));
    } else {
      $scope.announcements.forEach(function(announcement) {
        if(announcement.categoryTags.includes(dashboardTagName)) {
          $scope.sublistAnnouncements.push(angular.copy(announcement));
        }
      });
    }
  };

  // Iterate over all announcements and create a list of optional tags
  // Also weed out all the duplicate optional tags
  $scope.createOptionalTags = function() {
    $scope.optionalTags = [];
    $scope.selectedOptionalTags = [];
    $scope.announcements.forEach(function(announcement) {
      if(announcement.optionalTags !== null) {
        announcement.optionalTags.split(",").forEach(function(tag) {
          if($scope.optionalTags.indexOf(tag) === -1) {
            $scope.optionalTags.push(tag);
          }          
        });        
      }      
    });
  }

  $scope.updateSelectedOptionalTags = function(data) {      
      $scope.safeApply(function() {
          $scope.selectedOptionalTags = data;
      });
  };

  $scope.optionalTagFilter = function(announcement) {
    var filterSatisfied = false;
    // If Optional Tags aren't selected then return all Announcements
    if($scope.selectedOptionalTags.length === 0) {
      filterSatisfied = true;
    } 
    // If Announcement has optional Tag as null then it won't appear on search results as one or more Optional tag is selected
    // If Announcement has optional Tag not null then if tag is included return true else don't return result
    else if(announcement.optionalTags !== null) {
        $scope.selectedOptionalTags.some(function(tag) {
          if(announcement.optionalTags.includes(tag)) {
            filterSatisfied = true;
          }
        });
    };

    return filterSatisfied;
  };

  /** Announcement Dashboard Section - End **/

  // Retrieve Announcements between Start Date and End Date
  $scope.retrieveAnnouncementDashboard = function(startDate, endDate) {
    $scope.showAnnouncementSpinner = true;    
    /* Retrieve Dashboard Announcements */
    dashboardService.getDashboardAnnouncements(startDate, endDate)
      .then(
        function(response) {
          $scope.announcements = response.data;    
          $scope.sublistAnnouncements = response.data;
          $scope.createOptionalTags();
          $scope.showAnnouncementSpinner = false;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  // Retrieves Announcements from last 2 weeks
  $scope.initializeAnnouncementDashboard = function() {
    $scope.showAnnouncementSpinner = true;

    /* Retrieve Dashboard Announcements */
    dashboardService.getDashboardAnnouncements()
      .then(
        function(response) {
          $scope.announcements = response.data;    
          $scope.sublistAnnouncements = response.data;
          $scope.createOptionalTags();
          $scope.showAnnouncementSpinner = false;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };


	$scope.initializeDashboard = function() {
    
    $scope.showStatSummarySpinner = true;
    $scope.showPrivSummarySpinner = true;

    $scope.activeDashboardTag = 'All';
  
		/* Retrieve Stats Summary Info */
      dashboardService.getServiceInfo()
        .then(
          function(response) {
          	var serviceInfo = response.data;
          	serviceInfo.name = "Services";
            $scope.statSummary.push(serviceInfo);
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      dashboardService.getApiActionInfo()
        .then(
          function(response) {
          	var apiActionInfo = response.data;
            apiActionInfo.name = "Api Actions";
            $scope.statSummary.push(apiActionInfo);
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      dashboardService.getRolesInfo()
        .then(
          function(response) {
            var roleInfo = response.data;
          	roleInfo.name = "Roles";
            $scope.statSummary.push(roleInfo);
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      dashboardService.getPrivilegeInfo()
        .then(
          function(response) {
            var privilegeInfo = response.data;
            privilegeInfo.name = "Privileges";
            $scope.statSummary.push(privilegeInfo);  
            $scope.showStatSummarySpinner = false;            
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

    /* Retrieve Privilege Configuration Summary */  
    dashboardService.getPrivilegeRequestSummary()
      .then(
        function(response) {
          $scope.privilegeSummary = response.data;    
          // Turn spinner off once the privilege summary has been obtained from the server      
          $scope.showPrivSummarySpinner = false;
        },
        function(response) {
          console.log('Failure msg Priv originated here!!!!');
          console.log(response);
          alert( "failure message : " + JSON.stringify({data: response.data}));
        }
      );

    /* Retrieve Dashboard Tags */
    tagService.getDashboardTags()
      .then(
        function(response) {
          $scope.dashboardTags = response.data;    
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

      // Initialize Announcement Dashboard
      $scope.initializeAnnouncementDashboard();
	};

	$scope.initializeDashboard();
}]);