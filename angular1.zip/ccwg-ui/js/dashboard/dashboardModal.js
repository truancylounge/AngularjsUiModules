ccwgApp.controller('DashboardModalController', ['$scope', '$uibModalInstance', 'entries', 'title', function($scope, $uibModalInstance, entries, title) {
  console.log("Entering Dashboard modal Controller");

  $scope.title = title;
  $scope.entries = entries;
  console.log($scope.entries);

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);

ccwgApp.controller('AdditionalInfoModalController', ['$scope', '$uibModalInstance', 'announcement', function($scope, $uibModalInstance, announcement) {
  console.log("Entering Dashboard modal Controller");

  $scope.announcement = announcement;
  
  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);