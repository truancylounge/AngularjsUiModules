ccwgApp.controller('GenericErrorController', ['$scope', 'errorJson', '$sessionStorage', function($scope, errorJson, $sessionStorage) {
  console.log("Entering Generic Error Controller");
  $scope.errorObject = errorJson;   
  $scope.currentTime = new Date();  
  $scope.username = $sessionStorage.user.name;

	$scope.getUserName = function(userId) {
	  var userName;
	  if(userId !== undefined) {
	    $sessionStorage.users.some(function(user) {
	      if(user.userId.toUpperCase() === userId.toUpperCase()) 
	        userName = user.userName;
	    });
	  }

	  return userName;
	};




}]);


ccwgApp.controller('PrivErrorController', ['$scope', '$sessionStorage', function($scope, $sessionStorage) {
  console.log("Entering Priv Error Controller");

  $scope.currentTime = new Date();  
  $scope.username = $sessionStorage.user.name;

	$scope.getUserName = function(userId) {
	  var userName;
	  if(userId !== undefined) {
	    $sessionStorage.users.some(function(user) {
	      if(user.userId.toUpperCase() === userId.toUpperCase()) 
	        userName = user.userName;
	    });
	  }

	  return userName;
	};

}]);