ccwgApp.controller('FileUploadSummaryController', ['$scope', '$uibModalInstance', 'uploadSummary', 
  function($scope, $uibModalInstance, uploadSummary) {
  //editRole = this;
  console.log("Entering File Upload Summary modal Controller");

  $scope.uploadSummary = uploadSummary;
  
  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);