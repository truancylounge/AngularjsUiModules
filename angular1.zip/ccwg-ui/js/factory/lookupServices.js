ccwgApp.service('lookupService', ['$http', '$q', 'envService', function($http, $q, envService) {
	var lookupService = {};

  lookupService.retrieveReferences = function() {

    var promise = $http({method: 'GET', url: envService.read('lookupUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        var references = {};
        references.cloudServiceProviders = [];
        references.serviceStates = [];
        references.evaluationPriorities = [];
        references.categoryTypes = [];
        references.evaluationTypes = [];
        references.targetTypes = [];
        references.environments = [];
        references.orgs = [];
        references.serviceEvaluationStatuses = [];
        references.apiGsRiskRankings = [];
        references.privilegesSettingValues = [];
        references.userRoles = [];
        references.auxiliaryRoles = [];
        references.privReviewResponses = [];
        references.announcementEventTypes = [];
        references.teamAssociations = [];
        references.iamPolicyConfigurations = [];

        response.data.forEach(function(reference) {
          switch(reference.refType) {
            case 'CloudServiceProvider': 
              references.cloudServiceProviders.push(reference.value);
              break;
            case 'serviceState':
              references.serviceStates.push(reference.value);
              break;
            case 'evaluationPriority':
              references.evaluationPriorities.push(reference.value);
              break;
            case 'categoryType':
              references.categoryTypes.push(reference.value);
              break;
            case 'evaluationType':
              references.evaluationTypes.push(reference.value);
              break;
            case 'targetType':
              references.targetTypes.push(reference.value);
              break;
            case 'environment':
              references.environments.push(reference.value);
              break;
            case 'organization':
              references.orgs.push(reference.value);
              break;
            case 'serviceEvaluationStatus':
              references.serviceEvaluationStatuses.push(reference.value);
              break;
            case 'apiGsRiskRanking':
              references.apiGsRiskRankings.push(reference.value);
              break;
            case 'privilegesSettingValue':
              references.privilegesSettingValues.push(reference.value);
              break;
            case 'userRole':
              references.userRoles.push(reference.value);
              break;
            case 'auxiliaryRole':
              references.auxiliaryRoles.push(reference.value);
              break;
            case 'privReviewResponse':
              references.privReviewResponses.push(reference.value);
              break;
            case 'announcementEventType':
              references.announcementEventTypes.push(reference.value);
              break;
             case 'teamAssociation':
              references.teamAssociations.push(reference.value);
              break;
            case 'iamPolicyConfiguration':
              references.iamPolicyConfigurations.push(reference);
              break;
              
          }
        });

/*
        console.log("Cloud Service Providers retrieved: " + references.cloudServiceProviders);
        console.log("Service States retrieved: " + references.serviceStates);
        console.log("Evaluation Priorities retrieved: " + references.evaluationPriorities);

        console.log("Category Types retrieved: " + references.categoryTypes);
        console.log("Evaluation Types retrieved: " + references.evaluationTypes);
        console.log("Target Types retrieved: " + references.targetTypes);
        console.log("Environments retrieved: " + references.environments);
        console.log("Service Evaluation Statuses retrieved: " + references.serviceEvaluationStatuses);
        console.log("API GS Risk Rankings retrieved: " + references.apiGsRiskRankings);

        console.log("Privileges Setting values retrieved: " + references.privilegesSettingValues);
        console.log("User roles retrieved: " + references.userRoles);

        console.log("Privileges Review Responses retrieved: " + references.privReviewResponses);

        console.log("Announcement Event Types retrieved: " + references.announcementEventTypes);
*/

        deferObject.resolve(references);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;    

  };

  return lookupService;

}]);