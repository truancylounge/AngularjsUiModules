ccwgApp.service('tagService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var tagService = {};

  tagService.getTags = function() {

    var promise = $http({method: 'GET', url: envService.read('tagUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  tagService.getDashboardTags = function() {

    var promise = $http({method: 'GET', url: envService.read('tagDashboardUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  tagService.postTags = function(tagsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('tagUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: tagsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  return tagService;

}]);