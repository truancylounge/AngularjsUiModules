ccwgApp.service('fileService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var fileService = {}
  fileService.getSamplePrivBulkUploadFile = function() {

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('privilegeSampleBulkUploadUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  fileService.exportPrivConfigsFile = function(privilegesJson) {

    var promise = $http({
      method: 'POST', 
      responseType: 'arraybuffer', 
      url: envService.read('exportPrivilegeConfigUrl'),
      headers: {
        'Content-Type': 'application/json'
      },
      data: privilegesJson
    });
    
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;    
  };


  fileService.getPrivBulkUploadFileInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('privilegeBulkUploadFileInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  fileService.getPrivBulkUploadFiles = function(fileIds) {

    var fileIdsQueryString = "?";

    fileIds.forEach(function(fileId) {
      fileIdsQueryString = fileIdsQueryString + "fileIds=" + fileId + "&";
    });

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('privilegeBulkUploadFilesDownloadUrl') + fileIdsQueryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  return fileService;

}]);
