ccwgApp.service('awsAccountService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var awsAccountService = {};

  awsAccountService.getAwsAccounts = function() {

    var promise = $http({method: 'GET', url: envService.read('awsAccountUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  awsAccountService.getIamAwsAccounts = function() {

    var promise = $http({method: 'GET', url: envService.read('awsAccountUrl') + "/iam"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  awsAccountService.postAwsAccounts = function(awsAccountsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('awsAccountUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: awsAccountsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  return awsAccountService;

}]);