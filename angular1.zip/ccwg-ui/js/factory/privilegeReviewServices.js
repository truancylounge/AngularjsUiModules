ccwgApp.service('privilegeReviewService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var privilegeReviewService = {};

  // Retrieves Total Count of UnApproved privilege reviews
  privilegeReviewService.getUnApprovedPrivilegeReviewsCount = function() {
    
    var countUrl = envService.read('privilegeReviewUrl') + "/count";
  
    var promise = $http({method: 'GET', url: countUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves Total Count of UnApproved privilege reviews forspecific user
  privilegeReviewService.getUserUnApprovedPrivilegeReviewsCount = function() {
    
    var countUrl = envService.read('privilegeReviewUrl') + "/user/count";
  
    var promise = $http({method: 'GET', url: countUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of unapproved privilege reviews for the specific user
  privilegeReviewService.getPrivilegeReviews = function(pageNumber, pageSize) {
    var pageNumber = pageNumber || 1;
    var pageSize = pageSize || envService.read('privilegeReviewMaxPageSize');

    var paginatedUrl = envService.read('privilegeReviewUrl') + "?pageNumber=" + pageNumber + "&pageSize=" + pageSize;
  
    var promise = $http({method: 'GET', url: paginatedUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of historically approved/denied privilege reviews for the specific user
  privilegeReviewService.getHistoricPrivilegeReviews = function() {
  
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/history"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of all privilege approvals
  privilegeReviewService.getPrivilegeApprovals = function(pageNumber, pageSize) {
    var pageNumber = pageNumber || 1;
    var pageSize = pageSize || envService.read('privilegeReviewMaxPageSize');

    var paginatedUrl = envService.read('privilegeApprovalUrl') + "?pageNumber=" + pageNumber + "&pageSize=" + pageSize;
    
    var promise = $http({method: 'GET', url: paginatedUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of history of all privilege approvals i.e privilege review approvals which have been finalized
  privilegeReviewService.getPrivilegeApprovalsHistory = function(startDate, endDate) {

    var approvalHistoryUrl = envService.read('privilegeApprovalUrl') + "/history";

    // Start date and End Date get converted to format yyyy-MM-dd
    if(startDate  && endDate ) {
      approvalHistoryUrl = approvalHistoryUrl + "?" + "dateFrom=" + startDate.toISOString().slice(0,10) + "&dateTo=" + endDate.toISOString().slice(0,10);
    } 
  
    var promise = $http({method: 'GET', url: approvalHistoryUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeReviewService.postPrivilegeReviews = function(privilegeReviewsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeReviewUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegeReviewsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeReviewService.postRevertPrivilegeReviews = function(privilegeReviewsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeReviewUrl') + '/revert',
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegeReviewsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeReviewService.postPrivilegeApprovals = function(privilegeApprovalsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeApprovalUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegeApprovalsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  


  /**
    Retrieves All privilege reviews which are < 100 for a particular Request title
  */
  privilegeReviewService.getUnApprovedLeanRequests = function() {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/leanRequests"});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  /**
    Retrieves All privilege approvals which are < 100 for a particular Request title
  */
  privilegeReviewService.getLeanPrivilegeApprovals = function() {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/leanApprovals"});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  


  /**
    Retrieves Privilege Review Request Title Info for bulk request titles, > 100 privilege reviews
  */
  privilegeReviewService.getBulkPrivilegeReviewRequestTitleInfo = function() {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/bulkRequestsInfo"});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  /**
    Retrieves Privilege Approval Request Title Info for bulk request titles, > 100 privilege reviews
  */
  privilegeReviewService.getBulkPrivilegeApprovalRequestTitleInfo = function() {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/bulkApprovalsInfo"});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  /**
    Retrieves user specific UnApproved Privilege Reviews for a Request Title 
  */
  privilegeReviewService.getUnApprovedPrivilegeReviewsByRequestTitle = function(requestTitle) {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/" + requestTitle});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  /**
    Retrieves all Privilege Approvals for a Request Title 
  */
  privilegeReviewService.getPrivilegeApprovalsByRequestTitle = function(requestTitle) {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/approvals/" + requestTitle});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  // Retrieves a list of history of all lean privilege approvals i.e privilege review approvals which have been finalized & request title < 100
  privilegeReviewService.getLeanPrivilegeApprovalsHistory = function(startDate, endDate) {

    var approvalHistoryUrl = envService.read('privilegeApprovalUrl') + "/history/lean";

    // Start date and End Date get converted to format yyyy-MM-dd
    if(startDate  && endDate ) {
      approvalHistoryUrl = approvalHistoryUrl + "?" + "dateFrom=" + startDate.toISOString().slice(0,10) + "&dateTo=" + endDate.toISOString().slice(0,10);
    } 
  
    var promise = $http({method: 'GET', url: approvalHistoryUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  /**
    Retrieves Privilege Approval History Request Title Info for bulk request titles, > 100 privilege reviews
  */
  privilegeReviewService.getBulkPrivilegeApprovalHistoryRequestTitleInfo = function(startDate, endDate) {

    var bulkApprovalHistoryUrl = envService.read('privilegeReviewUrl') + "/bulkApprovalsHistoryInfo";

    // Start date and End Date get converted to format yyyy-MM-dd
    if(startDate  && endDate ) {
      bulkApprovalHistoryUrl = bulkApprovalHistoryUrl + "?" + "dateFrom=" + startDate.toISOString().slice(0,10) + "&dateTo=" + endDate.toISOString().slice(0,10);
    }
    
    var promise = $http({method: 'GET', url: bulkApprovalHistoryUrl});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  /**
    Retrieves all Historic (Published) Privilege Approvals for a Request Title 
  */
  privilegeReviewService.getPublishedPrivilegeApprovalsByRequestTitle = function(requestTitle) {
    var promise = $http({method: 'GET', url: envService.read('privilegeReviewUrl') + "/approvals/history/" + requestTitle});

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };




  
  return privilegeReviewService;

}]);