ccwgApp.service('announcementService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var announcementService = {};

  announcementService.getAnnouncements = function(startDate, endDate) {

    var announcementUrl = envService.read('announcementUrl');

    // Start date and End Date get converted to format yyyy-MM-dd
    if(startDate  && endDate ) {
      announcementUrl = announcementUrl + "?" + "dateFrom=" + startDate.toISOString().slice(0,10) + "&dateTo=" + endDate.toISOString().slice(0,10);
    }

    var promise = $http({method: 'GET', url: announcementUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  announcementService.postAnnouncements = function(announcementsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('announcementUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: announcementsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  return announcementService;

}]);