ccwgApp.service('userService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var userService = {};


  userService.getUsers = function() {
  
    var promise = $http({method: 'GET', url: envService.read('userUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.getApprovers = function() {
  
    var promise = $http({method: 'GET', url: envService.read('userUrl') +  "/approvers"});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  userService.postUsers = function(usersJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('userUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: usersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  userService.getUserFilters = function(userId) {

    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";
  
    var promise = $http({method: 'GET', url: userFilterUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.postUserFilters = function(userFiltersJson, userId) {
    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";

    var promise = $http({ 
                          method: 'POST', 
                          url: userFilterUrl,
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: userFiltersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  userService.deleteUserFilters = function(userFiltersJson, userId) {
    var userFilterUrl = envService.read('userUrl') + "/" + userId + "/userFilters";

    console.log(userFiltersJson);

    var promise = $http({ 
                          method: 'DELETE', 
                          url: userFilterUrl,
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: userFiltersJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  

  return userService;

}]);