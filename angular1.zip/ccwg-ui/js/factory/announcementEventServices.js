ccwgApp.service('announcementEventService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var announcementEventService = {};

  announcementEventService.getAnnouncementEvents = function() {

    var promise = $http({method: 'GET', url: envService.read('announcementEventUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  announcementEventService.postAnnouncementEvents = function(announcementEventsJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('announcementEventUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: announcementEventsJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  return announcementEventService;

}]);
