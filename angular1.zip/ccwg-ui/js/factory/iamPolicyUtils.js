ccwgApp.service('iamPolicyUtil', ['$filter', function($filter) {

  var iamPolicyUtil = {}

  iamPolicyUtil.generateConsolidatedPolicy = function(alternateDetailedPolicyConfigs) {
    var consolidatedPolicy = {};
    consolidatedPolicy.Version = "2012-10-17";
    consolidatedPolicy.Statement = [];

    var uniqueResourceCondition = [];
    var type2DeviationAllowActions = [];

    console.log("AlternateDetailed Policy Configs: ", alternateDetailedPolicyConfigs);
    
    alternateDetailedPolicyConfigs.forEach(function(policyConfig) {

        // If type2 deviations then add them under seperate bucket.
        if(policyConfig.deviation === 'type2' && policyConfig.publishAction === 'Allow') {
            type2DeviationAllowActions.push(policyConfig.actionName);

        } else {
            var exists = false;
            uniqueResourceCondition.forEach(function(value) {
                if(JSON.stringify(value.condition) === JSON.stringify(policyConfig.condition) && 
                    arrayEquals(value.resources, policyConfig.resources)) {                
                    exists = true;
                    // Only if publish action is Allow add it to the policy file
                    if(policyConfig.publishAction === 'Allow') {
                        value.actions.push(policyConfig.actionName);
                    }
                    
                }
            });

            if(!exists) {            
                uniqueResourceCondition.push({
                    condition: policyConfig.condition, 
                    resources: policyConfig.resources === null ? ['*'] : policyConfig.resources,
                    sid: policyConfig.sid,
                    publishAction: 'Allow',
                    actions: policyConfig.publishAction === 'Allow' ? new Array(policyConfig.actionName) : []
                });                        
            }
        }

    });

    // Adding type2 deviation configs
    if(type2DeviationAllowActions.length > 0) {
        uniqueResourceCondition.push({
            condition: null, 
            resources: ['*'],
            sid: 'Non_Compliant_Type2',
            publishAction: 'Allow',
            actions: type2DeviationAllowActions
        });
    };

    //console.log("Unique Resource C's: ", uniqueResourceCondition);
    uniqueResourceCondition.forEach(function(value) {
        var statement = {};
        statement.Sid = value.sid;
        statement.Effect = 'Allow';
        statement.Action = value.actions;
        statement.Resource = value.resources;
        statement.Condition = value.condition;

        consolidatedPolicy.Statement.push(statement);
    });

    return consolidatedPolicy;
  };

  iamPolicyUtil.generateManagedPolicy = function(managedDetailedPolicyConfigs) {

    var managedPolicy  = {};
    managedPolicy.Version = "2012-10-17";
    managedPolicy.Statement = [];

    var dateString = $filter('date')(new Date(), "yyyyMMdd");

    var compliantStatement = {};
    compliantStatement.Sid = 'Compliant' + dateString;
    compliantStatement.Effect = 'Allow';
    compliantStatement.Action = [];
   
    managedDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'compliant' && compliantStatement.Action.indexOf(config.actionName) === -1 ) {
        compliantStatement.Action.push(config.actionName);
      };
    });

    //compliantStatement.Resource = ['*'];
    compliantStatement.Resource = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].resources : ['*'];
    compliantStatement.Condition = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].condition : null;
    

    managedPolicy.Statement.push(compliantStatement);

    var nonCompliantType1Statement = {};
    nonCompliantType1Statement.Sid = 'NonCompliantType1' + dateString;
    nonCompliantType1Statement.Effect = 'Allow';
    nonCompliantType1Statement.Action = [];

    managedDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type1' && nonCompliantType1Statement.Action.indexOf(config.actionName) === -1) {
        nonCompliantType1Statement.Action.push(config.actionName);
      };
    });

    //nonCompliantType1Statement.Resource = ['*'];
    nonCompliantType1Statement.Resource = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].resources : ['*'];
    nonCompliantType1Statement.Condition = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].condition : null;
    

    managedPolicy.Statement.push(nonCompliantType1Statement);

    var nonCompliantType2Statement = {};
    nonCompliantType2Statement.Sid = 'NonCompliantType2' + dateString;
    nonCompliantType2Statement.Effect = 'Allow';
    nonCompliantType2Statement.Action = [];

    managedDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type2' && nonCompliantType2Statement.Action.indexOf(config.actionName) === -1) {
        nonCompliantType2Statement.Action.push(config.actionName);
      };
    });

    //nonCompliantType2Statement.Resource = ['*'];
    nonCompliantType2Statement.Resource = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].resources : ['*'];
    nonCompliantType2Statement.Condition = managedDetailedPolicyConfigs.length > 0 ? managedDetailedPolicyConfigs[0].condition : null;
    

    managedPolicy.Statement.push(nonCompliantType2Statement);
/*
    var nonCompliantType2DenyStatement = {};
    nonCompliantType2DenyStatement.Sid = 'NonCompliantType2Deny' + dateString;
    nonCompliantType2DenyStatement.Effect = 'Deny';
    nonCompliantType2DenyStatement.Action = [];

    managedDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type2' && nonCompliantType2DenyStatement.Action.indexOf(config.actionName) === -1) {
        nonCompliantType2DenyStatement.Action.push(config.actionName);
      };
    });

    nonCompliantType2DenyStatement.Resource = ['*'];

    managedPolicy.Statement.push(nonCompliantType2DenyStatement);
*/

    return managedPolicy;
  };


  iamPolicyUtil.generateInlinePolicy = function(inlineDetailedPolicyConfigs) {
    var inlinePolicy  = {};
    inlinePolicy.Version = "2012-10-17";
    inlinePolicy.Statement = [];

    var dateString = $filter('date')(new Date(), "yyyyMMdd");

    var compliantStatement = {};
    compliantStatement.Sid = 'Compliant' + dateString;
    compliantStatement.Effect = 'Allow';
    compliantStatement.Action = [];

    inlineDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'compliant') {
        compliantStatement.Action.push(config.actionName);
      };
    });

    compliantStatement.Resource = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].resources : ['*'];
    compliantStatement.Condition = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].condition : null;
    
    inlinePolicy.Statement.push(compliantStatement);

    var nonCompliantType1Statement = {};
    nonCompliantType1Statement.Sid = 'NonCompliantType1' + dateString;
    nonCompliantType1Statement.Effect = 'Allow';
    nonCompliantType1Statement.Action = [];

    inlineDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type1') {
        nonCompliantType1Statement.Action.push(config.actionName);
      };
    });

    nonCompliantType1Statement.Resource = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].resources : ['*'];
    nonCompliantType1Statement.Condition = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].condition : null;
    
    inlinePolicy.Statement.push(nonCompliantType1Statement);

    var nonCompliantType2Statement = {};
    nonCompliantType2Statement.Sid = 'NonCompliantType2' + dateString;
    nonCompliantType2Statement.Effect = 'Allow';
    nonCompliantType2Statement.Action = [];

    inlineDetailedPolicyConfigs.forEach(function(config) {
      if(config.deviation === 'type2') {
        nonCompliantType2Statement.Action.push(config.actionName);
      };
    });

    nonCompliantType2Statement.Resource = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].resources : ['*'];
    nonCompliantType2Statement.Condition = inlineDetailedPolicyConfigs.length > 0 ? inlineDetailedPolicyConfigs[0].condition : null;
    
    inlinePolicy.Statement.push(nonCompliantType2Statement);

    return inlinePolicy;
  };

  var arrayEquals = function(a, b) {
    if(a == b ) return true;
    if(a == null || b == null) return false;
    if(a.length != b.length) return false;

    a.sort();
    b.sort();

    for (var i = 0; i < a.length; ++i) {
        if (a[i] !== b[i]) return false;
    }

    return true;
  };

  return iamPolicyUtil;
}]);