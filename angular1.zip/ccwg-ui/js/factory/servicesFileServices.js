ccwgApp.service('servicesFileService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var servicesFileService = {}
  
  servicesFileService.getSampleServiceBulkUploadFile = function() {

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('serviceSampleBulkUploadUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  servicesFileService.getServiceBulkUploadFileInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceBulkUploadFileInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  servicesFileService.getServiceBulkUploadFiles = function(fileIds) {

    var fileIdsQueryString = "?";

    fileIds.forEach(function(fileId) {
      fileIdsQueryString = fileIdsQueryString + "fileIds=" + fileId + "&";
    });

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('serviceBulkUploadFilesDownloadUrl') + fileIdsQueryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  return servicesFileService;

}]);