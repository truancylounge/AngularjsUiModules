
ccwgApp.service('serviceRest', ['$http', '$q', 'envService', function($http, $q, envService) {

  var serviceRest = {}
  serviceRest.getServices = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  serviceRest.getServiceApiActions = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceApiActionUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };  


  serviceRest.getAllActiveServiceNames = function() {

    var serviceNamesUrl = envService.read('serviceUrl') + "/names";

    var promise = $http({method: 'GET', url: serviceNamesUrl });
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  serviceRest.getServiceById = function(id) {

    var promise = $http({method: 'GET', url: envService.read('serviceUrl') + "/" + id});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  serviceRest.postServices = function(servicesJson) {

    console.log("Entering post service: ");

    console.log("Service Json: ", servicesJson);
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('serviceUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: servicesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  return serviceRest;

}]);