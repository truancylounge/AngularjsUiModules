ccwgApp.service('privilegeService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var privilegeService = {};

  privilegeService.getPrivilegesCount = function(roleIds, serviceIds, environments) {

    var rolesQueryString = "";
    var servicesQueryString = "";
    var envQueryString = "";

    roleIds.forEach(function(roleId) {
      rolesQueryString = rolesQueryString + "roles=" + roleId + "&";
    });
    // Remove the last &
    rolesQueryString = rolesQueryString.slice(0, -1);

    serviceIds.forEach(function(serviceId) {
      servicesQueryString = servicesQueryString + "services=" + serviceId + "&";
    });

    environments.forEach(function(env) {
      envQueryString = envQueryString + "envs=" + env + "&";
    });
    // Remove the last &
    //servicesQueryString = servicesQueryString.slice(0, -1);

    var queryString = "?";
    if(rolesQueryString !== "")
      queryString = queryString + rolesQueryString + "&";

    if(servicesQueryString !== "")
      queryString = queryString + servicesQueryString + "&";

    if(envQueryString !== "")
      queryString = queryString + envQueryString;

    var filterUrl = envService.read('privilegeCountUrl') + queryString;
    console.log("Filter Count Url: " + filterUrl );

    var promise = $http({method: 'GET', url: filterUrl });
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;    

  };

  privilegeService.getPrivilegesUsingFilter = function(roleIds, serviceIds, environments, pageNumber, pageSize) {
    var rolesQueryString = "";
    var servicesQueryString = "";
    var envQueryString = "";

    roleIds.forEach(function(roleId) {
      rolesQueryString = rolesQueryString + "roles=" + roleId + "&";
    });
    // Remove the last &
    rolesQueryString = rolesQueryString.slice(0, -1);

    serviceIds.forEach(function(serviceId) {
      servicesQueryString = servicesQueryString + "services=" + serviceId + "&";
    });

    environments.forEach(function(env) {
      envQueryString = envQueryString + "envs=" + env + "&";
    });
    // Remove the last &
    //servicesQueryString = servicesQueryString.slice(0, -1);

    var queryString = "?";
    if(rolesQueryString !== "")
      queryString = queryString + rolesQueryString + "&";

    if(servicesQueryString !== "")
      queryString = queryString + servicesQueryString + "&";

    if(envQueryString !== "")
      queryString = queryString + envQueryString + "&";

    queryString = queryString + "pageNumber=" + pageNumber + "&pageSize=" + pageSize;



    var filterUrl = envService.read('privilegeUrl') + queryString;
    console.log("Filter Url: " + filterUrl );

    var promise = $http({method: 'GET', url: filterUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
    
  };

  privilegeService.getPrivileges = function(pageNumber, pageSize) {
    var paginatedUrl = envService.read('privilegeUrl') + "?pageNumber=" + pageNumber + "&pageSize=" + pageSize;

    var promise = $http({method: 'GET', url: paginatedUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeService.getPrivilegeDeltasForAwsAccount = function(awsAccountId) {
    var deltasUrl = envService.read('privilegeUrl') + "/deltas/" + awsAccountId;

    var promise = $http({method: 'GET', url: deltasUrl});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  privilegeService.postPrivileges = function(privilegesJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('privilegeUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: privilegesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  return privilegeService;

}]);
