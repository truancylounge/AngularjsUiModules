ccwgApp.service('iamPolicyService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var iamPolicyService = {};

  iamPolicyService.getIamPolicy = function(roleId, serviceId, awsAccountId ) {

    var queryString = "?roleId=" + roleId + "&serviceId=" + serviceId +  "&awsAccountId=" + awsAccountId; 

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.getIamPoliciesByRoleId = function(roleId, serviceIds, awsAccountId ) {

    var queryString = "/composite?roleId=" + roleId + "&awsAccountId=" + awsAccountId; 

    serviceIds.forEach(function(serviceId) {
      queryString = queryString + "&serviceIds=" + serviceId;
    });

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.postDetailedPolicyConfigsWC = function(policyConfigsWcJson) {
    
    console.log("Saved policy configs: ", policyConfigsWcJson);

    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('iamPolicyWorkingCopyUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: policyConfigsWcJson
                      });


    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.getManagedDetailedPolicyConfigs = function(iamRole, awsAccountId, fromCloud ) {
    
    var queryString = "/detailedPolicyConfigs/managed?iamRole=" + iamRole + "&awsAccountId=" + awsAccountId +"&cloud=" + fromCloud;

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.getInlineDetailedPolicyConfigs = function(iamRole, awsAccountId, fromCloud ) {

    var queryString = "/detailedPolicyConfigs/inline?iamRole=" + iamRole + "&awsAccountId=" + awsAccountId + "&cloud=" + fromCloud;

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.getManagdPolicies = function(iamRole, awsAccountId ) {

    var queryString = "/managed?iamRole=" + iamRole + "&awsAccountId=" + awsAccountId;

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  iamPolicyService.getInlinePolicies = function(iamRole, awsAccountId ) {

    var queryString = "/inline?iamRole=" + iamRole + "&awsAccountId=" + awsAccountId;

    var promise = $http({method: 'GET', url: envService.read('iamPolicyUrl') + queryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  return iamPolicyService;

}]);