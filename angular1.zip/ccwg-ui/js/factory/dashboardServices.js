ccwgApp.service('dashboardService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var dashboardService = {}
  dashboardService.getServiceInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('dashboardServiceInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  dashboardService.getApiActionInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('dashboardApiActionInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  dashboardService.getRolesInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('dashboardRolesInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };


  dashboardService.getPrivilegeInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('dashboardPrivilegeInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  dashboardService.getPrivilegeRequestSummary = function() {

    var promise = $http({method: 'GET', url: envService.read('dashboardPrivilegeRequestSummaryUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  dashboardService.getDashboardAnnouncements = function(startDate, endDate) {
    var announcementUrl = envService.read('dashboardAnnouncementsUrl');

    // Start date and End Date get converted to format yyyy-MM-dd
    if(startDate  && endDate ) {
      announcementUrl = announcementUrl + "?" + "dateFrom=" + startDate.toISOString().slice(0,10) + "&dateTo=" + endDate.toISOString().slice(0,10);
    } 

    var promise = $http({method: 'GET', url: announcementUrl });
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  return dashboardService;

}]);