ccwgApp.service('roleService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var roleService = {}
  roleService.getRoles = function() {

    var promise = $http({method: 'GET', url: envService.read('roleUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  roleService.postRoles = function(rolesJson) {
    var promise = $http({ 
                          method: 'POST', 
                          url: envService.read('roleUrl'),
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          data: rolesJson
                      });

    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };
  return roleService;

}]);