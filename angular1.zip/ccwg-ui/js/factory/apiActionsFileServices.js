ccwgApp.service('apiActionsFileService', ['$http', '$q', 'envService', function($http, $q, envService) {

  var apiActionsFileService = {}

  apiActionsFileService.getSampleServiceApiActionBulkUploadFile = function() {

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('serviceApiActionSampleBulkUploadUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;
  };

  apiActionsFileService.getServiceApiActionBulkUploadFileInfo = function() {

    var promise = $http({method: 'GET', url: envService.read('serviceApiActionBulkUploadFileInfoUrl')});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  apiActionsFileService.getServiceApiActionBulkUploadFiles = function(fileIds) {

    var fileIdsQueryString = "?";

    fileIds.forEach(function(fileId) {
      fileIdsQueryString = fileIdsQueryString + "fileIds=" + fileId + "&";
    });

    var promise = $http({method: 'GET', responseType: 'arraybuffer', url: envService.read('serviceApiActionBulkUploadFilesDownloadUrl') + fileIdsQueryString});
    var deferObject = deferObject || $q.defer();

    promise.then(
      function(response) {
        deferObject.resolve(response);
      },
      function(response) {
        deferObject.reject(response);
      });

    return deferObject.promise;

  };

  return apiActionsFileService;

}]);