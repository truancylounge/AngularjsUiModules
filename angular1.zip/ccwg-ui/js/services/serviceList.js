ccwgApp.controller('ServiceListController', ['$scope', '$uibModal', '$location', 'serviceRest', 'envService', '$sessionStorage', 'lookupService',
      function($scope, $uibModal, $location, serviceRest, envService, $sessionStorage, lookupService) {

    $scope.services = [];

    $scope.serviceProviders = [];
    $scope.serviceStates = [];
    $scope.evaluationPriorities = [];  

    $scope.sortType = 'updatedDate'; // set the default sort type
    $scope.sortReverse  = true;  // set the default sort order
    
    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after services have been saved
    $scope.showSuccessAlert = false;
    $scope.savedServicesCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showServicesSpinner = false;

    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedServicesCount = 0;
    };

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
    };



    $scope.showServiceEvaluations = function(service) {
      console.log("Navigate to Service Evaluation for Service with id : " + service.id);
      $location.path('/awsServiceEvaluations/'+ service.id);
    };

    $scope.showServiceApiActions = function(service) {
      console.log("Navigate to Service Api Action for Service with id : " + service.id);
      $location.path('/awsServiceApiActions/'+ service.id);
    };    

    $scope.retrieveAllServices = function() {
      $scope.showServicesSpinner = true;

      serviceRest.getServices()
        .then(
          function(response) {
            // If User has Admin roles, show all the Services else, show only unArchived services
            if($.inArray('Admin', $sessionStorage.user.permissions) !== -1) {
              $scope.services = response.data;
            } else {
              response.data.forEach(function(serviceEntity) {
                if(serviceEntity.isActive === true) {
                  $scope.services.push(serviceEntity);
                }                
              });
            };

            $scope.showServicesSpinner = false;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            $scope.serviceProviders = response.cloudServiceProviders;
            $scope.serviceStates = response.serviceStates;
            $scope.evaluationPriorities = response.evaluationPriorities;  
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };

    $scope.activeClicked = function() {
      console.log("Active Button Status : " + $scope.activeButtonStatus);
    };

    $scope.activeFilter = function (service) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return service;
          case 'off':
            return service.isActive == false;
          case 'on':
            return service.isActive == true;
        }
    };

    $scope.dirtyRecordFilter = function(role) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return role;
          case 'on':
            return role.action === 'U' || role.action === 'I';
        }

    };    

    $scope.serviceAttributesOpen = function(i) {
      //console.log("Entering service Attributes Modal");
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/services/serviceAttributesModal.html',
        controller: 'ServiceAttributesModalController',
        resolve: {
          service: function(){ return i;}
        }
      });
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through services to find out if service has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.services.forEach(function(service) {
        if(service.action === 'U' || service.action === 'I') {
          enable = true;
        };
      });

      return enable;
    };    

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.services.some(function(service) {
        if(service.id === i.id) {
          service.action = 'U';
        };
      });    
    };
    
    $scope.revertServices = function() {
      console.log("Reverting services back to original copy from server.")
      $scope.retrieveAllServices();
    };

    $scope.addServiceOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/services/addServiceModal.html',
        controller: 'AddServiceModalController',
        resolve: {
          services: function() { return $scope.services;},
          serviceProviders: function() { return $scope.serviceProviders;},
          serviceStates: function() {return $scope.serviceStates;},
          evaluationPriorities: function() { return $scope.evaluationPriorities; }
        }
      });
    };

    $scope.editServiceOpen = function(i, size) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/services/editServiceModal.html',
        controller: 'EditServiceModalController',
        size: size,
        resolve: {
          editService: function(){ return i;},
          services: function() { return $scope.services;},
          serviceProviders: function() { return $scope.serviceProviders;},
          serviceStates: function() {return $scope.serviceStates;},
          evaluationPriorities: function() { return $scope.evaluationPriorities; }
        }
      });
    };

    $scope.exportExcelFile = function() {
      console.log("Export data into Excel.");
      //var exportedServices = $.extend({}, $scope.filteredServices);
      var exportedServices = [];
      $scope.filteredServices.forEach(function(service) {
        exportedServices.push(_update(service, {}));
      });
      
      alasql('SELECT * INTO XLSX("services.xlsx",{headers:true}) FROM ?',[exportedServices]);
      console.log(exportedServices);
    };

    function _update(srcObj, destObj) {
      for (var key in srcObj) {
        console.log("Type of Key: ", key,  typeof srcObj[key] );
        if(srcObj.hasOwnProperty(key) && typeof srcObj[key] !== 'object') {
          destObj[key] = srcObj[key];
        }
      }
      return destObj;
    }


    $scope.updateServices = function() {
      var updatedServices = [];

      $scope.services.forEach(function(service) {
        if(service.action === 'U' || service.action === 'I') {
          updatedServices.push(service);
        }
      });

      serviceRest.postServices(updatedServices)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.savedServicesCount = updatedServices.length;

            $scope.retrieveAllServices();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };

    $scope.retrieveAllServices(); // Call the serviceRest.getServices() GET method    
}]);