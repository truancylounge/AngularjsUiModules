ccwgApp.controller('ServiceBulkUploadController', ['$scope', '$uibModal', 'FileUploader', 'envService', 'usSpinnerService', 'servicesFileService', '$sessionStorage', 
    function($scope, $uibModal, FileUploader, envService, usSpinnerService, servicesFileService, $sessionStorage) {

    $scope.servicesBulkUploadFilesInfo = [];
    $scope.selectedFilesIds = [];

    // Status of file Uploads
    $scope.fileUploadSummary = [];

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    $scope.getUserName = function(userId) {
        var userName;
         if(userId !== undefined) {
            $sessionStorage.users.some(function(user) {
              if(user.userId.toUpperCase() === userId.toUpperCase()) 
                userName = user.userName;
            });
          }

        return userName;
    };  

    $scope.sampleFileDownload = function() {

        servicesFileService.getSampleServiceBulkUploadFile()
            .then(
                function(response) {
                    var type = response.headers('Content-Type');
                    var disposition = response.headers('Content-Disposition');
                    var defaultFileName = "";
                    console.log(disposition);
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    console.log(defaultFileName);
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    console.log("DefaultFileName : " + defaultFileName);

                    var blob = new Blob([response.data], {type: type});
                    saveAs(blob, defaultFileName);
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
            );
    };

/* File Uploader code */

    var uploader = $scope.uploader = new FileUploader({
        url: envService.read('serviceBulkUploadUrl'),
        alias: 'uploadFile',        
        headers: {
            //'sAMAccountName': "K25850"
        },
        //queueLimit: 1,
        removeAfterUpload : true        
    });



    // CALLBACKS

    uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
        console.info('onWhenAddingFileFailed', item, filter, options);
    };
    uploader.onAfterAddingFile = function(fileItem) {
        console.info('onAfterAddingFile', fileItem);
    };
    uploader.onAfterAddingAll = function(addedFileItems) {
        console.info('onAfterAddingAll', addedFileItems);
        // Initialize the bulk upload files collection to empty
        //$scope.privsBulkUploadFilesInfo = [];    
    };
    uploader.onBeforeUploadItem = function(item) {
        console.info('onBeforeUploadItem', item);
        if(item.comments !== undefined) {
            item.formData.push({'comments': item.comments});
        }
    };
    uploader.onProgressItem = function(fileItem, progress) {
        console.info('onProgressItem', fileItem, progress);
    };
    uploader.onProgressAll = function(progress) {
        console.info('onProgressAll', progress);
        usSpinnerService.spin('bulkUploadSpinner');
    };
    uploader.onSuccessItem = function(fileItem, response, status, headers) {
        console.info('onSuccessItem', fileItem, response, status, headers);
        // Make a call to retrieve all the service bulk upload files
        $scope.retrieveServicesBulkUploadFilesInfo();
    };
    uploader.onErrorItem = function(fileItem, response, status, headers) {
        console.info('onErrorItem', fileItem, response, status, headers);
    };
    uploader.onCancelItem = function(fileItem, response, status, headers) {
        console.info('onCancelItem', fileItem, response, status, headers);
    };
    uploader.onCompleteItem = function(fileItem, response, status, headers) {
        console.info('onCompleteItem', fileItem, response, status, headers);
        var uploadStatus = (status === 200) ? "Success" : "Failure";
        var errorMessage = {};
        if(status !== 200) {
            errorMessage.errorCode = response.code;
            errorMessage.developerMsg = response.developerMessage;
            errorMessage.msg = response.message;
        }

        $scope.fileUploadSummary.push({
            'fileName': fileItem.file.name,
            'status': uploadStatus,
            'errorCode': errorMessage.errorCode,
            'developerMessage': errorMessage.developerMsg,
            'errorMessage': errorMessage.msg
        });
    };
    uploader.onCompleteAll = function() {
        console.info('onCompleteAll');
        usSpinnerService.stop('bulkUploadSpinner');
        console.log("FileUpload Summary: ", $scope.fileUploadSummary);
        $scope.fileUploadSummaryOpen($scope.fileUploadSummary);
        $scope.fileUploadSummary = [];
    };

    $scope.fileUploadSummaryOpen = function(summary) {
        console.log("Display file Upload Summary");
        var modalInstance = $uibModal.open({
            templateUrl: 'html/bulkFileUpload/fileUploadSummary.html',
            controller: 'FileUploadSummaryController',
            resolve: {
              uploadSummary: function(){ return summary;}
            },
            size: 'lg'
        });
    };


/* Services Bulk Upload File Display Code */

    $scope.retrieveServicesBulkUploadFilesInfo = function() {
        
        console.log("Retrieving Services Bulk Upload Files data");

        servicesFileService.getServiceBulkUploadFileInfo()
            .then(
                function(response) {
                    $scope.selectedFilesIds= [];
                    $scope.servicesBulkUploadFilesInfo = response.data;                    
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
            );

    };

    $scope.downloadServiceBulkUploadFiles = function() {
        console.log("Retrieving files with ids : ", $scope.selectedFilesIds);

        servicesFileService.getServiceBulkUploadFiles($scope.selectedFilesIds)
            .then(
                function(response) {
                    // Resetting the checkbox modals, coz we are refreshing the files from the DB.
                    console.log('resetting checkbox modelas');
                    $scope.selectedFilesIds = [];

                    // We uncheck the checkbox after the file download has been completed
                    $scope.servicesBulkUploadFilesInfo.forEach(function(value) {
                        value.checked = false;
                    });

                    var type = response.headers('Content-Type');
                    var disposition = response.headers('Content-Disposition');
                    var defaultFileName = "";
                    if (disposition) {
                        var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                        if (match[1])
                            defaultFileName = match[1];
                    }
                    defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                    
                    var blob = new Blob([response.data], {type: type});
                    saveAs(blob, defaultFileName);
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
            );
    };


    $scope.isDownloadButtonValid = function() {
        return $scope.selectedFilesIds.length > 0 ? true : false
    };

    $scope.updateSelected = function(action, id) {
        // Selected file id doesn't exist in the selected list, add the id
        if(action === 'add' & $scope.selectedFilesIds.indexOf(id) === -1) {
            $scope.selectedFilesIds.push(id)
        };

        if(action === 'remove' && $scope.selectedFilesIds.indexOf(id) !== -1) {
            $scope.selectedFilesIds.splice($scope.selectedFilesIds.indexOf(id), 1);
        }

    };

    $scope.selectedFileEntry = function($event, i) {
        var action = ($event.target.checked ? 'add' : 'remove');
        $scope.updateSelected(action, i.id);
    };



    $scope.retrieveServicesBulkUploadFilesInfo();







}]);