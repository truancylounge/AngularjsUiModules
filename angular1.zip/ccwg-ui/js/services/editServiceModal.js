ccwgApp.controller('EditServiceModalController', ['$scope', '$uibModalInstance', 'editService', 'services', 'serviceProviders', 'serviceStates' , 'evaluationPriorities', function($scope, $uibModalInstance, editService, services, serviceProviders, serviceStates, evaluationPriorities ) {
  
  $scope.serviceProviders = serviceProviders;
  $scope.serviceStates = serviceStates;
  $scope.evaluationPriorities = evaluationPriorities;  

  $scope.serviceNameShort = editService.serviceNameShort;
  $scope.serviceNameLong = editService.serviceNameLong;
  $scope.serviceDescription = editService.serviceDescription;
  $scope.refPrimaryFinra = editService.refPrimaryFinra;
  $scope.refAlternateFinra1 = editService.refAlternateFinra1;
  $scope.refPrimaryVendor = editService.refPrimaryVendor;
  $scope.refAlternateVendor1 = editService.refAlternateVendor1;
  $scope.refAlternateVendor2 = editService.refAlternateVendor2;
  $scope.serviceProvider = editService.cloudServiceProvider;
  $scope.serviceState = editService.serviceState;
  $scope.evaluationPriority = editService.evaluationPriority;

  $scope.editService = function() {
    // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
    services.some(function(service) {
      if(service.id === editService.id) {
        service.serviceNameShort = $scope.serviceNameShort;
        service.serviceNameLong = $scope.serviceNameLong;
        service.serviceDescription = $scope.serviceDescription;
        service.refPrimaryFinra = $scope.refPrimaryFinra;
        service.refAlternateFinra1 = $scope.refAlternateFinra1;
        service.refPrimaryVendor = $scope.refPrimaryVendor;
        service.refAlternateVendor1 = $scope.refAlternateVendor1;
        service.refAlternateVendor2 = $scope.refAlternateVendor2;
        service.cloudServiceProvider = $scope.serviceProvider;
        service.serviceState = $scope.serviceState;
        service.evaluationPriority = $scope.evaluationPriority;        
        service.action = 'U';
      };
    });       

    $uibModalInstance.close();

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
}]);

ccwgApp.controller('AddServiceModalController', ['$scope', '$uibModalInstance', 'services', 'serviceProviders', 'serviceStates', 'evaluationPriorities', function($scope, $uibModalInstance, services, serviceProviders, serviceStates, evaluationPriorities ) {
  
  $scope.serviceProviders = serviceProviders;
  $scope.serviceStates = serviceStates;
  $scope.evaluationPriorities = evaluationPriorities;    

  $scope.serviceNameShort;
  $scope.serviceNameLong;
  $scope.serviceDescription;
  $scope.refPrimaryFinra;
  $scope.refAlternateFinra1;
  $scope.refPrimaryVendor;
  $scope.refAlternateVendor1;
  $scope.refAlternateVendor2;
  $scope.serviceProvider;
  $scope.serviceState;
  $scope.evaluationPriority;

  $scope.addService = function() {
    services.push({
      "cloudServiceProvider": $scope.serviceProvider, 
      "serviceNameShort": $scope.serviceNameShort,
      "serviceNameLong": $scope.serviceNameLong,
      "serviceState": $scope.serviceState,
      "serviceDescription": $scope.serviceDescription,
      "refPrimaryFinra": $scope.refPrimaryFinra,
      "refAlternateFinra1": $scope.refAlternateFinra1,
      "refPrimaryVendor": $scope.refPrimaryVendor,
      "refAlternateVendor1": $scope.refAlternateVendor1,
      "refAlternateVendor2": $scope.refAlternateVendor2,
      "evaluationPriority": $scope.evaluationPriority,
      "action": "I",
      "isActive": true
    });   

    $uibModalInstance.close();

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  }; 
}]);