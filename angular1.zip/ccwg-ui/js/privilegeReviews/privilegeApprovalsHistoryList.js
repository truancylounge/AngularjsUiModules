ccwgApp.controller('PrivilegeApprovalsHistoryListController', ['$scope', '$rootScope', 'privilegeReviewService', 'serviceRest', 'envService', '$uibModal', '$sessionStorage', 'awsAccountService', '$location', 
  function($scope, $rootScope, privilegeReviewService, serviceRest, envService, $uibModal, $sessionStorage, awsAccountService, $location) {


    $scope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if(phase == '$apply' || phase == '$digest') {
        if(fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };


  	$scope.privilegeApprovalsHistory = [];
    $scope.sublistPrivilegeApprovalsHistory = [];
    $scope.privilegeApprovalRequestsHistory = [];
    $scope.activePrivilegeApprovalRequestHistory = 'All';

    $scope.serviceApiActionEntities = [];

    $scope.awsAccountEntities = [];

    // Array that stores Bulk Hisotry Approval Request titles ( privilege reviews > = 100)
    // contains requestTitle, justification, count & changeProposedDate
    $scope.bulkApprovalsHistoryInfo = [];

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    $scope.showPrivilegeApprovalHistorySpinner = false;

    // Creating a map between service name and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.serviceNameColumnIdMap = {};
    $scope.apiPrefixColumnIdMap = {};
    $scope.apiActionColumnIdMap = {};
    $scope.envColumnIdMap = {};
    $scope.roleNameColumnIdMap = {};
    $scope.accountNameColumnIdMap = {};

    // Help's us figure out which filter made the change
    // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env/ Role/ Account
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModified = {
      'serviceName': false,
      'apiPrefix': false,
      'actionGs': false,
      'env': false,
      'role': false,
      'account': false
    };


    $scope.getUserName = function(userId) {
        var userName;
        if(userId !== undefined) {
          $sessionStorage.users.some(function(user) {
            if(user.userId.toUpperCase() === userId.toUpperCase()) 
              userName = user.userName;
          });
        }        

        return userName;
    };  

    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettings = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };

    // ng-dropdown-multiselect event listeners
    $scope.serviceNameEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableServices.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': true,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }      
      }
    };

    $scope.apiPrefixEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableApiPrefix.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': true,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }
      }
    };

    $scope.actionGsEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableActionGs.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': true,
            'env': false,
            'role': false,
            'account': false
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }
      }
    };

    $scope.envEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableEnvs.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': true,
            'role': false,
            'account': false
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }
      }
    };

    $scope.roleEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableRoles.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': true,
            'account': false
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }
      }
    };

    $scope.accountEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableAccounts.length > 0) {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': true
          };
        } else {
          $scope.columnFilterModified = {
            'serviceName': false,
            'apiPrefix': false,
            'actionGs': false,
            'env': false,
            'role': false,
            'account': false
          };
        }
      }
    };

    // Column Service filter attributes
    $scope.selectedTableServices = [];   
    $scope.servicesData = [];     // Data that gets displayed on Column Service Filter
    // Column Service Api Prefix filter attributes
    $scope.selectedTableApiPrefix = [];   
    $scope.apiPrefixData = [];     // Data that gets displayed on Column Api Prefix Filter
    // Column ServiceApi Action filter attributes
    $scope.selectedTableActionGs = [];   
    $scope.serviceApiActionsData = [];     // Data that gets displayed on Column Service Api Action Filter
    // Column Envs filter attributes
    $scope.selectedTableEnvs = [];   
    $scope.envsData = [];     // Data that gets displayed on Column Envs Filter
    // Column Roles filter attributes
    $scope.selectedTableRoles = [];   
    $scope.rolesData = [];     // Data that gets displayed on Column Envs Filter
    $scope.selectedTableOriginal = []; // Selected Original Value from column filter
    $scope.selectedTableProposed = []; // Selected Proposed Value from column filter
    // Original Config also has Empty value, hence splitting config data into Original and Proposed
    $scope.configurationOriginalData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}, {id: 3, label: 'Empty'}];
    $scope.configurationProposedData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];
    
    $scope.selectedTableAccounts = [];   
    $scope.accountsData = [];     // Data that gets displayed on Column Envs Filter

    //date picker options
    $scope.dateFormat = 'dd-MMMM-yyyy';
    $scope.startDateOptions = {
      formatYear: 'yy',
      showWeeks: false,
      maxDate: new Date(2020, 5, 22),
      minDate: new Date(2010, 1, 22),
      startingDay: 1
    };

    $scope.endDateOptions = {
      formatYear: 'yy',
      showWeeks: false,
      maxDate: new Date(2020, 5, 22),
      minDate: new Date(2010, 1, 22),
      startingDay: 1
    };

    $scope.startDateCalender = {
      opened: false
    };

    $scope.endDateCalender = {
      opened: false
    };

    $scope.startDate = null;
    $scope.endDate = null;

    $scope.startDateOpen = function() {
      $scope.startDateCalender.opened = true;
    };

    $scope.endDateOpen = function() {
      $scope.endDateCalender.opened = true;
    };

    // Makes sure End date calender cannot select a date before start date if its set
    $scope.startDateSelected = function() {
      $scope.endDateOptions.minDate = $scope.startDate;
    };

    // Makes sure Start date calender cannot select a date after end date if its set
    $scope.endDateSelected = function() {
      $scope.startDateOptions.maxDate = $scope.endDate;
    }

    $scope.retrieveFinalizationHistory = function() {
      $scope.initialize();
    }

    /*
      Watch change to privilege approval history table results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('filteredEntries', function() {
      $scope.updateColumnFilterValuesOnChange(); 
    });

    /**
      We will be monitoring the $scope.privilegeApprovalsHistory and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.privilegeApprovalsHistory.length}, function() {      
      if($scope.privilegeApprovalsHistory.length > 0) {
        console.log('Privilege Approval History retrieved, initiating Table Population');
        $scope.initiateTablePopulation();        
      };
    });

    /**
      We will be monitoring the $scope.serviceApiActionEntities and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.serviceApiActionEntities.length}, function() {
      if($scope.serviceApiActionEntities.length > 0) {
        console.log('Service Api Action Entities Count reached, initiating Table Population');
        $scope.initiateTablePopulation();  
      }
    });

    $scope.showBulkApprovalHistoryRequestTitle = function(i) {
      $location.path('/bulkPrivilegeApprovalListHistory/'+ i.requestTitle);
    }

    // We initiate population after both $scope.privilegeApprovalHistory & $scope.serviceApiActionEntities have been retrieved
    $scope.initiateTablePopulation = function() {
      if($scope.privilegeApprovalsHistory.length > 0 && $scope.serviceApiActionEntities.length > 0) {
        console.log("Privilege Approvals History & ApiActionEntities have been retrieved. Start populating the Request titles pane");
        $scope.privilegeApprovalsHistory.forEach(function(privilegeApproval) {
          $scope.addRoleName(privilegeApproval); // Add a new property called RoleName based on ccwgRoleOrgId
          $scope.addAwsAccount(privilegeApproval); // Add a new property called AwsAccount based on ccwgFinraAwsAccountsId
          $scope.addServiceApiActionName(privilegeApproval); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
        });

        Array.prototype.push.apply($scope.sublistPrivilegeApprovalsHistory, angular.copy($scope.privilegeApprovalsHistory));

        $scope.createPrivilegeApprovalsRequestsHistory();  
        $scope.createSublistColumnTableFilter(); 
        $scope.showPrivilegeApprovalHistorySpinner = false;
      }
    };

    $scope.updateColumnFilterValuesOnChange = function() {
      // Resetting the Data that gets displayed on Serice/ApiPrefix/ApiAction/Env column filters
      var uniqueServiceNames = [];
      var uniqueApiPrefixes = [];
      var uniqueApiActions = [];
      var uniqueEnvs = [];
      var uniqueRoles = [];
      var uniqueAccounts = [];

      $scope.filteredEntries.forEach(function(filteredEntry) {
        // Create Unique Service Names as multiple filtered entries can have same Service names
        // Only peform this operation if user isn't accessing Service name column filter
        if($scope.columnFilterModified.serviceName === false && uniqueServiceNames.indexOf(filteredEntry.privilegeEntity.serviceNameShort) === -1) {
          uniqueServiceNames.push(filteredEntry.privilegeEntity.serviceNameShort);
        }      
        // Creating unique Api Prefixes as multiple filtered entries can have same api prefix
        // Only peform this operation if user isn't accessing Api Prefix column filter
        if($scope.columnFilterModified.apiPrefix === false && uniqueApiPrefixes.indexOf(filteredEntry.privilegeEntity.apiActionPrefix) === -1) {
          uniqueApiPrefixes.push(filteredEntry.privilegeEntity.apiActionPrefix);
        };
        // Creating Api Action Names
        // Only peform this operation if user isn't accessing Service Api Action column filter
        if($scope.columnFilterModified.actionGs === false && uniqueApiActions.indexOf(filteredEntry.privilegeEntity.apiActionName) === -1) {
          uniqueApiActions.push(filteredEntry.privilegeEntity.apiActionName);
        };      
        // Creating unique Envs as multiple filtered entries can have same Env
        // Only peform this operation if user isn't accessing Env column filter
        if($scope.columnFilterModified.env === false && uniqueEnvs.indexOf(filteredEntry.privilegeEntity.environment) === -1) {
          uniqueEnvs.push(filteredEntry.privilegeEntity.environment);
        }
        // Creating unique Roles as multiple filtered entries can have same role
        // Only peform this operation if user isn't accessing role column filter
        if($scope.columnFilterModified.role === false && uniqueRoles.indexOf(filteredEntry.privilegeEntity.roleName) === -1) {
          uniqueRoles.push(filteredEntry.privilegeEntity.roleName);
        }
        // Creating unique accounts as multiple filtered entries can have same account
        // Only peform this operation if user isn't accessing account column filter
        if($scope.columnFilterModified.account === false && uniqueAccounts.indexOf(filteredEntry.privilegeEntity.awsAccount) === -1) {
          uniqueAccounts.push(filteredEntry.privilegeEntity.awsAccount);
        }
      });

      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do servicesData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModified.serviceName === false) {
        $scope.servicesData = [];
        $scope.createServiceNameColumnFilterValues(uniqueServiceNames.sort());
      }
      if($scope.columnFilterModified.apiPrefix === false) {
        $scope.apiPrefixData = [];
        $scope.createApiPrefixColumnFilterValues(uniqueApiPrefixes.sort());
      }
      if($scope.columnFilterModified.actionGs === false) {
        $scope.serviceApiActionsData = [];
        $scope.createApiActionColumnFilterValues(uniqueApiActions.sort());
      }
      if($scope.columnFilterModified.env === false) {
        $scope.envsData = [];
        $scope.createEnvColumnFilterValues(uniqueEnvs.sort());
      }
      if($scope.columnFilterModified.role === false) {
        $scope.rolesData = [];
        $scope.createRoleColumnFilterValues(uniqueRoles.sort());
      }
      if($scope.columnFilterModified.account === false) {
        $scope.accountsData = [];
        $scope.createAccountColumnFilterValues(uniqueAccounts.sort());
      }
    };

    /*
      Creates Service Name column filter values. Initially we load all Service Names sorted.
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered Service Names are displayed
    */
    $scope.createServiceNameColumnFilterValues = function(sortedServiceNames) {
      $scope.servicesData = [];
      // Setting serviceData array for service column table filter
      sortedServiceNames.forEach(function(serviceName) {
        $scope.servicesData.push({
          id: $scope.serviceNameColumnIdMap[serviceName],
          label: serviceName
        });
      });
    };

    /*
      Creates Api Prefix column filter values. Initially we load all Api Prefixes sorted.
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered Api Prefixes are displayed
    */
    $scope.createApiPrefixColumnFilterValues = function(sortedUniqueApiPrefixes) {
      $scope.apiPrefixData = [];
      sortedUniqueApiPrefixes.forEach(function(apiPrefix) {
        $scope.apiPrefixData.push({
          id: $scope.apiPrefixColumnIdMap[apiPrefix],
          label: apiPrefix
        });
      });
    };

    /*
      Creates Api Action GS column filter values based on api actions in the table
      Initially we load all api action names sorted
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered api action names are displayed
    */

    $scope.createApiActionColumnFilterValues = function(sortedServiceApiActionNames) {
      $scope.serviceApiActionsData = [];
      sortedServiceApiActionNames.forEach(function(apiActionName) {
        $scope.serviceApiActionsData.push({
          id: $scope.apiActionColumnIdMap[apiActionName],
          label: apiActionName
        });
      });
    };

    /*
      Creates Environment column filter values based on rows in the table
      Initially we load all Envs sorted
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered envs are displayed
    */
    $scope.createEnvColumnFilterValues = function(sortedEnvs) {
      $scope.envsData = [];
      sortedEnvs.forEach(function(env) {
        $scope.envsData.push({
          id: $scope.envColumnIdMap[env],
          label: env
        });
      });
    };

    /*
      Creates Role column filter values based on rows in the table
      Initially we load all Roles sorted
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered Roles are displayed
    */
    $scope.createRoleColumnFilterValues = function(sortedRoles) {
      $scope.rolesData = [];
      sortedRoles.forEach(function(role) {
        $scope.rolesData.push({
          id: $scope.roleNameColumnIdMap[role],
          label: role
        });
      });
    };

    /*
      Creates Account column filter values based on rows in the table
      Initially we load all Accounts sorted
      Later if the table get's filtered then this method get's called from watchCollection method 
      and only filtered Accounts are displayed
    */
    $scope.createAccountColumnFilterValues = function(sortedAccounts) {
      $scope.accountsData = [];
      sortedAccounts.forEach(function(account) {
        $scope.accountsData.push({
          id: $scope.accountNameColumnIdMap[account],
          label: account
        });
      });
    };

    // Creates data for Column Filters from $scope.sublistPrivilegeApprovalsHistory
    $scope.createSublistColumnTableFilter = function() {
      // Setting serviceData array for service column table filter
      var uniqueServiceNames = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if(uniqueServiceNames.indexOf(privilegeApproval.privilegeEntity.serviceNameShort) === -1) {
          uniqueServiceNames.push(privilegeApproval.privilegeEntity.serviceNameShort);
        }
      });
      // Creating map between serviceName ~ uniqueId
      var serviceId = 1;      
      uniqueServiceNames.forEach(function(serviceName) {
        $scope.serviceNameColumnIdMap[serviceName] = serviceId++;
      });
      // Create sorted column filter values for Service Name
      $scope.createServiceNameColumnFilterValues(uniqueServiceNames.sort());

      // Setting apiPrefixData array for service column table filter
      var uniqueApiPrefixes = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if(uniqueApiPrefixes.indexOf(privilegeApproval.privilegeEntity.apiActionPrefix) === -1) {
          uniqueApiPrefixes.push(privilegeApproval.privilegeEntity.apiActionPrefix);
        }
      });
      // Creating map between apiPrefix ~ uniqueId
      var apiPrefixId = 1;
      uniqueApiPrefixes.forEach(function(apiPrefix) {
        $scope.apiPrefixColumnIdMap[apiPrefix] = apiPrefixId++; 
      });
      // Create sorted column filter values for Api Prefix
      $scope.createApiPrefixColumnFilterValues(uniqueApiPrefixes.sort());


      // Setting serviceApiActionData array for service Api Action table filter
      var uniqueApiActions = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if(uniqueApiActions.indexOf(privilegeApproval.privilegeEntity.apiActionName) === -1) {
          uniqueApiActions.push(privilegeApproval.privilegeEntity.apiActionName);
        }
      });

      var apiActionId = 1;
      uniqueApiActions.forEach(function(apiActionName) {
        $scope.apiActionColumnIdMap[apiActionName] = apiActionId++;
      });
      // Create sorted column filter values for Api Action
      $scope.createApiActionColumnFilterValues(uniqueApiActions.sort());   


      // Setting EnvsData array for Envs column table filter
      var uniqueEnvs = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if(uniqueEnvs.indexOf(privilegeApproval.privilegeEntity.environment) === -1) {
          uniqueEnvs.push(privilegeApproval.privilegeEntity.environment);
        }
      });

      var envId = 1;
      uniqueEnvs.forEach(function(env) {
        $scope.envColumnIdMap[env] = envId++;
      });
      // Create sorted column filter values for Environment
      $scope.createEnvColumnFilterValues(uniqueEnvs.sort());

      // Setting data for Roles column table filter
      var uniqueRoles = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if(uniqueRoles.indexOf(privilegeApproval.privilegeEntity.roleName) === -1) {
          uniqueRoles.push(privilegeApproval.privilegeEntity.roleName);
        }
      });
      var roleId = 1;
      uniqueRoles.forEach(function(role) {
        $scope.roleNameColumnIdMap[role] = roleId++;
      });
      $scope.createRoleColumnFilterValues(uniqueRoles.sort());

      // Setting data for Accounts column table filter
      var uniqueAccounts = [];
      $scope.sublistPrivilegeApprovalsHistory.forEach(function(privilegeApproval) {        
        if(privilegeApproval.privilegeEntity.ccwgFinraAwsAccountsId !== null && 
          uniqueAccounts.indexOf(privilegeApproval.privilegeEntity.awsAccount) === -1) {
          uniqueAccounts.push(privilegeApproval.privilegeEntity.awsAccount);
        }
      });
     
      var accountId = 1;
      uniqueAccounts.forEach(function(account) {
        $scope.accountNameColumnIdMap[account] = accountId++; 
      });
      $scope.createAccountColumnFilterValues(uniqueAccounts.sort());
    };

    $scope.clearColumnFilterAttributes = function() {
      console.log('Clear column filter attirbutes');
      $scope.selectedTableServices = [];
      $scope.selectedTableActionGs = [];
      $scope.selectedTableApiPrefix = [];
      $scope.selectedTableRoles = [];
      $scope.selectedTableEnvs = [];
      $scope.selectedTableOriginal = [];
      $scope.selectedTableProposed = [];
      $scope.selectedTableAccounts = [];
      $scope.searchKeyword = '';
    };


    $scope.columnServiceFilter = function(i) {
      var serviceNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableServices.length > 0) {
        $scope.selectedTableServices.forEach(function(selectedEntry) {
          serviceNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.serviceNameShort, serviceNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnApiPrefixFilter = function(i) {
      var apiPrefixes = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableApiPrefix.length > 0) {
        $scope.selectedTableApiPrefix.forEach(function(selectedEntry) {
          apiPrefixes.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionPrefix, apiPrefixes) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    $scope.columnServiceApiActionFilter = function(i) {
      var serviceApiActionNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableActionGs.length > 0) {
        $scope.selectedTableActionGs.forEach(function(selectedEntry) {
          serviceApiActionNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionName, serviceApiActionNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnEnvFilter = function(i) {
      var envNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableEnvs.length > 0) {
        $scope.selectedTableEnvs.forEach(function(selectedEntry) {
          envNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.environment, envNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnRoleFilter = function(i) {
      var roles = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableRoles.length > 0) {
        $scope.selectedTableRoles.forEach(function(selectedEntry) {
          roles.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.roleName, roles) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnAccountFilter = function(i) {
      var accounts = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableAccounts.length > 0) {
        $scope.selectedTableAccounts.forEach(function(selectedEntry) {
          accounts.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.awsAccount, accounts) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnOriginalValueFilter = function(i) {
      var originalValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableOriginal.length > 0) {
        $scope.selectedTableOriginal.forEach(function(selectedEntry) {
          originalValue.push(selectedEntry.label);
        });

        if($.inArray((i.fromValue === null ? 'Empty' : i.fromValue), originalValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    $scope.columnProposedValueFilter = function(i) {
      var proposedValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableProposed.length > 0) {
        $scope.selectedTableProposed.forEach(function(selectedEntry) {
          proposedValue.push(selectedEntry.label);
        });

        if($.inArray(i.toValue, proposedValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.privilegeReviewApprovalLogOpen = function(i) {
      console.log("Entering Privilege Review Approval log Modal");
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/privilegeReviews/privilegeApprovalsHistoryLogModal.html',
        controller: 'PrivilegeApprovalHistoryLogModalController',
        resolve: {
          logEntities: function(){ return i.privilegeReviewLogEntities;}
        }
      });   
    }

    $scope.addRoleName = function(privilegeApproval) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeApproval.privilegeEntity.ccwgRoleOrgId) { 
          privilegeApproval.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };  

    $scope.addAwsAccount = function(privilegeApproval) {
      $scope.awsAccountEntities.forEach(function(awsAccountEntity) {
        if(awsAccountEntity.id === privilegeApproval.privilegeEntity.ccwgFinraAwsAccountsId) { 
          privilegeApproval.privilegeEntity['awsAccount'] = awsAccountEntity.org + ":" + 
                                                            awsAccountEntity.accountName + ":" + 
                                                            awsAccountEntity.accountArn;
        }          
      });
    }
    
     $scope.addServiceApiActionName = function(privilegeApproval) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeApproval.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeApproval.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeApproval.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeApproval.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
          privilegeApproval.privilegeEntity['apiActionDescription'] = serviceApiActionEntity.apiActionDescription;
          privilegeApproval.privilegeEntity['apiActionReference'] = serviceApiActionEntity.apiActionReference;
        }          
      });
    };


    // Create privilege Approvals requests history array to be displayed on the sidebar view
    $scope.createPrivilegeApprovalsRequestsHistory = function() {
      var approvalRequestsHistory = [];

      $scope.privilegeApprovalsHistory.sort(function(a, b) {return new Date(b.reviewedDate).getTime() - new Date(a.reviewedDate).getTime() });


      // Create a unique list of requestTitles 
      $scope.privilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if (approvalRequestsHistory.indexOf(privilegeApproval.requestTitle) === -1) {
           approvalRequestsHistory.push(privilegeApproval.requestTitle);
        }
      });

      // Retrieve count of requestTitles and create privilegeApprovalsRequestsHistory
      approvalRequestsHistory.forEach(function(approvalRequest) {
        $scope.privilegeApprovalRequestsHistory.push({
          requestName: approvalRequest,
          justification: $scope.getPrivilegeApprovalsRequestsHistoryJustification(approvalRequest),
          requestCount: $scope.getPrivilegeApprovalsRequestsHistoryCount(approvalRequest)
        });
      });
    };

    $scope.getPrivilegeApprovalsRequestsHistoryCount = function(requestTitle) {
      var count = 0;

      $scope.privilegeApprovalsHistory.forEach(function(privilegeApproval) {
        if (privilegeApproval.requestTitle === requestTitle) {
           count++;
        }
      });

      return count;
    };

    $scope.getPrivilegeApprovalsRequestsHistoryJustification = function(requestTitle) {
      var justification = "";

      $scope.privilegeApprovalsHistory.some(function(privilegeApproval) {
        if (privilegeApproval.requestTitle === requestTitle) {
           justification = privilegeApproval.justification;
        }
      });

      return justification;
    }; 


    // Create a sublist of privilegeReviewRequestsHistory based on requestTitle
    $scope.retrieveSublistPrivilegeApprovalsHistory = function(requestTitle) {
      // Setting activePrivilegeApprovalRequest so that the active request title gets highlighted on the UI
      $scope.activePrivilegeApprovalRequestHistory = requestTitle;

      $scope.sublistPrivilegeApprovalsHistory = [];

      if(requestTitle === 'All') {
        Array.prototype.push.apply($scope.sublistPrivilegeApprovalsHistory, angular.copy($scope.privilegeApprovalsHistory));
      } else {
        // Create sublistPrivilegeApprovalsHistory based on requestTitle
        $scope.privilegeApprovalsHistory.forEach(function(privilegeApproval) {
          if (privilegeApproval.requestTitle === requestTitle) {
             $scope.sublistPrivilegeApprovalsHistory.push(angular.copy(privilegeApproval));
          }
        });
      }

      // Let's create Column filter values based on what sublist has been selected.
      // Populate Data for  service/ serviceApiActions/ Env column filters
      $scope.createSublistColumnTableFilter();      
    };    


  /**
    Initialize method which does the following
      (1) Loads Finalized Privilege Review Approvals History
  */
  $scope.initialize = function() { 

    $scope.showPrivilegeApprovalHistorySpinner = true;

    $scope.privilegeApprovalsHistory = [];
    $scope.serviceApiActionEntities = [];
    $scope.awsAccountEntities = [];

    $scope.sublistPrivilegeApprovalsHistory = [];
    $scope.privilegeApprovalRequestsHistory = [];
    $scope.activePrivilegeApprovalRequestHistory = 'All';

    $scope.bulkApprovalsHistoryInfo = [];


    // Retrieve Service Api Actions
    serviceRest.getServiceApiActions()
      .then(
        function(response) {
          $scope.serviceApiActionEntities = response.data;  
          
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
    );

    // Retrieve Aws Account to be displayed in the table
    awsAccountService.getAwsAccounts()
      .then(
          function(response) {
            $scope.awsAccountEntities = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );

    // Retrieve Finalized Privilege Review Approvals History
    privilegeReviewService.getLeanPrivilegeApprovalsHistory($scope.startDate, $scope.endDate)
      .then(
        function(response) {
          $scope.privilegeApprovalsHistory = response.data;

          if($scope.privilegeApprovalsHistory.length === 0) {
            $scope.showPrivilegeApprovalHistorySpinner = false;
          }          
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    privilegeReviewService.getBulkPrivilegeApprovalHistoryRequestTitleInfo($scope.startDate, $scope.endDate)
      .then(
        function(response) {
          $scope.bulkApprovalsHistoryInfo = response.data;          
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  $scope.initialize();
}]);