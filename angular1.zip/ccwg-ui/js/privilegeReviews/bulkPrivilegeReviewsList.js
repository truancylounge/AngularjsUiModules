ccwgApp.controller('BulkPrivilegeReviewsListController', ['$scope', '$rootScope', '$routeParams', 'privilegeReviewService', 'awsAccountService', 'serviceRest', 'lookupService', 'envService', '$sessionStorage',
    function($scope, $rootScope, $routeParams, privilegeReviewService, awsAccountService, serviceRest, lookupService, envService, $sessionStorage) {

  console.log("Route params : " + $routeParams.requestTitle);
  $scope.requestTitle = $routeParams.requestTitle;
  $scope.justification;

  $scope.privilegeReviews = [];
  $scope.serviceApiActionEntities = [];
  $scope.awsAccountEntities = [];
  $scope.responseTypes = [];

  $scope.enableActionChanges = false;
  $scope.showPrivilegeReviewSpinner = false;

  // Alert after Priv Reviews have been saved
  $scope.showSuccessAlert = false;
  $scope.savedPrivReviewsCount = 0;
  $scope.alertTimeout = envService.read('alertTimeout');

  $scope.closeAlert = function() {
    $scope.showSuccessAlert = false;
    $scope.savedPrivReviewsCount = 0;
  };

  $scope.getUserName = function(userId) {
    var userName;

    if(userId !== undefined) {
      $sessionStorage.users.some(function(user) {
        if(user.userId.toUpperCase() === userId.toUpperCase()) 
          userName = user.userName;
      });
    }
    return userName;
  };    

  // Pagination attributes
  $scope.currentPage = envService.read('currentPage');
  $scope.itemsPerPage = envService.read('itemsPerPage');
  $scope.maxSize = envService.read('maxSize');

  // Active button attirbutes
  $scope.data = {};
  $scope.data.activeButtonStatus = 'uncheck';
  $scope.data.reviewComments = null;
  $scope.data.filteredReviews = [];

  /* Watch section Start */

  /**
    We will be monitoring the $scope.privilegeReviews and once all entries have been retrieved we start populating Request titles
  */
  $scope.$watch(function() {return $scope.privilegeReviews.length}, function() {      
    if($scope.privilegeReviews.length > 0) {
      //console.log('Privilege Review Retrieved, initiating Table Population');
      $scope.initiateTablePopulation();        
    };
  });

  /**
    We will be monitoring the $scope.serviceApiActionEntities and once all entries have been retrieved we start populating Request titles
  */
  $scope.$watch(function() {return $scope.serviceApiActionEntities.length}, function() {
    if($scope.serviceApiActionEntities.length > 0) {
      //console.log('Service Api Action Entities Count reached, initiating Table Population');
      $scope.initiateTablePopulation();  
    }
  });

  $scope.$watch(function() {return $sessionStorage.user.permissions.length}, function() {    
    // If user is in Approver role then allow configuration item reviews
    if($.inArray('Approver', $sessionStorage.user.permissions) !== -1) {
      $scope.enableActionChanges = true;
    } else {
      $scope.enableActionChanges = false;
    }
  });

  /*
    Watch change to privilege review  table results and update the column filters with filtered values
    The filtered values will have to be sorted based on the filtered keywords
  */
  $scope.$watchCollection('data.filteredReviews', function() {
    $scope.updateColumnFilterValuesOnChange(); 
  });

  /* Watch Section End */

  //Setting for ng-dropdown-multiselect directive
  // Table Column filters
  $scope.multiSelectSettings = {
      //closeOnSelect: true,
      //closeOnDeselect: true,
      scrollableHeight: '300px',
      scrollable: true,
      externalIdProp: '',
      buttonClasses: 'btn btn-primary btn-xs'
  };
  // Creating a map between service name and unique Id, which will be used in column filters
  // We are creating this once during init and evertime we change column filter values, the id's remain the same
  // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
  $scope.serviceNameColumnIdMap = {};
  $scope.apiPrefixColumnIdMap = {};
  $scope.apiActionColumnIdMap = {};
  $scope.envColumnIdMap = {};
  $scope.roleNameColumnIdMap = {};
  $scope.accountNameColumnIdMap = {};

  $scope.clearColumnFilterAttributes = function() {
      console.log('Clear column filter attirbutes');
      $scope.selectedTableServices = [];
      $scope.selectedTableActionGs = [];
      $scope.selectedTableApiPrefix = [];
      $scope.selectedTableRoles = [];
      $scope.selectedTableEnvs = [];
      $scope.selectedTableOriginal = [];
      $scope.selectedTableProposed = [];
      $scope.selectedTableAccounts = [];
      $scope.privilegeApprovalSearchKeyword = '';
  };

  // Help's us figure out which filter made the change
  // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env/ Role/ Account
  // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
  $scope.columnFilterModified = {
    'serviceName': false,
    'apiPrefix': false,
    'actionGs': false,
    'env': false,
    'role': false,
    'account': false
  };    

  // Column Service filter attributes
  $scope.selectedTableServices = [];   
  $scope.servicesData = [];     // Data that gets displayed on Column Service Filter
  // ng-dropdown-multiselect event listeners
  $scope.serviceNameEventListeners = {
     onSelectionChanged: function() {
      if($scope.selectedTableServices.length > 0) {
        $scope.columnFilterModified = {'serviceName': true,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }      
    }
  };

  $scope.columnServiceFilter = function(i) {
    var serviceNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableServices.length > 0) {
      $scope.selectedTableServices.forEach(function(selectedEntry) {
        serviceNames.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.serviceNameShort, serviceNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };

  // Column Service Api Prefix filter attributes
  $scope.selectedTableApiPrefix = [];   
  $scope.apiPrefixData = [];     // Data that gets displayed on Column Api Prefix Filter
  $scope.apiPrefixEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableApiPrefix.length > 0) {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': true,'actionGs': false,'env': false,'role': false,'account': false};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }
    }
  };

  $scope.columnApiPrefixFilter = function(i) {
    var apiPrefixes = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableApiPrefix.length > 0) {
      $scope.selectedTableApiPrefix.forEach(function(selectedEntry) {
        apiPrefixes.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.apiActionPrefix, apiPrefixes) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;
  };

  // Column ServiceApi Action filter attributes
  $scope.selectedTableActionGs = [];   
  $scope.serviceApiActionsData = [];     // Data that gets displayed on Column Service Api Action Filter
  $scope.actionGsEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableActionGs.length > 0) {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': true,'env': false,'role': false,'account': false};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }
    }
  };

  $scope.columnServiceApiActionFilter = function(i) {
    var serviceApiActionNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableActionGs.length > 0) {
      $scope.selectedTableActionGs.forEach(function(selectedEntry) {
        serviceApiActionNames.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.apiActionName, serviceApiActionNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };
  
  // Column Envs filter attributes
  $scope.selectedTableEnvs = [];   
  $scope.envsData = [];     // Data that gets displayed on Column Envs Filter
  $scope.envEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableEnvs.length > 0) {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': true,'role': false,'account': false};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }
    }
  };

  $scope.columnEnvFilter = function(i) {
    var envNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableEnvs.length > 0) {
      $scope.selectedTableEnvs.forEach(function(selectedEntry) {
        envNames.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.environment, envNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };
  
  // Column Roles filter attributes
  $scope.selectedTableRoles = [];   
  $scope.rolesData = [];     // Data that gets displayed on Column Envs Filter
  $scope.roleEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableRoles.length > 0) {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': true,'account': false};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }
    }
  };

  $scope.columnRoleFilter = function(i) {
    var roles = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableRoles.length > 0) {
      $scope.selectedTableRoles.forEach(function(selectedEntry) {
        roles.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.roleName, roles) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };
  
  $scope.selectedTableOriginal = []; // Selected Original Value from column filter
  $scope.selectedTableProposed = []; // Selected Proposed Value from column filter
  // Original Config also has Empty value, hence splitting config data into Original and Proposed
  $scope.configurationOriginalData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}, {id: 3, label: 'Empty'}];
  $scope.configurationProposedData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];

  $scope.columnOriginalValueFilter = function(i) {
    var originalValue = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableOriginal.length > 0) {
      $scope.selectedTableOriginal.forEach(function(selectedEntry) {
        originalValue.push(selectedEntry.label);
      });

      if($.inArray((i.fromValue === null ? 'Empty' : i.fromValue), originalValue) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };

  $scope.columnProposedValueFilter = function(i) {
    var proposedValue = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableProposed.length > 0) {
      $scope.selectedTableProposed.forEach(function(selectedEntry) {
        proposedValue.push(selectedEntry.label);
      });

      if($.inArray(i.toValue, proposedValue) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };
  
  $scope.selectedTableAccounts = [];   
  $scope.accountsData = [];     // Data that gets displayed on Column Envs Filter
  $scope.accountEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableAccounts.length > 0) {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': true};
      } else {
        $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
      }
    }
  };

  $scope.columnAccountFilter = function(i) {
    var accounts = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableAccounts.length > 0) {
      $scope.selectedTableAccounts.forEach(function(selectedEntry) {
        accounts.push(selectedEntry.label);
      });

      if($.inArray(i.privilegeEntity.awsAccount, accounts) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };


  // Creates data for Column Filters from $scope.privilegeReviews
  $scope.createSublistColumnTableFilter = function() {
    // Setting serviceData array for service column table filter
    var uniqueServiceNames = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.serviceNameShort');
    $scope.createGenericColumnMap(uniqueServiceNames, $scope.serviceNameColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueServiceNames, $scope.servicesData, $scope.serviceNameColumnIdMap);

    var uniqueApiPrefixes = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.apiActionPrefix');
    $scope.createGenericColumnMap(uniqueApiPrefixes, $scope.apiPrefixColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueApiPrefixes, $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);

    var uniqueApiActions = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.apiActionName');
    $scope.createGenericColumnMap(uniqueApiActions, $scope.apiActionColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueApiActions, $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);

    var uniqueEnvs = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.environment');
    $scope.createGenericColumnMap(uniqueEnvs, $scope.envColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueEnvs, $scope.envsData, $scope.envColumnIdMap);

    var uniqueRoles = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.roleName');
    $scope.createGenericColumnMap(uniqueRoles, $scope.roleNameColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueRoles, $scope.rolesData, $scope.roleNameColumnIdMap);

    var uniqueAccounts = $scope.getGenericFieldValues($scope.privilegeReviews, 'privilegeEntity.awsAccount');
    $scope.createGenericColumnMap(uniqueAccounts, $scope.accountNameColumnIdMap);       
    $scope.createGenericColumnFilterValues(uniqueAccounts, $scope.accountsData, $scope.accountNameColumnIdMap);
  };

  /*
   Function takes collection & field name of an element in collection and returns unique list of field values
   This is a generic function to create column filter values.
  */
  $scope.getGenericFieldValues = function(genericCollection, fieldName) {
    var uniqueFieldValues = [];
    // Split the fieldName by dot to retrieve object values
    var innerFields = fieldName.split(".");

    if(innerFields.length === 1) {
      genericCollection.forEach(function(i) {
        if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
          uniqueFieldValues.push(i[fieldName]);
        }
      });
    } else if (innerFields.length === 2) { // To retrieve 'privilegeApproval.privilegeEntity.serviceNameShort'
      genericCollection.forEach(function(i) {
        if(uniqueFieldValues.indexOf(i[innerFields[0]][innerFields[1]]) === -1) {
          uniqueFieldValues.push(i[innerFields[0]][innerFields[1]]);
        }
      });
    }    
    
    return uniqueFieldValues.sort();
  };

  /*
    Creates generic column map for $scope.serviceNameColumnIdMap, $scope.apiPrefixColumnIdMap  etc
    Function takes unique column values & column map
  */
  $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
    var id = 1;
    genericColumnValues.forEach(function(value) {
      genericColumnMap[value] = id++;
    });
  };

  /*
    Create Generic Column Filter values.
    Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
  */
  $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
    genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
    genericColumnValues.forEach(function(value) {
      genericColumnData.push({
        id: genericColumnIdMap[value],
        label: value
      });
    });
  };

  /**
    Method get's called when table rows are filtered and this needs readjustment of the column values
  */
  $scope.updateColumnFilterValuesOnChange = function() {
    console.log("Inside Column filter values!!");
    // Only reset column filter's if other filter has been modified, 
    // if current filter is being accessed by the user don't modify the values of current filter
    // If we don't do $scope.servicesData etc to [] then duplicates will appear in the column filters 
    if($scope.columnFilterModified.serviceName === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.serviceNameShort'), 
        $scope.servicesData, $scope.serviceNameColumnIdMap);
    };

    if($scope.columnFilterModified.apiPrefix === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.apiActionPrefix'), 
        $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);
    };

    if($scope.columnFilterModified.actionGs === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.apiActionName'), 
        $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);
    };

    if($scope.columnFilterModified.env === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.environment'), 
        $scope.envsData, $scope.envColumnIdMap);
    };

    if($scope.columnFilterModified.role === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.roleName'), 
        $scope.rolesData, $scope.roleNameColumnIdMap);
    };

    if($scope.columnFilterModified.account === false) {
      $scope.createGenericColumnFilterValues(
        $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.awsAccount'), 
        $scope.accountsData, $scope.accountNameColumnIdMap);
    };
  };

  /* Column Filter section - End */


  $scope.activeClicked = function(activeButtonStatus, filteredPrivilegeReviews) {
    $scope.data.activeButtonStatus = activeButtonStatus;
    console.log($scope.data.activeButtonStatus);

    switch($scope.data.activeButtonStatus) {          
      case 'uncheck': 
        $scope.data.reviewComments = null;
        filteredPrivilegeReviews.forEach(function(privilegeReview) {
          if($scope.canPrivReviewBeApproved(privilegeReview)) {
            privilegeReview.responseType = "";
            privilegeReview.reviewComment = null;
            privilegeReview.action = "I";
          }              
        });
        break;

      case 'approveAll':
        filteredPrivilegeReviews.forEach(function(privilegeReview) {
          if($scope.canPrivReviewBeApproved(privilegeReview)) {
            privilegeReview.responseType = "Approved";
            privilegeReview.action = "U";
          }              
        });
        break;

      case 'rejectAll':
        filteredPrivilegeReviews.forEach(function(privilegeReview) {
          if($scope.canPrivReviewBeApproved(privilegeReview)) {
            privilegeReview.responseType = "Reject";
            privilegeReview.action = "U";              
          }              
        });
        break;
    }
  };

  $scope.checkSaveRevertValidity = function() {
    // Looping through privilegeReviews to find out if any have been updated, if so enable Revert and Save buttons.
    var enable = false;
    if(typeof $scope.privilegeReviews != 'undefined' && $scope.privilegeReviews instanceof Array) {
      $scope.privilegeReviews.filter(Boolean).forEach(function(privReview) {
        if(privReview.action == 'U') {
          enable = true;
        };
      });
    };
    return enable;
  }; 

  $scope.checkRejectValidity = function() {
    // Enable Save button if:
    // (1) Looping through privilegeReviews to find out if any have been updated
    // (2) If an Action is Reject prompt for comments and make sure it has been added.
    var enable = true;
    if(typeof $scope.privilegeReviews != 'undefined' && $scope.privilegeReviews instanceof Array) {

      for(var i = 0, len = $scope.privilegeReviews.filter(Boolean).length; i < len; ++i ) {
        if(!$scope.checkSpecificRejectValidity($scope.privilegeReviews.filter(Boolean)[i])) {
          enable = false;
          break;
        };

      }
    };
    return enable;
  }; 

  $scope.checkSpecificRejectValidity = function(privReview) {
    var valid = true;
    if(privReview.action === 'U' && !privReview.reviewComment && privReview.responseType === 'Reject' ) {
      valid = false;
    }
    return valid;
  };

  // Disable Approval edits if (1) Same user who proposed changes (2) Hasn't clicked Edit button
  $scope.disableApprovalChanges = function(i) {
    // If same user is trying to review changes disable
    if(i.privilegeEntity.updatedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
      return true;
    } 
    return !$scope.enableActionChanges;
  };

  $scope.canPrivReviewBeApproved = function(privilegeReview) {
    if(privilegeReview.privilegeEntity.updatedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
      return false;
    } else return true;
  }; 

  $scope.addingBulkComments = function(filteredPrivilegeReviews, reviewComments) {
    filteredPrivilegeReviews.forEach(function(privReview) {
      if($scope.canPrivReviewBeApproved(privReview)) {
        privReview.reviewComment = reviewComments;
      }        
    });
  };

  $scope.editResponseType = function(i) {
    i.action = "U";
  };

  $scope.revertPrivReviews = function() {
    $scope.initialize();
  };

  $scope.savePrivReviews = function() {
    $scope.showPrivilegeReviewSpinner = true;

    var updatedPrivilegeReviews = [];
    $scope.privilegeReviews.forEach(function(privReview) {
      if(privReview.action === 'U') {
        updatedPrivilegeReviews.push(privReview);
      }
    });

    privilegeReviewService.postPrivilegeReviews(updatedPrivilegeReviews)
      .then(
        function(response) {
          // Setting the Alert params
          $scope.showSuccessAlert = true;
          $scope.savedPrivReviewsCount = updatedPrivilegeReviews.length;
          
          $scope.initialize();
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };


  // We initiate population after both $scope.privilegeReviews & $scope.serviceApiActionEntities have been retrieved
  $scope.initiateTablePopulation = function() {
    if($scope.privilegeReviews.length > 0 && $scope.serviceApiActionEntities.length > 0) {
      $scope.privilegeReviews.forEach(function(privilegeReview) {
        $scope.addRoleName(privilegeReview); // Add a new property called RoleName based on ccwgRoleOrgId
        $scope.addAwsAccount(privilegeReview); // Add a new property called AwsAccount based on ccwgFinraAwsAccountsId
        $scope.addServiceApiActionName(privilegeReview); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
      });

      $scope.createSublistColumnTableFilter();
      $scope.showPrivilegeReviewSpinner = false;
    }
  };

  $scope.addRoleName = function(privilegeReview) {
    $rootScope.roleEntities.forEach(function(roleEntity) {
      if(roleEntity.id === privilegeReview.privilegeEntity.ccwgRoleOrgId) { 
        privilegeReview.privilegeEntity['roleName'] = roleEntity.roleName;
      }          
    });
  };

  $scope.addAwsAccount = function(privilegeReview) {
    $scope.awsAccountEntities.forEach(function(awsAccountEntity) {
      if(awsAccountEntity.id === privilegeReview.privilegeEntity.ccwgFinraAwsAccountsId) { 
        privilegeReview.privilegeEntity['awsAccount'] = awsAccountEntity.org + ":" + 
                                                        awsAccountEntity.accountName + ":" + 
                                                        awsAccountEntity.accountArn;
      }          
    });
  }

  $scope.addServiceApiActionName = function(privilegeReview) {
    $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
      if(serviceApiActionEntity.id === privilegeReview.privilegeEntity.ccwgServiceApiActionGsId) { 
        privilegeReview.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
        privilegeReview.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
        privilegeReview.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
        privilegeReview.privilegeEntity['apiActionDescription'] = serviceApiActionEntity.apiActionDescription;
        privilegeReview.privilegeEntity['apiActionReference'] = serviceApiActionEntity.apiActionReference;
      }          
    });
  };


  /**
    (1) Retrive Aws Accounts
    (2) Retrieve un approved privilege reviews for bulk request title
    (3) Retrieve Service Api Actions
  */

  $scope.initialize = function() {
    $scope.privilegeReviews = [];
    $scope.data.activeButtonStatus = 'uncheck';

    $scope.showPrivilegeReviewSpinner = true;
    $scope.data.reviewComments = null;

    // Retrieve Aws Account to be displayed in the table
    awsAccountService.getAwsAccounts()
      .then(
          function(response) {
            $scope.awsAccountEntities = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );

    privilegeReviewService.getUnApprovedPrivilegeReviewsByRequestTitle($scope.requestTitle)
      .then(
        function(response) {          
          $scope.privilegeReviews = response.data;  
          
          if($scope.privilegeReviews.length === 0) {
            $scope.showPrivilegeReviewSpinner = false;
          } else {
            $scope.justification = $scope.privilegeReviews[0].justification;
          }
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Adding envs creation here coz lookup service takes some time to load envs.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.responseTypes = response.privReviewResponses;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
    );

    // Retrieve service api actions
    serviceRest.getServiceApiActions()
      .then(
        function(response) {
          $scope.serviceApiActionEntities = response.data;        
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  $scope.initialize(); 
}]);