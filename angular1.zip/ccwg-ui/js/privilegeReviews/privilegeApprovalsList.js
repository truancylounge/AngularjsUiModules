ccwgApp.controller('PrivilegeApprovalsListController', ['$scope', '$rootScope', 'privilegeReviewService', 'serviceRest', 'lookupService', 'userService', 'envService', '$sessionStorage', 'awsAccountService', '$timeout', '$location',
  function($scope, $rootScope, privilegeReviewService, serviceRest, lookupService, userService, envService, $sessionStorage, awsAccountService, $timeout, $location) {

    $scope.privilegeApprovals = [];
    $scope.sublistPrivilegeApprovals = [];
    $scope.privilegeApprovalRequests = [];
    $scope.activePrivilegeApprovalRequest = 'All';

    // Active button attirbutes
    $scope.activeButtonStatus = 'uncheck';

    // Array that stores Bulk Approval Request titles ( privilege reviews > = 100)
    // contains requestTitle, justification, count & changeProposedDate
    $scope.bulkApprovalsInfo = [];

    $scope.serviceApiActionEntities = [];

    $scope.awsAccountEntities = [];

    $scope.responseTypes = [];
    $scope.approvers = [];

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    $scope.enableActionChanges = false;

    // Alert after Priv Approvals have been saved
    $scope.showSuccessAlert = false;
    $scope.savedPrivApprovalCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showPrivilegeApprovalSpinner = false;
    

    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedPrivApprovalCount = 0;
    };

    $scope.getUserName = function(userId) {
        var userName;
        if(userId !== undefined) {
          $sessionStorage.users.some(function(user) {
            if(user.userId.toUpperCase() === userId.toUpperCase()) 
              userName = user.userName;
          });
        }

        return userName;
    }; 

    $scope.$watch(function() {return $sessionStorage.user.permissions.length}, function() {
      
      // If user is in Approver role then allow configuration item reviews
      if($.inArray('Admin', $sessionStorage.user.permissions) !== -1) {
        $scope.enableActionChanges = true;
      } else {
        $scope.enableActionChanges = false;
      }
    });

    /**
      We will be monitoring the $scope.privilegeApprovals and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.privilegeApprovals.length}, function() {      
      if($scope.privilegeApprovals.length > 0) {
        console.log('Privilege Approval Count reached, initiating Table Population');
        $scope.initiateTablePopulation();        
      };
    });

    /**
      We will be monitoring the $scope.serviceApiActionEntities and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.serviceApiActionEntities.length}, function() {
      if($scope.serviceApiActionEntities.length > 0) {
        console.log('Service Api Action Entities Count reached, initiating Table Population');
        $scope.initiateTablePopulation();  
      }
    });

    /*
      Watch change to privilege approval  table results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('filteredApprovals', function() {
      $scope.updateColumnFilterValuesOnChange(); 
    });


    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettings = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };
    // Creating a map between service name and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.serviceNameColumnIdMap = {};
    $scope.apiPrefixColumnIdMap = {};
    $scope.apiActionColumnIdMap = {};
    $scope.envColumnIdMap = {};
    $scope.roleNameColumnIdMap = {};
    $scope.accountNameColumnIdMap = {};

    $scope.clearColumnFilterAttributes = function() {
        console.log('Clear column filter attirbutes');
        $scope.selectedTableServices = [];
        $scope.selectedTableActionGs = [];
        $scope.selectedTableApiPrefix = [];
        $scope.selectedTableRoles = [];
        $scope.selectedTableEnvs = [];
        $scope.selectedTableOriginal = [];
        $scope.selectedTableProposed = [];
        $scope.selectedTableAccounts = [];
        $scope.searchKeyword = '';
    };

    // Help's us figure out which filter made the change
    // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env/ Role/ Account
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModified = {
      'serviceName': false,
      'apiPrefix': false,
      'actionGs': false,
      'env': false,
      'role': false,
      'account': false
    };    

    // Column Service filter attributes
    $scope.selectedTableServices = [];   
    $scope.servicesData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.serviceNameEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableServices.length > 0) {
          $scope.columnFilterModified = {'serviceName': true,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }      
      }
    };

    $scope.columnServiceFilter = function(i) {
      var serviceNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableServices.length > 0) {
        $scope.selectedTableServices.forEach(function(selectedEntry) {
          serviceNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.serviceNameShort, serviceNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Service Api Prefix filter attributes
    $scope.selectedTableApiPrefix = [];   
    $scope.apiPrefixData = [];     // Data that gets displayed on Column Api Prefix Filter
    $scope.apiPrefixEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableApiPrefix.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': true,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnApiPrefixFilter = function(i) {
      var apiPrefixes = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableApiPrefix.length > 0) {
        $scope.selectedTableApiPrefix.forEach(function(selectedEntry) {
          apiPrefixes.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionPrefix, apiPrefixes) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column ServiceApi Action filter attributes
    $scope.selectedTableActionGs = [];   
    $scope.serviceApiActionsData = [];     // Data that gets displayed on Column Service Api Action Filter
    $scope.actionGsEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableActionGs.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': true,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnServiceApiActionFilter = function(i) {
      var serviceApiActionNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableActionGs.length > 0) {
        $scope.selectedTableActionGs.forEach(function(selectedEntry) {
          serviceApiActionNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionName, serviceApiActionNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Envs filter attributes
    $scope.selectedTableEnvs = [];   
    $scope.envsData = [];     // Data that gets displayed on Column Envs Filter
    $scope.envEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableEnvs.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': true,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnEnvFilter = function(i) {
      var envNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableEnvs.length > 0) {
        $scope.selectedTableEnvs.forEach(function(selectedEntry) {
          envNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.environment, envNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Roles filter attributes
    $scope.selectedTableRoles = [];   
    $scope.rolesData = [];     // Data that gets displayed on Column Envs Filter
    $scope.roleEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableRoles.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': true,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnRoleFilter = function(i) {
      var roles = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableRoles.length > 0) {
        $scope.selectedTableRoles.forEach(function(selectedEntry) {
          roles.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.roleName, roles) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableOriginal = []; // Selected Original Value from column filter
    $scope.selectedTableProposed = []; // Selected Proposed Value from column filter
    // Original Config also has Empty value, hence splitting config data into Original and Proposed
    $scope.configurationOriginalData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}, {id: 3, label: 'Empty'}];
    $scope.configurationProposedData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];

    $scope.columnOriginalValueFilter = function(i) {
      var originalValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableOriginal.length > 0) {
        $scope.selectedTableOriginal.forEach(function(selectedEntry) {
          originalValue.push(selectedEntry.label);
        });

        if($.inArray((i.fromValue === null ? 'Empty' : i.fromValue), originalValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnProposedValueFilter = function(i) {
      var proposedValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableProposed.length > 0) {
        $scope.selectedTableProposed.forEach(function(selectedEntry) {
          proposedValue.push(selectedEntry.label);
        });

        if($.inArray(i.toValue, proposedValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableAccounts = [];   
    $scope.accountsData = [];     // Data that gets displayed on Column Envs Filter
    $scope.accountEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableAccounts.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': true};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnAccountFilter = function(i) {
      var accounts = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableAccounts.length > 0) {
        $scope.selectedTableAccounts.forEach(function(selectedEntry) {
          accounts.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.awsAccount, accounts) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };


    // Creates data for Column Filters from $scope.sublistPrivilegeApprovalsHistory
    $scope.createSublistColumnTableFilter = function() {
      // Setting serviceData array for service column table filter
      var uniqueServiceNames = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.serviceNameShort');
      $scope.createGenericColumnMap(uniqueServiceNames, $scope.serviceNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueServiceNames, $scope.servicesData, $scope.serviceNameColumnIdMap);

      var uniqueApiPrefixes = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.apiActionPrefix');
      $scope.createGenericColumnMap(uniqueApiPrefixes, $scope.apiPrefixColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueApiPrefixes, $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);

      var uniqueApiActions = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.apiActionName');
      $scope.createGenericColumnMap(uniqueApiActions, $scope.apiActionColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueApiActions, $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);

      var uniqueEnvs = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.environment');
      $scope.createGenericColumnMap(uniqueEnvs, $scope.envColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueEnvs, $scope.envsData, $scope.envColumnIdMap);

      var uniqueRoles = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.roleName');
      $scope.createGenericColumnMap(uniqueRoles, $scope.roleNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueRoles, $scope.rolesData, $scope.roleNameColumnIdMap);

      var uniqueAccounts = $scope.getGenericFieldValues($scope.sublistPrivilegeApprovals, 'privilegeEntity.awsAccount');
      $scope.createGenericColumnMap(uniqueAccounts, $scope.accountNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueAccounts, $scope.accountsData, $scope.accountNameColumnIdMap);
    };

    /*
     Function takes collection & field name of an element in collection and returns unique list of field values
     This is a generic function to create column filter values.
    */
    $scope.getGenericFieldValues = function(genericCollection, fieldName) {
      var uniqueFieldValues = [];
      // Split the fieldName by dot to retrieve object values
      var innerFields = fieldName.split(".");

      if(innerFields.length === 1) {
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
            uniqueFieldValues.push(i[fieldName]);
          }
        });
      } else if (innerFields.length === 2) { // To retrieve 'privilegeApproval.privilegeEntity.serviceNameShort'
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[innerFields[0]][innerFields[1]]) === -1) {
            uniqueFieldValues.push(i[innerFields[0]][innerFields[1]]);
          }
        });
      }    
      
      return uniqueFieldValues.sort();
    };

    /*
      Creates generic column map for $scope.serviceNameColumnIdMap, $scope.apiPrefixColumnIdMap  etc
      Function takes unique column values & column map
    */
    $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
      var id = 1;
      genericColumnValues.forEach(function(value) {
        genericColumnMap[value] = id++;
      });
    };

    /*
      Create Generic Column Filter values.
      Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
    */
    $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
      genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
      genericColumnValues.forEach(function(value) {
        genericColumnData.push({
          id: genericColumnIdMap[value],
          label: value
        });
      });
    };

    /**
      Method get's called when table rows are filtered and this needs readjustment of the column values
    */
    $scope.updateColumnFilterValuesOnChange = function() {
      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do $scope.servicesData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModified.serviceName === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.serviceNameShort'), 
          $scope.servicesData, $scope.serviceNameColumnIdMap);
      };

      if($scope.columnFilterModified.apiPrefix === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.apiActionPrefix'), 
          $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);
      };

      if($scope.columnFilterModified.actionGs === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.apiActionName'), 
          $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);
      };

      if($scope.columnFilterModified.env === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.environment'), 
          $scope.envsData, $scope.envColumnIdMap);
      };

      if($scope.columnFilterModified.role === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.roleName'), 
          $scope.rolesData, $scope.roleNameColumnIdMap);
      };

      if($scope.columnFilterModified.account === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredApprovals, 'privilegeEntity.awsAccount'), 
          $scope.accountsData, $scope.accountNameColumnIdMap);
      };
    };

    /* Column Filter section - End */

    $scope.activeClicked = function(filteredPrivilegeApprovals) {
      console.log($scope.activeButtonStatus);
        switch($scope.activeButtonStatus) {          
          case 'uncheck': 
            $scope.approvalComments = null;
            
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "";
              privilegeApproval.reviewComment = null;
              privilegeApproval.action = "I";              
            });
            
            break;

          case 'approveAll':
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "Approved";
              privilegeApproval.action = "U";
            });
            break;

          case 'rejectAll':
            filteredPrivilegeApprovals.forEach(function(privilegeApproval) {
              privilegeApproval.responseType = "Reject";
              privilegeApproval.action = "U";
            });
            break;
        }      

    };

    $scope.addingBulkComments = function(filteredPrivilegeApprovals, approvalComments) {
      filteredPrivilegeApprovals.forEach(function(privApproval) {
        privApproval.reviewComment = approvalComments;
      });
    };    

    $scope.revertPrivApprovals = function() {
      $scope.initialize();
    };

    $scope.savePrivApprovals = function() {
      $scope.showPrivilegeApprovalSpinner = true;    
      var updatedPrivApprovals = [];
      $scope.sublistPrivilegeApprovals.forEach(function(privApproval) {
        if(privApproval.action === "U") { updatedPrivApprovals.push(privApproval); }
      });

      $scope.savedPrivApprovalCount = updatedPrivApprovals.length;
      privilegeReviewService.postPrivilegeApprovals(updatedPrivApprovals)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.initialize();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );      
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through privilegeApprovals to find out if any have been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.sublistPrivilegeApprovals !== 'undefined' && $scope.sublistPrivilegeApprovals instanceof Array) {
        $scope.sublistPrivilegeApprovals.filter(Boolean).forEach(function(privApproval) {
          if(privApproval.action == 'U') {
            enable = true;
          };
        });
      };
      return enable;
    }; 

    $scope.checkRejectValidity = function() {
      // Enable Save button if:
      // (1) Looping through privilegeApprovals to find out if any have been updated
      // (2) If an Action is Reject prompt for comments and make sure it has been added.
      var enable = true;

      if(typeof $scope.sublistPrivilegeApprovals != 'undefined' && $scope.sublistPrivilegeApprovals instanceof Array) {

        for(var i = 0, len = $scope.sublistPrivilegeApprovals.filter(Boolean).length; i < len; ++i ) {
          if(!$scope.checkSpecificRejectValidity($scope.sublistPrivilegeApprovals.filter(Boolean)[i])) {
            enable = false;
            break;
          };

        }
      };
      return enable;
    }; 

    $scope.checkSpecificRejectValidity = function(privApproval) {
      var valid = true;
      if(privApproval.action === 'U' && !privApproval.reviewComment && privApproval.responseType === 'Reject' ) {
        valid = false;
      }

      return valid;

    };

    $scope.editResponseType = function(i) {
      console.log("Edit response type");
      i.action = "U";
    };
   
    $scope.addRoleName = function(privilegeApproval) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeApproval.privilegeEntity.ccwgRoleOrgId) { 
          privilegeApproval.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };

    $scope.addAwsAccount = function(privilegeApproval) {
      $scope.awsAccountEntities.forEach(function(awsAccountEntity) {
        if(awsAccountEntity.id === privilegeApproval.privilegeEntity.ccwgFinraAwsAccountsId) { 
          privilegeApproval.privilegeEntity['awsAccount'] = awsAccountEntity.org + ":" + 
                                                            awsAccountEntity.accountName + ":" + 
                                                            awsAccountEntity.accountArn;
        }          
      });
    }

    $scope.addServiceApiActionName = function(privilegeApproval) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeApproval.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeApproval.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeApproval.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeApproval.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
          privilegeApproval.privilegeEntity['apiActionDescription'] = serviceApiActionEntity.apiActionDescription;
          privilegeApproval.privilegeEntity['apiActionReference'] = serviceApiActionEntity.apiActionReference;
        }          
      });
    };

    $scope.transposeApprovedUserActions = function(privilegeApproval) {
      privilegeApproval.privilegeReviewLogEntities.forEach(function(logEntry) {
        
        privilegeApproval[logEntry.reviewedBy.toUpperCase()] = {
          "responseType": logEntry.responseType,
          "reviewComment": logEntry.reviewComment
        };
      });
    }

    // Create privilege Approvals requests array to be displayed on the sidebar view
    $scope.createPrivilegeApprovalsRequests = function() {
      var approvalRequests = [];

      $scope.privilegeApprovals.sort(function(a, b) {return new Date(b.changeProposedDate).getTime() - new Date(a.changeProposedDate).getTime() });


      // Create a unique list of requestTitles 
      $scope.privilegeApprovals.forEach(function(privilegeApproval) {
        if (approvalRequests.indexOf(privilegeApproval.requestTitle) === -1) {
           approvalRequests.push(privilegeApproval.requestTitle);
        }
      });

      // Retrieve count of requestTitles and create privilegeApprovalsRequests
      approvalRequests.forEach(function(approvalRequest) {
        $scope.privilegeApprovalRequests.push({
          requestName: approvalRequest,
          justification: $scope.getPrivilegeApprovalsRequestsJustification(approvalRequest),
          requestCount: $scope.getPrivilegeApprovalsRequestsCount(approvalRequest)
        });
      });
    };

    $scope.getPrivilegeApprovalsRequestsCount = function(requestTitle) {
      var count = 0;

      $scope.privilegeApprovals.forEach(function(privilegeApproval) {
        if (privilegeApproval.requestTitle === requestTitle) {
           count++;
        }
      });

      return count;
    };

    $scope.getPrivilegeApprovalsRequestsJustification = function(requestTitle) {
      var justification = "";

      $scope.privilegeApprovals.some(function(privilegeApproval) {
        if (privilegeApproval.requestTitle === requestTitle) {
           justification = privilegeApproval.justification;
        }
      });

      return justification;
    };    

    // Create a sublist of privilegeReviewRequests based on requestTitle
    $scope.retrieveSublistPrivilegeApprovals = function(requestTitle) {
      // Setting activePrivilegeApprovalRequest so that the active request title gets highlighted on the UI
      $scope.activePrivilegeApprovalRequest = requestTitle;

      $scope.sublistPrivilegeApprovals = [];

      if(requestTitle === 'All') {
        Array.prototype.push.apply($scope.sublistPrivilegeApprovals, angular.copy($scope.privilegeApprovals));
      } else {
        // Create sublistPrivilegeApprovals based on requestTitle
        $scope.privilegeApprovals.forEach(function(privilegeApproval) {
          if (privilegeApproval.requestTitle === requestTitle) {
             $scope.sublistPrivilegeApprovals.push(angular.copy(privilegeApproval));
          }
        });
      }
      // Let's create Column filter values based on what sublist has been selected.
      // Populate Data for  service/ serviceApiActions/ Env column filters
      $scope.createSublistColumnTableFilter();  
    }; 

  $scope.showBulkApprovalRequestTitle = function(i) {
    $location.path('/bulkPrivilegeApprovalList/'+ i.requestTitle);
  }

  // We initiate population after both $scope.privilegeApprovals & $scope.serviceApiActionEntities have been retrieved
  $scope.initiateTablePopulation = function() {
    if($scope.privilegeApprovals.length > 0 && $scope.serviceApiActionEntities.length > 0) {
      console.log("Privilege Approvals & ApiActionEntities have been retrieved. Start populating the Request titles pane");

      $scope.privilegeApprovals.forEach(function(privilegeApproval) {
        $scope.addRoleName(privilegeApproval); // Add a new property called RoleName based on ccwgRoleOrgId
        $scope.addAwsAccount(privilegeApproval); // Add a new property called AwsAccount based on ccwgFinraAwsAccountsId
        $scope.addServiceApiActionName(privilegeApproval); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
        $scope.transposeApprovedUserActions(privilegeApproval);
      });
      
      Array.prototype.push.apply($scope.sublistPrivilegeApprovals, angular.copy($scope.privilegeApprovals));
      $scope.createPrivilegeApprovalsRequests();  
      $scope.createSublistColumnTableFilter();
      $scope.showPrivilegeApprovalSpinner = false;
    }
  };


  /**
    Initialize method which does the following
      (1) Loads Privilege Approvals
      (2) Loads Privilege Review Responses
      (3) Loads all users who are approvers

  */
  $scope.initialize = function() {
    $scope.privilegeApprovals = [];
    $scope.sublistPrivilegeApprovals = [];
    $scope.privilegeApprovalRequests = [];
    $scope.activePrivilegeApprovalRequest = 'All';

    $scope.activeButtonStatus = 'uncheck';
    $scope.approvalComments = null;

    $scope.clearColumnFilterAttributes();

    $scope.showPrivilegeApprovalSpinner = true;

    // Loading service api actions.
    serviceRest.getServiceApiActions()
      .then(
        function(response) {
          $scope.serviceApiActionEntities = response.data;        
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Retrieve privilege review responses.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.responseTypes = response.privReviewResponses;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Retrieve Aws Account to be displayed in the table
    awsAccountService.getAwsAccounts()
      .then(
          function(response) {
            $scope.awsAccountEntities = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );

    userService.getApprovers()
      .then(
        function(response) {
          $scope.approvers = response.data;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    privilegeReviewService.getLeanPrivilegeApprovals()
      .then(
        function(response) {
          $scope.privilegeApprovals = response.data;  
          if($scope.privilegeApprovals.length === 0) {
            $scope.showPrivilegeApprovalSpinner = false;
          }        
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    privilegeReviewService.getBulkPrivilegeApprovalRequestTitleInfo()
      .then(
        function(response) {
          $scope.bulkApprovalsInfo = response.data;          
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  $scope.initialize();  
}]);