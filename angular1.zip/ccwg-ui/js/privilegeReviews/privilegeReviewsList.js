ccwgApp.controller('PrivilegeReviewsListController', ['$scope', '$rootScope', 'privilegeReviewService', 'roleService', 'serviceRest', 'lookupService', 'envService', '$sessionStorage', 'awsAccountService', '$timeout', 'usSpinnerService', '$location',
  function($scope, $rootScope, privilegeReviewService, roleService, serviceRest, lookupService, envService, $sessionStorage, awsAccountService, $timeout, usSpinnerService, $location) {

    $scope.originalPrivilegeReviews = [];
    $scope.privilegeReviews = [];
    $scope.sublistPrivilegeReviews = [];
    $scope.privilegeReviewsRequests = [];
    $scope.activePrivilegeReviewRequest = 'All';

    // Array that stores Bulk Request titles ( privilege reviews > = 100)
    // contains requestTitle, justification, count & changeProposedDate
    $scope.bulkRequestsInfo = [];
    $scope.originalBulkRequestsInfo = [];

    $scope.historicPrivilegeReviews = [];
    $scope.sublistHistoricPrivilegeReviews = [];
    $scope.historicPrivilegeReviewsRequests = [];
    $scope.activeHistoricPrivilegeReviewRequest = 'All';

    $scope.serviceApiActionEntities = [];

    $scope.awsAccountEntities = [];

    $scope.responseTypes = [];
    $scope.enableActionChanges = false;

    // Alert after Priv Reviews have been saved
    $scope.showSuccessAlert = false;
    $scope.savedPrivReviewsCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showPrivilegeReviewSpinner = false;
    $scope.showPrivilegeReviewHistorySpinner = false;

    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedPrivReviewsCount = 0;
    };

    $scope.getUserName = function(userId) {
        var userName;

        if(userId !== undefined) {
          $sessionStorage.users.some(function(user) {
            if(user.userId.toUpperCase() === userId.toUpperCase()) 
              userName = user.userName;
          });
        }
        return userName;
    };

    $scope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if(phase == '$apply' || phase == '$digest') {
        if(fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.data = {};
    $scope.data.activeButtonStatus = 'uncheck';
    $scope.data.reviewComments = null;
    $scope.data.filteredReviews = [];
    $scope.data.filteredHistoricReviews = [];
    $scope.data.revertJustification = null;

    // Config Filter Attributes
    $scope.configFilterValues = ['All', 'Pending Approvals', 'My Submissions'];
    $scope.selectedConfigsList = ['Pending Approvals'];
    $scope.selectedConfigValues = function(data) {
      $scope.selectedConfigsList = data;
    };

    $scope.filterSelectedConfigValues = function() {

      // When a selection is made, reset the privilegeReview collection to null
      // Based on selection, populate the privilegeReviews from originalPrivilegeReviews.
      $scope.privilegeReviews = [];
      $scope.bulkRequestsInfo = [];
      $scope.activePrivilegeReviewRequest = 'All';
      
      if($.inArray('All', $scope.selectedConfigsList) !== -1 || $scope.selectedConfigsList.length === 0 ) {
        $scope.privilegeReviews = $scope.originalPrivilegeReviews;
        $scope.bulkRequestsInfo = $scope.originalBulkRequestsInfo;
      } else {
        if($.inArray('Pending Approvals', $scope.selectedConfigsList) !== -1) {
          $scope.originalPrivilegeReviews.forEach(function(privilegeReview) {
            if(privilegeReview.changedBy.toUpperCase() !== $sessionStorage.user.name.toUpperCase()) {
              $scope.privilegeReviews.push(privilegeReview);
            }
          });

          $scope.originalBulkRequestsInfo.forEach(function(bulkInfo) {
            if(bulkInfo.changedBy.toUpperCase() !== $sessionStorage.user.name.toUpperCase()) {
              $scope.bulkRequestsInfo.push(bulkInfo);
            }
          });
        }

        if($.inArray('My Submissions', $scope.selectedConfigsList) !== -1) {
          $scope.originalPrivilegeReviews.forEach(function(privilegeReview) {
            if(privilegeReview.changedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
              $scope.privilegeReviews.push(privilegeReview);
            }
          });
          $scope.originalBulkRequestsInfo.forEach(function(bulkInfo) {
            if(bulkInfo.changedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
              $scope.bulkRequestsInfo.push(bulkInfo);
            }
          });
        }
      }      
    }

    $scope.$watch(function() {return $sessionStorage.user.permissions.length}, function() {      
      // If user is in Approver role then allow configuration item reviews
      if($.inArray('Approver', $sessionStorage.user.permissions) !== -1) {
        $scope.enableActionChanges = true;
      } else {
        $scope.enableActionChanges = false;
      }
    });


    /**
      We will be monitoring the $scope.privilegeReviews and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.privilegeReviews.length}, function() {      
      if($scope.privilegeReviews.length > 0) {
        console.log('Privilege Review Retrieved, initiating Table Population');
        $scope.initiateTablePopulation(false);        
      };
    });

    /**
      We will be monitoring the $scope.serviceApiActionEntities and once all entries have been retrieved we start populating Request titles
    */
    $scope.$watch(function() {return $scope.serviceApiActionEntities.length}, function() {
      if($scope.serviceApiActionEntities.length > 0) {
        //console.log('Service Api Action Entities Count reached, initiating Table Population');
        $scope.initiateTablePopulation(false);  
      }
    });

    /*
      Watch change to selectedConfigsList filter, as values are updated the table needs to get updated
    */
    $scope.$watchCollection('selectedConfigsList', function() {
      $scope.filterSelectedConfigValues();
      $scope.initiateTablePopulation(true);
    });

    /*
      Watch change to privilege review  table results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('data.filteredReviews', function() {
      $scope.updateColumnFilterValuesOnChange(); 
    });

    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettings = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };
    // Creating a map between service name and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.serviceNameColumnIdMap = {};
    $scope.apiPrefixColumnIdMap = {};
    $scope.apiActionColumnIdMap = {};
    $scope.envColumnIdMap = {};
    $scope.roleNameColumnIdMap = {};
    $scope.accountNameColumnIdMap = {};

    $scope.clearColumnFilterAttributes = function() {
        console.log('Clear column filter attirbutes');
        $scope.selectedTableServices = [];
        $scope.selectedTableActionGs = [];
        $scope.selectedTableApiPrefix = [];
        $scope.selectedTableRoles = [];
        $scope.selectedTableEnvs = [];
        $scope.selectedTableOriginal = [];
        $scope.selectedTableProposed = [];
        $scope.selectedTableAccounts = [];
        $scope.privilegeApprovalSearchKeyword = '';
    };

    // Help's us figure out which filter made the change
    // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env/ Role/ Account
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModified = {
      'serviceName': false,
      'apiPrefix': false,
      'actionGs': false,
      'env': false,
      'role': false,
      'account': false
    };    

    // Column Service filter attributes
    $scope.selectedTableServices = [];   
    $scope.servicesData = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.serviceNameEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableServices.length > 0) {
          $scope.columnFilterModified = {'serviceName': true,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }      
      }
    };

    $scope.columnServiceFilter = function(i) {
      var serviceNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableServices.length > 0) {
        $scope.selectedTableServices.forEach(function(selectedEntry) {
          serviceNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.serviceNameShort, serviceNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Service Api Prefix filter attributes
    $scope.selectedTableApiPrefix = [];   
    $scope.apiPrefixData = [];     // Data that gets displayed on Column Api Prefix Filter
    $scope.apiPrefixEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableApiPrefix.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': true,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnApiPrefixFilter = function(i) {
      var apiPrefixes = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableApiPrefix.length > 0) {
        $scope.selectedTableApiPrefix.forEach(function(selectedEntry) {
          apiPrefixes.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionPrefix, apiPrefixes) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column ServiceApi Action filter attributes
    $scope.selectedTableActionGs = [];   
    $scope.serviceApiActionsData = [];     // Data that gets displayed on Column Service Api Action Filter
    $scope.actionGsEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableActionGs.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': true,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnServiceApiActionFilter = function(i) {
      var serviceApiActionNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableActionGs.length > 0) {
        $scope.selectedTableActionGs.forEach(function(selectedEntry) {
          serviceApiActionNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionName, serviceApiActionNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Envs filter attributes
    $scope.selectedTableEnvs = [];   
    $scope.envsData = [];     // Data that gets displayed on Column Envs Filter
    $scope.envEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableEnvs.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': true,'role': false,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnEnvFilter = function(i) {
      var envNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableEnvs.length > 0) {
        $scope.selectedTableEnvs.forEach(function(selectedEntry) {
          envNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.environment, envNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Roles filter attributes
    $scope.selectedTableRoles = [];   
    $scope.rolesData = [];     // Data that gets displayed on Column Envs Filter
    $scope.roleEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableRoles.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': true,'account': false};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnRoleFilter = function(i) {
      var roles = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableRoles.length > 0) {
        $scope.selectedTableRoles.forEach(function(selectedEntry) {
          roles.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.roleName, roles) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableOriginal = []; // Selected Original Value from column filter
    $scope.selectedTableProposed = []; // Selected Proposed Value from column filter
    // Original Config also has Empty value, hence splitting config data into Original and Proposed
    $scope.configurationOriginalData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}, {id: 3, label: 'Empty'}];
    $scope.configurationProposedData = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];

    $scope.columnOriginalValueFilter = function(i) {
      var originalValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableOriginal.length > 0) {
        $scope.selectedTableOriginal.forEach(function(selectedEntry) {
          originalValue.push(selectedEntry.label);
        });

        if($.inArray((i.fromValue === null ? 'Empty' : i.fromValue), originalValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnProposedValueFilter = function(i) {
      var proposedValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableProposed.length > 0) {
        $scope.selectedTableProposed.forEach(function(selectedEntry) {
          proposedValue.push(selectedEntry.label);
        });

        if($.inArray(i.toValue, proposedValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableAccounts = [];   
    $scope.accountsData = [];     // Data that gets displayed on Column Envs Filter
    $scope.accountEventListeners = {
      onSelectionChanged: function() {
        if($scope.selectedTableAccounts.length > 0) {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': true};
        } else {
          $scope.columnFilterModified = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnAccountFilter = function(i) {
      var accounts = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableAccounts.length > 0) {
        $scope.selectedTableAccounts.forEach(function(selectedEntry) {
          accounts.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.awsAccount, accounts) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };


    // Creates data for Column Filters from $scope.sublistPrivilegeReviews
    $scope.createSublistColumnTableFilter = function() {
      // Setting serviceData array for service column table filter
      var uniqueServiceNames = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.serviceNameShort');
      $scope.createGenericColumnMap(uniqueServiceNames, $scope.serviceNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueServiceNames, $scope.servicesData, $scope.serviceNameColumnIdMap);

      var uniqueApiPrefixes = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.apiActionPrefix');
      $scope.createGenericColumnMap(uniqueApiPrefixes, $scope.apiPrefixColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueApiPrefixes, $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);

      var uniqueApiActions = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.apiActionName');
      $scope.createGenericColumnMap(uniqueApiActions, $scope.apiActionColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueApiActions, $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);

      var uniqueEnvs = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.environment');
      $scope.createGenericColumnMap(uniqueEnvs, $scope.envColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueEnvs, $scope.envsData, $scope.envColumnIdMap);

      var uniqueRoles = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.roleName');
      $scope.createGenericColumnMap(uniqueRoles, $scope.roleNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueRoles, $scope.rolesData, $scope.roleNameColumnIdMap);

      var uniqueAccounts = $scope.getGenericFieldValues($scope.sublistPrivilegeReviews, 'privilegeEntity.awsAccount');
      $scope.createGenericColumnMap(uniqueAccounts, $scope.accountNameColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueAccounts, $scope.accountsData, $scope.accountNameColumnIdMap);
    };

    /*
     Function takes collection & field name of an element in collection and returns unique list of field values
     This is a generic function to create column filter values.
    */
    $scope.getGenericFieldValues = function(genericCollection, fieldName) {
      var uniqueFieldValues = [];
      // Split the fieldName by dot to retrieve object values
      var innerFields = fieldName.split(".");

      if(innerFields.length === 1) {
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
            uniqueFieldValues.push(i[fieldName]);
          }
        });
      } else if (innerFields.length === 2) { // To retrieve 'privilegeApproval.privilegeEntity.serviceNameShort'
        genericCollection.forEach(function(i) {
          if(uniqueFieldValues.indexOf(i[innerFields[0]][innerFields[1]]) === -1) {
            uniqueFieldValues.push(i[innerFields[0]][innerFields[1]]);
          }
        });
      }    
      
      return uniqueFieldValues.sort();
    };

    /*
      Creates generic column map for $scope.serviceNameColumnIdMap, $scope.apiPrefixColumnIdMap  etc
      Function takes unique column values & column map
    */
    $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
      var id = 1;
      genericColumnValues.forEach(function(value) {
        genericColumnMap[value] = id++;
      });
    };

    /*
      Create Generic Column Filter values.
      Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
    */
    $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
      genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
      genericColumnValues.forEach(function(value) {
        genericColumnData.push({
          id: genericColumnIdMap[value],
          label: value
        });
      });
    };

    /**
      Method get's called when table rows are filtered and this needs readjustment of the column values
    */
    $scope.updateColumnFilterValuesOnChange = function() {
      console.log("Inside Column filter values!!");
      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do $scope.servicesData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModified.serviceName === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.serviceNameShort'), 
          $scope.servicesData, $scope.serviceNameColumnIdMap);
      };

      if($scope.columnFilterModified.apiPrefix === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.apiActionPrefix'), 
          $scope.apiPrefixData, $scope.apiPrefixColumnIdMap);
      };

      if($scope.columnFilterModified.actionGs === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.apiActionName'), 
          $scope.serviceApiActionsData, $scope.apiActionColumnIdMap);
      };

      if($scope.columnFilterModified.env === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.environment'), 
          $scope.envsData, $scope.envColumnIdMap);
      };

      if($scope.columnFilterModified.role === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.roleName'), 
          $scope.rolesData, $scope.roleNameColumnIdMap);
      };

      if($scope.columnFilterModified.account === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredReviews, 'privilegeEntity.awsAccount'), 
          $scope.accountsData, $scope.accountNameColumnIdMap);
      };
    };

    /* Column Filter section - End */

    $scope.activeClicked = function(activeButtonStatus, filteredPrivilegeReviews) {
      $scope.data.activeButtonStatus = activeButtonStatus;
      console.log($scope.data.activeButtonStatus);

        switch($scope.data.activeButtonStatus) {          
          case 'uncheck': 
            $scope.data.reviewComments = null;
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              if($scope.canPrivReviewBeApproved(privilegeReview)) {
                privilegeReview.responseType = "";
                privilegeReview.reviewComment = null;
                privilegeReview.action = "I";
              }              
            });
            break;

          case 'approveAll':
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              if($scope.canPrivReviewBeApproved(privilegeReview)) {
                privilegeReview.responseType = "Approved";
                privilegeReview.action = "U";
              }              
            });
            break;

          case 'rejectAll':
            filteredPrivilegeReviews.forEach(function(privilegeReview) {
              if($scope.canPrivReviewBeApproved(privilegeReview)) {
                privilegeReview.responseType = "Reject";
                privilegeReview.action = "U";              
              }              
            });
            break;
        }      

    };

    $scope.canPrivReviewBeApproved = function(privilegeReview) {
      if(privilegeReview.privilegeEntity.updatedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
        return false;
      } else return true;

    }; 

    $scope.addingBulkComments = function(filteredPrivilegeReviews, reviewComments) {
      filteredPrivilegeReviews.forEach(function(privReview) {
        if($scope.canPrivReviewBeApproved(privReview)) {
          privReview.reviewComment = reviewComments;
        }        
      });
    };  


    // Disable Approval edits if (1) Same user who proposed changes (2) Hasn't clicked Edit button
    $scope.disableApprovalChanges = function(i) {
      // If same user is trying to review changes disable
      if(i.privilegeEntity.updatedBy.toUpperCase() === $sessionStorage.user.name.toUpperCase()) {
        return true;
      } 

      return !$scope.enableActionChanges;

    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through privilegeReviews to find out if any have been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.sublistPrivilegeReviews != 'undefined' && $scope.sublistPrivilegeReviews instanceof Array) {
        $scope.sublistPrivilegeReviews.filter(Boolean).forEach(function(privReview) {
          if(privReview.action == 'U') {
            enable = true;
          };
        });
      };
      return enable;
    }; 


    $scope.checkRejectValidity = function() {
      // Enable Save button if:
      // (1) Looping through privilegeReviews to find out if any have been updated
      // (2) If an Action is Reject prompt for comments and make sure it has been added.
      var enable = true;

      if(typeof $scope.sublistPrivilegeReviews != 'undefined' && $scope.sublistPrivilegeReviews instanceof Array) {

        for(var i = 0, len = $scope.sublistPrivilegeReviews.filter(Boolean).length; i < len; ++i ) {
          if(!$scope.checkSpecificRejectValidity($scope.sublistPrivilegeReviews.filter(Boolean)[i])) {
            enable = false;
            break;
          };

        }
      };
      return enable;
    }; 

    $scope.checkSpecificRejectValidity = function(privReview) {
      var valid = true;
      if(privReview.action === 'U' && !privReview.reviewComment && privReview.responseType === 'Reject' ) {
        valid = false;
      }

      return valid;

    };

    $scope.exportExcelFile = function() {
      var exportedPrivileges = [];
      $scope.data.filteredReviews.forEach(function(review) {
        var privilegeReview = _update(review, {});
        privilegeReview.fromValue = review.fromValue;
        privilegeReview.serviceNameShort = review.privilegeEntity.serviceNameShort;
        privilegeReview.apiActionPrefix = review.privilegeEntity.apiActionPrefix;
        privilegeReview.apiActionName = review.privilegeEntity.apiActionName;
        privilegeReview.roleName = review.privilegeEntity.roleName;
        privilegeReview.environment = review.privilegeEntity.environment;
        privilegeReview.awsAccount = review.privilegeEntity.awsAccount;
        

        exportedPrivileges.push(privilegeReview);
      });
      alasql('SELECT * INTO XLSX("privilegeReviews.xlsx",{headers:true}) FROM ?',[exportedPrivileges]);
    };
    
    function _update(srcObj, destObj) {
      for (var key in srcObj) {
        //console.log("Type of Key: ", key,  typeof srcObj[key] );
        if(srcObj.hasOwnProperty(key) && typeof srcObj[key] !== 'object') {
          destObj[key] = srcObj[key];
        }
      }
      return destObj;
    }

    $scope.revertPrivReviews = function() {
      $scope.initialize();
    };

    $scope.savePrivReviews = function() {
      $scope.showPrivilegeReviewSpinner = true;
      privilegeReviewService.postPrivilegeReviews($scope.sublistPrivilegeReviews)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.sublistPrivilegeReviews.forEach(function(priv) {
              if(priv.action === 'U') 
                $scope.savedPrivReviewsCount++;
            });
            console.log('Saved PRiv review count: ', $scope.savedPrivReviewsCount);
            
            $scope.initialize();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );      
    };

    $scope.editResponseType = function(i) {
      i.action = "U";
    };

    $scope.addRoleName = function(privilegeReview) {
      $rootScope.roleEntities.forEach(function(roleEntity) {
        if(roleEntity.id === privilegeReview.privilegeEntity.ccwgRoleOrgId) { 
          privilegeReview.privilegeEntity['roleName'] = roleEntity.roleName;
        }          
      });
    };

    $scope.addAwsAccount = function(privilegeReview) {
      $scope.awsAccountEntities.forEach(function(awsAccountEntity) {
        if(awsAccountEntity.id === privilegeReview.privilegeEntity.ccwgFinraAwsAccountsId) { 
          privilegeReview.privilegeEntity['awsAccount'] = awsAccountEntity.org + ":" + 
                                                          awsAccountEntity.accountName + ":" + 
                                                          awsAccountEntity.accountArn;
        }          
      });
    }

    $scope.addServiceApiActionName = function(privilegeReview) {
      $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
        if(serviceApiActionEntity.id === privilegeReview.privilegeEntity.ccwgServiceApiActionGsId) { 
          privilegeReview.privilegeEntity['apiActionName'] = serviceApiActionEntity.apiActionName;
          privilegeReview.privilegeEntity['serviceNameShort'] = serviceApiActionEntity.serviceNameShort;
          privilegeReview.privilegeEntity['apiActionPrefix'] = serviceApiActionEntity.apiActionPrefix;
          privilegeReview.privilegeEntity['apiActionDescription'] = serviceApiActionEntity.apiActionDescription;
          privilegeReview.privilegeEntity['apiActionReference'] = serviceApiActionEntity.apiActionReference;
        }          
      });
    };

    /** Historic priv methods - Start**/

    // Create a sublist of privilegeReviewRequests based on requestTitle
    $scope.retrieveHistoricSublistPrivilegeReviews = function(requestTitle) {
      // Setting activeHistoricPrivilegeReviewRequest so that the active request title gets highlighted on the UI
      $scope.activeHistoricPrivilegeReviewRequest = requestTitle;

      $scope.sublistHistoricPrivilegeReviews = [];

      if(requestTitle === 'All') {
        $scope.sublistHistoricPrivilegeReviews = angular.copy($scope.historicPrivilegeReviews);
        //Array.prototype.push.apply($scope.sublistHistoricPrivilegeReviews, angular.copy($scope.historicPrivilegeReviews));
      } else {
        // Create sublistHistoricPrivilegeReviews based on requestTitle
        $scope.historicPrivilegeReviews.forEach(function(privilegeReview) {
          if (privilegeReview.requestTitle === requestTitle) {
             $scope.sublistHistoricPrivilegeReviews.push(angular.copy(privilegeReview));
          }
        });
      }
    };

    // Create historic privilege review requests array to be displayed on the sidebar view
    $scope.createHistoricPrivilegeReviewsRequests = function() {
      var historicReviewRequests = [];

      $scope.historicPrivilegeReviews.sort(function(a, b) {return new Date(b.changeProposedDate).getTime() - new Date(a.changeProposedDate).getTime() });

      // Create a unique list of requestTitles 
      $scope.historicPrivilegeReviews.forEach(function(privilegeReview) {
        if (historicReviewRequests.indexOf(privilegeReview.requestTitle) === -1) {
           historicReviewRequests.push(privilegeReview.requestTitle);
        }
      });

      // Retrieve count of requestTitles and create privilegeReviewsRequests
      historicReviewRequests.forEach(function(reviewRequest) {
        $scope.historicPrivilegeReviewsRequests.push({
          requestName: reviewRequest,
          justification: $scope.getHitoricPrivilegeReviewsRequestsJustification(reviewRequest),
          requestCount: $scope.getHitoricPrivilegeReviewsRequestsCount(reviewRequest)
        });
      });
    };

    $scope.getHitoricPrivilegeReviewsRequestsCount = function(requestTitle) {
      var count = 0;

      $scope.historicPrivilegeReviews.forEach(function(privilegeReview) {
        if (privilegeReview.requestTitle === requestTitle) {
           count++;
        }
      });

      return count;
    };

    $scope.getHitoricPrivilegeReviewsRequestsJustification = function(requestTitle) {
      var justification = "";

      $scope.historicPrivilegeReviews.some(function(privilegeReview) {
        if (privilegeReview.requestTitle === requestTitle) {
           justification = privilegeReview.justification;
        }
      });

      return justification;
    };

    /** Historic priv methods - END**/

    $scope.showBulkRequestTitle = function(i) {
      $location.path('/bulkPrivilegeReviewList/'+ i.requestTitle);
    };

    /** Priv methods - Start**/
    // Create a sublist of privilegeReviewRequests based on requestTitle
    $scope.retrieveSublistPrivilegeReviews = function(requestTitle) {
      // Setting activePrivilegeReviewRequest so that the active request title gets highlighted on the UI
      $scope.activePrivilegeReviewRequest = requestTitle;

      $scope.sublistPrivilegeReviews = [];

      if(requestTitle === 'All') {
        Array.prototype.push.apply($scope.sublistPrivilegeReviews, angular.copy($scope.privilegeReviews));
      } else {
        // Create sublistPrivilegeReviews based on requestTitle
        $scope.privilegeReviews.forEach(function(privilegeReview) {
          if (privilegeReview.requestTitle === requestTitle) {
             $scope.sublistPrivilegeReviews.push(angular.copy(privilegeReview));
          }
        });
      }
      // Let's create Column filter values based on what sublist has been selected.
      // Populate Data for  service/ serviceApiActions/ Env column filters
      $scope.createSublistColumnTableFilter();  
    };

    // We initiate population after both $scope.privilegeReviews & $scope.serviceApiActionEntities have been retrieved
    // We call this method if a selection is made from the Privilege Review Filter
    $scope.initiateTablePopulation = function(fromConfigFilter) {
      if(($scope.privilegeReviews.length > 0 && $scope.serviceApiActionEntities.length > 0) || fromConfigFilter == true)  {
        // Run this code only when not coming from Config filter to rectify the on load filter bug
        if(fromConfigFilter === false) {
          $scope.filterSelectedConfigValues();
        }
        
        //console.log("Privilege Reviews & ApiActionEntities have been retrieved. Start populating the Request titles pane");
        $scope.privilegeReviews.forEach(function(privilegeReview) {
          $scope.addRoleName(privilegeReview); // Add a new property called RoleName based on ccwgRoleOrgId
          $scope.addAwsAccount(privilegeReview); // Add a new property called AwsAccount based on ccwgFinraAwsAccountsId
          $scope.addServiceApiActionName(privilegeReview); //Add serviceApiActionName, serviceApiPrefix, serviceShortName
        });
        angular.copy($scope.privilegeReviews, $scope.sublistPrivilegeReviews);
        $scope.createPrivilegeReviewsRequests();      
        $scope.createSublistColumnTableFilter();

        if(fromConfigFilter === false) {
          $scope.showPrivilegeReviewSpinner = false;
        }        
      }    
    };

    // Create privilege review requests array to be displayed on the sidebar view
    $scope.createPrivilegeReviewsRequests = function() {
      var reviewRequests = [];
      $scope.privilegeReviewsRequests = [];

      // Sort priv reviews in order of recently proposed date
      $scope.privilegeReviews.sort(function(a, b) {return new Date(b.changeProposedDate).getTime() - new Date(a.changeProposedDate).getTime() });

      // Create a unique list of requestTitles 
      $scope.privilegeReviews.forEach(function(privilegeReview) {
        if (reviewRequests.indexOf(privilegeReview.requestTitle) === -1) {
           reviewRequests.push(privilegeReview.requestTitle);
        }
      });

      // Retrieve count of requestTitles and create privilegeReviewsRequests
      reviewRequests.forEach(function(reviewRequest) {
        $scope.privilegeReviewsRequests.push({
          requestName: reviewRequest,
          justification: $scope.getPrivilegeReviewsRequestsJustification(reviewRequest),
          requestCount: $scope.getPrivilegeReviewsRequestsCount(reviewRequest)
        });
      });
    };

    $scope.getPrivilegeReviewsRequestsCount = function(requestTitle) {
      var count = 0;

      $scope.privilegeReviews.forEach(function(privilegeReview) {
        if (privilegeReview.requestTitle === requestTitle) {
           count++;
        }
      });

      return count;
    };

    $scope.getPrivilegeReviewsRequestsJustification = function(requestTitle) {
      var justification = "";

      $scope.privilegeReviews.some(function(privilegeReview) {
        if (privilegeReview.requestTitle === requestTitle) {
           justification = privilegeReview.justification;
        }
      });

      return justification;
    };

    /** Priv methods - END**/



  /** Privilege Review history section */

  $scope.revertPrivilegeReview = function(i) {
    i.action = 'U';
  };

  $scope.checkApprovalHistoryModified = function() {
    // Looping through privilegeReviews to find out if any have been updated, if so enable Refresh and Save buttons.
    var enable = false;
    if(typeof $scope.sublistHistoricPrivilegeReviews != 'undefined' && $scope.sublistHistoricPrivilegeReviews instanceof Array) {
      $scope.sublistHistoricPrivilegeReviews.filter(Boolean).forEach(function(privReview) {
        if(privReview.action === 'U') {
          enable = true
        };
      });
    };

    return enable;
  };

  $scope.selectAll = function() {
    $scope.data.filteredHistoricReviews.forEach(function(i) {
      i.action = 'U';
    });
  };

  $scope.revertVoteCast = function() {
    var privilegeReviewsToBeReverted = [];
    $scope.showPrivilegeReviewHistorySpinner = true;
    console.log("Revert Vote justification: ", $scope.data.revertJustification );

    $scope.sublistHistoricPrivilegeReviews.forEach(function(privReview) {
      if(privReview.action === 'U') {
        privReview.reviewComment = $scope.data.revertJustification;
        privilegeReviewsToBeReverted.push(privReview);
      }
    });

    console.log('Revert Vote Cast list: ', privilegeReviewsToBeReverted);

    privilegeReviewService.postRevertPrivilegeReviews(privilegeReviewsToBeReverted)
      .then(
        function(response) {          
          // Setting the Alert params
          $scope.showSuccessAlert = true;
          $scope.savedPrivReviewsCount = privilegeReviewsToBeReverted.length;
          $scope.initialize();
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  $scope.refreshApprovalHistory = function() {

    $scope.historicPrivilegeReviews = [];
    $scope.sublistHistoricPrivilegeReviews = [];
    $scope.historicPrivilegeReviewsRequests = [];
    $scope.activeHistoricPrivilegeReviewRequest = 'All';
    $scope.showPrivilegeReviewHistorySpinner = true; 

    $scope.retrieveHistoricPrivilegeReview(); 
  };

  $scope.retrieveHistoricPrivilegeReview = function() {
    // Retrieve historic privilege reviews for specific user
    privilegeReviewService.getHistoricPrivilegeReviews()
      .then(
        function(response) {
          $scope.historicPrivilegeReviews = response.data;
          $scope.historicPrivilegeReviews.forEach(function(historicPrivilegeReview) {
            $scope.addRoleName(historicPrivilegeReview); // Add a new property called RoleName based on ccwgRoleOrgId
            $scope.addAwsAccount(historicPrivilegeReview); // Add a new property called AwsAccount based on ccwgFinraAwsAccountsId
            $scope.addServiceApiActionName(historicPrivilegeReview); // Add serviceApiActionName, serviceApiPrefix, serviceShortName
          });

          $scope.sublistHistoricPrivilegeReviews = angular.copy($scope.historicPrivilegeReviews);

          //Array.prototype.push.apply($scope.sublistHistoricPrivilegeReviews, angular.copy($scope.historicPrivilegeReviews));
          $scope.createHistoricPrivilegeReviewsRequests();    
          $scope.createSublistColumnTableFilterHistory();
          $scope.showPrivilegeReviewHistorySpinner = false;      
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };


  /* Privilege Review History Column filters*/

    /*
      Watch change to privilege review  table results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('data.filteredHistoricReviews', function() {
      $scope.updateColumnFilterValuesOnChangeHistory(); 
    });

    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettingsHistory = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };
    // Creating a map between service name and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.serviceNameColumnIdMapHistory = {};
    $scope.apiPrefixColumnIdMapHistory = {};
    $scope.apiActionColumnIdMapHistory = {};
    $scope.envColumnIdMapHistory = {};
    $scope.roleNameColumnIdMapHistory = {};
    $scope.accountNameColumnIdMapHistory = {};

    $scope.clearColumnFilterAttributesHistory = function() {
        console.log('Clear column filter attirbutes History');
        $scope.selectedTableServicesHistory = [];
        $scope.selectedTableActionGsHistory = [];
        $scope.selectedTableApiPrefixHistory = [];
        $scope.selectedTableRolesHistory = [];
        $scope.selectedTableEnvsHistory = [];
        $scope.selectedTableOriginalHistory = [];
        $scope.selectedTableProposedHistory = [];
        $scope.selectedTableAccountsHistory = [];
        $scope.approvalHistorySearchKeyword = '';
    };

    // Help's us figure out which filter made the change
    // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env/ Role/ Account
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModifiedHistory = {
      'serviceName': false,
      'apiPrefix': false,
      'actionGs': false,
      'env': false,
      'role': false,
      'account': false
    };    

    // Column Service filter attributes
    $scope.selectedTableServicesHistory = [];   
    $scope.servicesDataHistory = [];     // Data that gets displayed on Column Service Filter
    // ng-dropdown-multiselect event listeners
    $scope.serviceNameEventListenersHistory = {
       onSelectionChanged: function() {
        if($scope.selectedTableServicesHistory.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': true,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }      
      }
    };

    $scope.columnServiceFilterHistory = function(i) {
      var serviceNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableServicesHistory.length > 0) {
        $scope.selectedTableServicesHistory.forEach(function(selectedEntry) {
          serviceNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.serviceNameShort, serviceNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    // Column Service Api Prefix filter attributes
    $scope.selectedTableApiPrefixHistory = [];   
    $scope.apiPrefixDataHistory = [];     // Data that gets displayed on Column Api Prefix Filter
    $scope.apiPrefixEventListenersHistory = {
      onSelectionChanged: function() {
        if($scope.selectedTableApiPrefixHistory.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': true,'actionGs': false,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnApiPrefixFilterHistory = function(i) {
      var apiPrefixes = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableApiPrefixHistory.length > 0) {
        $scope.selectedTableApiPrefixHistory.forEach(function(selectedEntry) {
          apiPrefixes.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionPrefix, apiPrefixes) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column ServiceApi Action filter attributes
    $scope.selectedTableActionGsHistory = [];   
    $scope.serviceApiActionsDataHistory = [];     // Data that gets displayed on Column Service Api Action Filter
    $scope.actionGsEventListenersHistory = {
      onSelectionChanged: function() {
        if($scope.selectedTableActionGsHistory.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': true,'env': false,'role': false,'account': false};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnServiceApiActionFilterHistory = function(i) {
      var serviceApiActionNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableActionGsHistory.length > 0) {
        $scope.selectedTableActionGsHistory.forEach(function(selectedEntry) {
          serviceApiActionNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.apiActionName, serviceApiActionNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Envs filter attributes
    $scope.selectedTableEnvsHistory = [];   
    $scope.envsDataHistory = [];     // Data that gets displayed on Column Envs Filter
    $scope.envEventListenersHistory = {
      onSelectionChanged: function() {
        if($scope.selectedTableEnvs.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': true,'role': false,'account': false};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnEnvFilterHistory = function(i) {
      var envNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableEnvsHistory.length > 0) {
        $scope.selectedTableEnvsHistory.forEach(function(selectedEntry) {
          envNames.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.environment, envNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    // Column Roles filter attributes
    $scope.selectedTableRolesHistory = [];   
    $scope.rolesDataHistory = [];     // Data that gets displayed on Column Envs Filter
    $scope.roleEventListenersHistory = {
      onSelectionChanged: function() {
        if($scope.selectedTableRolesHistory.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': true,'account': false};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnRoleFilterHistory = function(i) {
      var roles = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableRolesHistory.length > 0) {
        $scope.selectedTableRolesHistory.forEach(function(selectedEntry) {
          roles.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.roleName, roles) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableOriginalHistory = []; // Selected Original Value from column filter
    $scope.selectedTableProposedHistory = []; // Selected Proposed Value from column filter
    // Original Config also has Empty value, hence splitting config data into Original and Proposed
    $scope.configurationOriginalDataHistory = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}, {id: 3, label: 'Empty'}];
    $scope.configurationProposedDataHistory = [{id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];

    $scope.columnOriginalValueFilterHistory = function(i) {
      var originalValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableOriginalHistory.length > 0) {
        $scope.selectedTableOriginalHistory.forEach(function(selectedEntry) {
          originalValue.push(selectedEntry.label);
        });

        if($.inArray((i.fromValue === null ? 'Empty' : i.fromValue), originalValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };

    $scope.columnProposedValueFilterHistory = function(i) {
      var proposedValue = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableProposedHistory.length > 0) {
        $scope.selectedTableProposedHistory.forEach(function(selectedEntry) {
          proposedValue.push(selectedEntry.label);
        });

        if($.inArray(i.toValue, proposedValue) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };
    
    $scope.selectedTableAccountsHistory = [];   
    $scope.accountsDataHistory = [];     // Data that gets displayed on Column Envs Filter
    $scope.accountEventListenersHistory = {
      onSelectionChanged: function() {
        if($scope.selectedTableAccountsHistory.length > 0) {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': true};
        } else {
          $scope.columnFilterModifiedHistory = {'serviceName': false,'apiPrefix': false,'actionGs': false,'env': false,'role': false,'account': false};
        }
      }
    };

    $scope.columnAccountFilterHistory = function(i) {
      var accounts = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableAccountsHistory.length > 0) {
        $scope.selectedTableAccountsHistory.forEach(function(selectedEntry) {
          accounts.push(selectedEntry.label);
        });

        if($.inArray(i.privilegeEntity.awsAccount, accounts) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;    
    };


    // Creates data for Column Filters from $scope.sublistHistoricPrivilegeReviews
    $scope.createSublistColumnTableFilterHistory = function() {
      // Setting serviceData array for service column table filter
      var uniqueServiceNames = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.serviceNameShort');
      $scope.createGenericColumnMap(uniqueServiceNames, $scope.serviceNameColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueServiceNames, $scope.servicesDataHistory, $scope.serviceNameColumnIdMapHistory);

      var uniqueApiPrefixes = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.apiActionPrefix');
      $scope.createGenericColumnMap(uniqueApiPrefixes, $scope.apiPrefixColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueApiPrefixes, $scope.apiPrefixDataHistory, $scope.apiPrefixColumnIdMapHistory);

      var uniqueApiActions = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.apiActionName');
      $scope.createGenericColumnMap(uniqueApiActions, $scope.apiActionColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueApiActions, $scope.serviceApiActionsDataHistory, $scope.apiActionColumnIdMapHistory);

      var uniqueEnvs = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.environment');
      $scope.createGenericColumnMap(uniqueEnvs, $scope.envColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueEnvs, $scope.envsDataHistory, $scope.envColumnIdMapHistory);

      var uniqueRoles = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.roleName');
      $scope.createGenericColumnMap(uniqueRoles, $scope.roleNameColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueRoles, $scope.rolesDataHistory, $scope.roleNameColumnIdMapHistory);

      var uniqueAccounts = $scope.getGenericFieldValues($scope.sublistHistoricPrivilegeReviews, 'privilegeEntity.awsAccount');
      $scope.createGenericColumnMap(uniqueAccounts, $scope.accountNameColumnIdMapHistory);       
      $scope.createGenericColumnFilterValues(uniqueAccounts, $scope.accountsDataHistory, $scope.accountNameColumnIdMapHistory);
    };

    /**
      Method get's called when table rows are filtered and this needs readjustment of the column values
    */
    $scope.updateColumnFilterValuesOnChangeHistory = function() {
      console.log("Inside Column filter History values!!");
      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do $scope.servicesData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModifiedHistory.serviceName === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.serviceNameShort'), 
          $scope.servicesDataHistory, $scope.serviceNameColumnIdMapHistory);
      };

      if($scope.columnFilterModifiedHistory.apiPrefix === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.apiActionPrefix'), 
          $scope.apiPrefixDataHistory, $scope.apiPrefixColumnIdMapHistory);
      };

      if($scope.columnFilterModifiedHistory.actionGs === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.apiActionName'), 
          $scope.serviceApiActionsDataHistory, $scope.apiActionColumnIdMapHistory);
      };

      if($scope.columnFilterModifiedHistory.env === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.environment'), 
          $scope.envsDataHistory, $scope.envColumnIdMapHistory);
      };

      if($scope.columnFilterModifiedHistory.role === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.roleName'), 
          $scope.rolesDataHistory, $scope.roleNameColumnIdMapHistory);
      };

      if($scope.columnFilterModifiedHistory.account === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.data.filteredHistoricReviews, 'privilegeEntity.awsAccount'), 
          $scope.accountsDataHistory, $scope.accountNameColumnIdMapHistory);
      };
    };

    /* End */



  /**
    Initialize method which does the following
      (1) Loads UnApproved Privilege Reviews for specific user
      (2) Loads historic privilege reviews for specific user

  */
  $scope.initialize = function() {
   
    $scope.privilegeReviews = [];
    $scope.sublistPrivilegeReviews = [];
    $scope.originalPrivilegeReviews = [];
    $scope.privilegeReviewsRequests = [];
    $scope.activePrivilegeReviewRequest = 'All';

    $scope.historicPrivilegeReviews = [];
    $scope.sublistHistoricPrivilegeReviews = [];
    $scope.historicPrivilegeReviewsRequests = [];
    $scope.activeHistoricPrivilegeReviewRequest = 'All';

    $scope.data.activeButtonStatus = 'uncheck';
    $scope.data.reviewComments = null;
    $scope.data.revertJustification = null;

    $scope.clearColumnFilterAttributes();
    $scope.clearColumnFilterAttributesHistory();

    $scope.showPrivilegeReviewSpinner = true;
    $scope.showPrivilegeReviewHistorySpinner = true;

    // Retrieve Aws Account to be displayed in the table
    awsAccountService.getAwsAccounts()
      .then(
          function(response) {
            $scope.awsAccountEntities = response.data;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
      );


    // Get Summary of bulk Request Titles (privilege reviews >= 100) for a particular user
    privilegeReviewService.getBulkPrivilegeReviewRequestTitleInfo()
      .then(
        function(response) {
          $scope.bulkRequestsInfo = response.data;   
          angular.copy($scope.bulkRequestsInfo, $scope.originalBulkRequestsInfo);
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );


    // Get UnApproved Lean Request Titles (privilege reviews < 100) for a particular user
    privilegeReviewService.getUnApprovedLeanRequests()
      .then(
        function(response) {
          $scope.privilegeReviews = response.data;
          Array.prototype.push.apply($scope.originalPrivilegeReviews, angular.copy($scope.privilegeReviews));
          if($scope.privilegeReviews.length === 0) {
            $scope.showPrivilegeReviewSpinner = false;
          }   
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Adding envs creation here coz lookup service takes some time to load envs.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.responseTypes = response.privReviewResponses;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    // Retrieve service api actions
    serviceRest.getServiceApiActions()
      .then(
        function(response) {
          $scope.serviceApiActionEntities = response.data;        
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

      $scope.retrieveHistoricPrivilegeReview(); 
  };

  $scope.initialize(); 




}]);