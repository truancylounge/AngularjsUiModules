ccwgApp.controller('PrivilegeApprovalHistoryLogModalController', ['$scope', '$uibModalInstance', 'logEntities', '$sessionStorage', 
	function($scope, $uibModalInstance, logEntities, $sessionStorage) {
  console.log("Entering Privilege Approval Hisotry Log modal Controller");

  $scope.logEntities = logEntities;

	$scope.getUserName = function(userId) {
	    var userName;

		if(userId !== undefined) {
			$sessionStorage.users.some(function(user) {
			  if(user.userId.toUpperCase() === userId.toUpperCase()) 
			    userName = user.userName;
			});
		}

	    return userName;
	};    


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);