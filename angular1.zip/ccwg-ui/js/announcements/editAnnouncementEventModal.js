ccwgApp.controller('EditAnnouncementEventModalController', ['$scope', '$uibModalInstance', 'editAnnouncementEvent', 'announcementEvents', 'announcementEventTypes', 'tags',
        function($scope, $uibModalInstance, editAnnouncementEvent, announcementEvents, announcementEventTypes, tags) {

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  $scope.categoryTagsSelected = false;

  $scope.announcementEventTypes = announcementEventTypes;  

  $scope.eventType = editAnnouncementEvent.eventType;
  $scope.eventDescription = editAnnouncementEvent.eventDescription;

  $scope.categoryTags = [];
  $scope.optionalTags = [];

  $scope.selectedCategoryTags = editAnnouncementEvent.categoryTags != null ? editAnnouncementEvent.categoryTags.split(",") : [];
  $scope.selectedOptionalTags = editAnnouncementEvent.optionalTags != null ? editAnnouncementEvent.optionalTags.split(",") : []; 


  tags.forEach(function(tag) {
    if(tag.isDashboardTag) {
      $scope.categoryTags.push(tag.tagName);
    } else {
      $scope.optionalTags.push(tag.tagName);
    }        
  });

  $scope.updateSelectedCategoryTags = function(data) {
    $scope.selectedCategoryTags = data;

    if($scope.selectedCategoryTags.length === 0) {
      $scope.safeApply(function() {
        $scope.categoryTagsSelected = false;
      });
      
    } else {
      $scope.safeApply(function() {
        $scope.categoryTagsSelected = true;
      });
    }
  };

  $scope.updateSelectedOptionalTags = function(data) {
    $scope.selectedOptionalTags = data;
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.editAnnouncementEvent = function() {
    announcementEvents.some(function(announcementEvent) {
      if(announcementEvent.id === editAnnouncementEvent.id) {
        announcementEvent.eventType = $scope.eventType;
        announcementEvent.eventDescription = $scope.eventDescription;
        announcementEvent.categoryTags = $scope.selectedCategoryTags.toString();
        announcementEvent.optionalTags = $scope.selectedOptionalTags.toString();
        announcementEvent.action = 'U';
      };
    });

    $uibModalInstance.close();
  };
}]);

ccwgApp.controller('AddAnnouncementEventModalController', ['$scope', '$uibModalInstance', 'announcementEvents', 'announcementEventTypes', 'tags',
        function($scope, $uibModalInstance, announcementEvents, announcementEventTypes, tags) {  

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  $scope.categoryTagsSelected = false;

  // Loop through Announcement Events and remove announcement Event Types that already exist in Announcement Events
  announcementEvents.forEach(function(announcementEvent) {
    announcementEventTypes.forEach(function(entry, index) {
      if(announcementEvent.eventType === entry) {
        announcementEventTypes.splice(index, 1);
      }
    })
  });

  $scope.announcementEventTypes = announcementEventTypes;  
  $scope.eventType;
  $scope.eventDescription;

  $scope.categoryTags = [];
  $scope.optionalTags = [];

  $scope.selectedCategoryTags = [];
  $scope.selectedOptionalTags = []; 

  tags.forEach(function(tag) {
    if(tag.isDashboardTag) {
      $scope.categoryTags.push(tag.tagName);
    } else {
      $scope.optionalTags.push(tag.tagName);
    }        
  });

  $scope.updateSelectedCategoryTags = function(data) {
    $scope.selectedCategoryTags = data;

    if($scope.selectedCategoryTags.length === 0) {
      $scope.safeApply(function() {
        $scope.categoryTagsSelected = false;
      });
      
    } else {
      $scope.safeApply(function() {
        $scope.categoryTagsSelected = true;
      });
    }
  };

  $scope.updateSelectedOptionalTags = function(data) {
    $scope.selectedOptionalTags = data;
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addAnnouncementEvent = function() {
    announcementEvents.push({
      "eventType": $scope.eventType,
      "eventDescription": $scope.eventDescription,
      "categoryTags": $scope.selectedCategoryTags.toString(),
      "optionalTags": $scope.selectedOptionalTags.toString(),
      "action": 'I',
      "isActive": true
    });

    $uibModalInstance.close();
  };
}]);