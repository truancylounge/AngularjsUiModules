ccwgApp.controller('AnnouncementEventListController', ['$scope', '$uibModal', 'envService', 'announcementEventService', '$sessionStorage', 'lookupService', 'tagService',
        function($scope, $uibModal, envService, announcementEventService, $sessionStorage, lookupService, tagService) {


  $scope.announcementEvents = [];
  $scope.announcementEventTypes = [];
  $scope.tags = [];

  $scope.sortType = 'updatedDate'; // set the default sort type
  $scope.sortReverse  = true;  // set the default sort order

  $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after Announcement Events have been saved
    $scope.showSuccessAlert = false;
    $scope.savedAnnouncementEvents = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showAnnouncementEventsSpinner = false;
    
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedAnnouncementEvents = 0;
    };

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through Announcement Events to find out if announcementEvent has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.announcementEvents.forEach(function(announcementEvent) {
        if(announcementEvent.action === 'U' || announcementEvent.action === 'I') {
          enable = true;
        };
      });

      return enable;
    }; 

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.announcementEvents.some(function(announcementEvent) {
        if(announcementEvent.id === i.id) {
          announcementEvent.action = 'U';
        };
      });    
    };    

    $scope.activeFilter = function (i) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return i;
          case 'off':
            return i.isActive == false;
          case 'on':
            return i.isActive == true;
        }
    }; 

    $scope.dirtyRecordFilter = function(i) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return i;
          case 'on':
            return (i.action === 'U' || i.action === 'I');
        }

    };

    $scope.addAnnouncementEventOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/announcements/addAnnouncementEventModal.html',
        controller: 'AddAnnouncementEventModalController',
        resolve: {
          announcementEvents: function() { return $scope.announcementEvents;},
          announcementEventTypes: function() {return $scope.announcementEventTypes;},
          tags: function() {return $scope.tags;}
        }
      });
    };


    $scope.editAnnouncementEventOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/announcements/editAnnouncementEventModal.html',
        controller: 'EditAnnouncementEventModalController',
        resolve: {
          editAnnouncementEvent: function(){ return i;},
          announcementEvents: function() { return $scope.announcementEvents;},
          announcementEventTypes: function() {return $scope.announcementEventTypes;},
          tags: function() {return $scope.tags;}
        }
      });
    };

    $scope.revertAnnouncementEvents= function() {
      console.log("Reverting Announcement Events back to original copy from server.")
      $scope.retrieveAllAnnouncementEvents();
    };

    $scope.updateAnnouncementEvents = function() {
      var updatedEvents = $scope.announcementEvents.filter(function(announcementEvent) {
        return announcementEvent.action === 'I' || announcementEvent.action === 'U';
      });

      console.log('Updated Events: ', updatedEvents);

      announcementEventService.postAnnouncementEvents(updatedEvents)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.savedAnnouncementEvents = updatedEvents.length;

            $scope.retrieveAllAnnouncementEvents();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };


    $scope.retrieveAllAnnouncementEvents = function() {

      $scope.showAnnouncementEventsSpinner = true;

      announcementEventService.getAnnouncementEvents()
        .then(
            function(response) {
              $scope.announcementEvents = response.data;
              $scope.showAnnouncementEventsSpinner = false;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
          );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            $scope.announcementEventTypes = response.announcementEventTypes;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      tagService.getTags()
        .then(
            function(response) {
              $scope.tags = response.data;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
        );
    }

    $scope.retrieveAllAnnouncementEvents();    
}]);