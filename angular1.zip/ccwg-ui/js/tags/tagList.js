ccwgApp.controller('TagListController', ['$scope', '$uibModal', 'envService', 'tagService', '$sessionStorage', 'lookupService',
        function($scope, $uibModal, envService, tagService, $sessionStorage, lookupService) {

    $scope.tags = [];
    $scope.userRoles = [];

    $scope.dashboardTags = {
        selected: null,
        values: [],
        dirty: false
    };

    $scope.sortType = 'updatedDate'; // set the default sort type
    $scope.sortReverse  = true;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after Tags have been saved
    $scope.showSuccessAlert = false;
    $scope.savedTags = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showTagsSpinner = false;
    
    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedTags = 0;
    };

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
    };

    $scope.createDashboardTags = function() {

      var filteredTags = $scope.tags.filter(function(tag) {
        return tag.isDashboardTag === true && tag.isActive;
      });

      // Filter Tags in Ascending Order base on priority. 1 = Highest Priority, n = Lowest Priority
      filteredTags.sort(function(value1, value2) {
        return value1.dashboardOrdinal - value2.dashboardOrdinal;
      });

      // Create Dashboard Tags
      filteredTags.forEach(function(tag) {
        if(tag.isDashboardTag === true) {
          $scope.dashboardTags.values.push({'label': tag.tagName});
        }
      });
    };

    // This function is called by dnd-moved event when Dashboard Tags get reordered.
    $scope.reorderDashboardTags = function(index) {
      // The dirty flag impacts the Save Button visibility
      $scope.dashboardTags.dirty = true;
      $scope.dashboardTags.values.splice(index, 1);
      console.log($scope.dashboardTags);
    };

    // Revert Dashboard Ordinal Order to original
    $scope.revertDashboardTagsOrdinal = function() {
      $scope.dashboardTags = {
        selected: null,
        values: [],
        dirty: false
      };

      $scope.createDashboardTags();
    };

    // Save the Dashboard Ordinal reorder
    $scope.saveDashboardTagsOrdinal = function() {

      //Iterate over $scope.tags and change the dashboardOrdinal value based on dashboardTags.values
      var ordinal = 0;
      $scope.dashboardTags.values.forEach(function(value) {
        ordinal = ordinal + 1;
        // Find the tagName in $scope.tags and add the ordinal
        $scope.tags.forEach(function(tag) {
          if(tag.tagName === value.label) {
            console.log("Entering here");
            tag.action = "U";
            tag.dashboardOrdinal = ordinal;
          };
        });
      });

      // Call the updateTags() to post tags
      $scope.updateTags();

      // Reset $scope.dashboardTags
      $scope.dashboardTags = {
        selected: null,
        values: [],
        dirty: false
      };
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through tags to find out if tag has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.tags.forEach(function(tag) {
        if(tag.action === 'U' || tag.action === 'I') {
          enable = true;
        };
      });

      return enable;
    }; 

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.tags.some(function(tag) {
        if(tag.id === i.id) {
          tag.action = 'U';
        };
      });    
    };    

    $scope.isDashboardToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.tags.some(function(tag) {
        if(tag.id === i.id) {
          tag.action = 'U';
        };
      });    
    };   

    $scope.activeFilter = function (tag) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return tag;
          case 'off':
            return tag.isActive == false;
          case 'on':
            return tag.isActive == true;
        }
    }; 

    $scope.dirtyRecordFilter = function(tag) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return tag;
          case 'on':
            return (tag.action === 'U' || tag.action === 'I');
        }

    };

    $scope.revertTags= function() {
      console.log("Reverting Tags back to original copy from server.")
      $scope.retrieveAllTags();
    };

    // Add & Edit Tag Modals
    $scope.editTagOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/tags/editTagModal.html',
        controller: 'EditTagModalController',
        resolve: {
          editTag: function(){ return i;},
          tags: function() { return $scope.tags;},
          userRoles: function() {return $scope.userRoles;}
        }
      });
    };    

    $scope.addTagOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/tags/addTagModal.html',
        controller: 'AddTagModalController',
        resolve: {
          tags: function() { return $scope.tags;},
          userRoles: function() {return $scope.userRoles;}
        }
      });
    };    

    // Add New / Update Existing Tags
    $scope.updateTags = function() {
      // Rather than sending all the tags, only send the Tag's that were modified
      var updatedTags = $scope.tags.filter(function(tag) {
        return tag.action === 'I' || tag.action === 'U';
      });

      tagService.postTags(updatedTags)
        .then(
          function(response) {
            // Setting the Alert params
            $scope.showSuccessAlert = true;
            $scope.savedTags = updatedTags.length;
            
            $scope.retrieveAllTags();
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };

    //Retrieve Tags / Initialze Page Section

    $scope.retrieveAllTags = function() {

      $scope.showTagsSpinner = true;
      // Reseting the Dashboard Tags
      $scope.dashboardTags = {
        selected: null,
        values: [],
        dirty: false
      };

      tagService.getTags()
        .then(
            function(response) {
              $scope.tags = response.data;
              $scope.createDashboardTags();
              $scope.showTagsSpinner = false;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
          );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            var userRoles = response.userRoles;
            var auxUserRoles = response.auxiliaryRoles;
            $scope.userRoles = userRoles.concat(auxUserRoles);

          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );  



    };


    $scope.retrieveAllTags();

    
 
    
}]);