ccwgApp.controller('EditTagModalController', ['$scope', '$uibModalInstance', 'editTag', 'tags', 'userRoles',
        function($scope, $uibModalInstance, editTag, tags, userRoles) {

  $scope.userRoles = userRoles;

  $scope.tagName = editTag.tagName;
  $scope.tagDescription = editTag.tagDescription;
  $scope.selectedManageRolesList = editTag.rolesCanManage !== null ? editTag.rolesCanManage.split(",") : [];
  $scope.selectedViewRolesList = editTag.rolesCanView !== null ? editTag.rolesCanView.split(",") : [];
  

  $scope.selectedManageUserRoles = function(data) {
    $scope.selectedManageRolesList = data;
  };

  $scope.selectedViewUserRoles = function(data) {
    $scope.selectedViewRolesList = data;
  };
  

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.editTag = function() {
    tags.some(function(tag) {
      if(tag.id === editTag.id) {
        tag.tagName = $scope.tagName;
        tag.tagDescription = $scope.tagDescription;
        tag.rolesCanManage = $scope.selectedManageRolesList.toString();
        tag.rolesCanView = $scope.selectedViewRolesList.toString();
        tag.action = 'U';
      };
    });

    $uibModalInstance.close();
  };
}]);

ccwgApp.controller('AddTagModalController', ['$scope', '$uibModalInstance', 'tags', 'userRoles',  
  function($scope, $uibModalInstance, tags, userRoles) {

  $scope.userRoles = userRoles;

  $scope.tagName;
  $scope.tagDescription;
  $scope.selectedManageRolesList = [];
  $scope.selectedViewRolesList = [];

  $scope.selectedManageUserRoles = function(data) {
    $scope.selectedManageRolesList = data;
  };

  $scope.selectedViewUserRoles = function(data) {
    $scope.selectedViewRolesList = data;
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addTag = function() {
    tags.push({
      "tagName": $scope.tagName,
      "tagDescription": $scope.tagDescription,
      "rolesCanManage": $scope.selectedManageRolesList.toString(),
      "rolesCanView": $scope.selectedViewRolesList.toString(),
      "action": 'I',
      "isActive": true
    });

    $uibModalInstance.close();
  };
    
}]);
