ccwgApp.controller('RoleListController', ['$scope', '$http', '$uibModal', 'envService', 'roleService', '$sessionStorage', 'lookupService',
        function($scope, $http, $uibModal, envService, roleService, $sessionStorage, lookupService) {

    // Debug Environment variables 
    //$scope.environment = envService.get();
    //console.log('Current env: ' + $scope.environment);
    //$scope.vars = envService.read('all');
    //console.log($scope.vars);
    $scope.roles = [];
    $scope.envs = [];

    $scope.sortType = 'updatedDate'; // set the default sort type
    $scope.sortReverse  = true;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');    
    $scope.itemsPerPage = envService.read('itemsPerPage');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after services have been saved
    $scope.showSuccessAlert = false;
    $scope.savedRolesCount = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showRolesSpinner = false;

    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedRolesCount = 0;
    };    

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
    }

    $scope.activeClicked = function() {
      console.log("Active Button Status : " + $scope.activeButtonStatus);
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through roles to find out if roles has been updated, if so enable Revert and Save buttons.
      var enable = false;
      if(typeof $scope.roles != 'undefined' && $scope.roles instanceof Array) {
        $scope.roles.filter(Boolean).forEach(function(role) {
          if(role.action === 'U' || role.action === 'I') {
            enable = true;
          };
        });
      };
      return enable;
    };

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.roles.some(function(role) {
        if(role.id === i.id) {
          role.action = 'U';
        };
      });    
    };

    $scope.activeFilter = function (role) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return role;
          case 'off':
            return role.isActive == false;
          case 'on':
            return role.isActive == true;
        }
    };

    $scope.dirtyRecordFilter = function(role) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return role;
          case 'on':
            return (role.action === 'U' || role.action === 'I');
        }

    };

    $scope.revertRoles = function() {
      $scope.retrieveAllRoles();
    };

    $scope.addRoleOpen = function() {
      var modalInstance = $uibModal.open({
        templateUrl: 'html/roles/addRoleModal.html',
        controller: 'AddRoleModalController',
        resolve: {
          roles: function() { return $scope.roles;},
          envs: function() {return $scope.envs;}
        }
      });
    };


    $scope.editRoleOpen = function(i) {
      var modalInstance = $uibModal.open({
        templateUrl: 'html/roles/editRoleModal.html',
        controller: 'EditRoleModalController',
        resolve: {
          editRole: function(){ return i;},
          roles: function() { return $scope.roles;},
          envs: function() {return $scope.envs;}
        }
      });
    };

    $scope.retrieveAllRoles = function() {
      $scope.showRolesSpinner = true;
      roleService.getRoles()
        .then(
          function(response) {
            // If User has Admin roles, show all the roles else, show only un archived roles
            if($.inArray('Admin', $sessionStorage.user.permissions) !== -1) {
              $scope.roles = response.data;
            } else {
              response.data.forEach(function(roleEntity) {
                if(roleEntity.isActive === true) {
                  $scope.roles.push(roleEntity);
                }                
              });
            }
            
            $scope.showRolesSpinner = false;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            $scope.envs = response.environments;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );
    };        

    $scope.updateRoles = function() {
      var updatedRoles = [];
      $scope.roles.forEach(function(role) {
        if(role.action === 'U' || role.action === 'I') {
          updatedRoles.push(role);
        }
      });

      roleService.postRoles(updatedRoles)
              .then(
                function(response) {
                  // Setting the Alert params
                  $scope.showSuccessAlert = true;
                  $scope.savedRolesCount = updatedRoles.length;

                  $scope.retrieveAllRoles();
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
              );
     }; 

    $scope.retrieveAllRoles();



/* Watch example
    $scope.$watch('searchKeyword', function(newValue, oldValue) {
      console.log('Changed ');
      console.log('Old: ' + oldValue);
      console.log('New: ' + newValue);
    });
*/

//$('.bs-switch').bootstrapSwitch();   
    
}]);