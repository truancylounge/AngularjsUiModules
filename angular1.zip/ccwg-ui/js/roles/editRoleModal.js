ccwgApp.controller('EditRoleModalController', ['$scope', '$uibModalInstance', 'editRole', 'roles', 'envs', function($scope, $uibModalInstance, editRole, roles, envs) {
  
  $scope.roleName = editRole.roleName;
  $scope.roleDescription = editRole.roleDescription;
  $scope.allowedEnvs = envs;

  $scope.selectedAllowedEnvsList = editRole.allowedEnvs != null ? editRole.allowedEnvs.split(",") : [];

  $scope.selectedAllowedEnvs = function(data) {
    $scope.selectedAllowedEnvsList = data;
  };

  $scope.editRole = function() {
    // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
    roles.some(function(role) {
      if(role.id === editRole.id) {
        role.roleName = $scope.roleName;
        role.roleDescription = $scope.roleDescription;
        role.allowedEnvs = $scope.selectedAllowedEnvsList.toString();
        role.action = 'U';
      };
    });       

    $uibModalInstance.close();

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);

ccwgApp.controller('AddRoleModalController', ['$scope', '$uibModalInstance', 'roles', 'envs', function($scope, $uibModalInstance, roles, envs) {
  
  $scope.roleName;
  $scope.roleDescription;
  $scope.allowedEnvs = envs;

  $scope.selectedAllowedEnvsList = [];

  $scope.selectedAllowedEnvs = function(data) {
    $scope.selectedAllowedEnvsList = data;
  };

  $scope.addRole = function() {
    roles.push({
      "roleName": $scope.roleName,
      "roleDescription": $scope.roleDescription,
      "allowedEnvs": $scope.selectedAllowedEnvsList.toString(),
      "action": "I",
      "isActive": true
    });

    $uibModalInstance.close();
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
    
}]);