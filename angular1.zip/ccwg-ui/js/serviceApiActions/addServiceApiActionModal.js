ccwgApp.controller('AddServiceApiActionModalController', ['$scope', '$uibModalInstance', 'lookupService', 'service', function($scope, $uibModalInstance, lookupService, service) {

  console.log(service);
  $scope.titleSegment = "Add";

  $scope.apiGsRiskRankings = []; 


  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addServiceApiAction = function() {
    service.action = 'U';
    service.serviceApiActionEntityList.push({
      "apiActionName": $scope.apiActionName, 
      "apiActionPrefix": $scope.apiActionPrefix,
      "apiActionDescription": $scope.apiActionDescription,
      "apiVersion": $scope.apiVersion,
      "apiGsRiskRanking": $scope.apiGsRiskRanking,
      "apiActionReference": $scope.apiActionReference,
      "isActive": true,
      "action": 'I'
    });

    $uibModalInstance.close();    

  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.apiGsRiskRankings = response.apiGsRiskRankings;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );    
}]);