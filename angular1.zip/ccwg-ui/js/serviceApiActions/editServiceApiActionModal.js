ccwgApp.controller('EditServiceApiActionModalController', ['$scope', '$uibModalInstance', 'lookupService', 'service', 'serviceApiAction', function($scope, $uibModalInstance, lookupService, service, serviceApiAction) {

  console.log("serviceapi action: ", serviceApiAction);

  $scope.titleSegment = "Edit";
  $scope.apiGsRiskRankings = [];

  $scope.apiActionName = serviceApiAction.apiActionName;
  $scope.apiActionPrefix = serviceApiAction.apiActionPrefix;
  $scope.apiActionDescription = serviceApiAction.apiActionDescription;
  $scope.apiVersion = serviceApiAction.apiVersion;
  $scope.apiGsRiskRanking = serviceApiAction.apiGsRiskRanking;
  $scope.apiActionReference = serviceApiAction.apiActionReference;

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addServiceApiAction = function() {
    service.action = 'U';
    service.serviceApiActionEntityList.some(function(serviceApiActionEntity) {
      if(serviceApiActionEntity.id == serviceApiAction.id) {
        serviceApiActionEntity.apiActionName =  $scope.apiActionName;
        serviceApiActionEntity.apiActionPrefix =  $scope.apiActionPrefix;
        serviceApiActionEntity.apiActionDescription =  $scope.apiActionDescription;
        serviceApiActionEntity.apiVersion =  $scope.apiVersion;
        serviceApiActionEntity.apiGsRiskRanking =  $scope.apiGsRiskRanking;
        serviceApiActionEntity.apiActionReference = $scope.apiActionReference;
        serviceApiActionEntity.action = 'U';
      };
    });

    $uibModalInstance.close();
  };

  lookupService.retrieveReferences()
    .then(
      function(response) {
        $scope.apiGsRiskRankings = response.apiGsRiskRankings;
      },
      function(response) {
        alert( "failure message: " + JSON.stringify({data: response.data}));
      }
    );
    
}]);