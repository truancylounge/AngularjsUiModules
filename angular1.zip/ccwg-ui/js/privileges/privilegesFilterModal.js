ccwgApp.controller('SaveNewFilterModalController', ['$scope', '$uibModalInstance', 'userService', 'selectedRoles', 'selectedServices', 'selectedEnvs', 'roles', 'services', 'envs', '$sessionStorage',
  function($scope, $uibModalInstance, userService, selectedRoles, selectedServices, selectedEnvs, roles, services, envs, $sessionStorage) {


  $scope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if(phase == '$apply' || phase == '$digest') {
        if(fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };


    $scope.filterName;
    $scope.selectedRolesList = selectedRoles;
    $scope.selectedServicesList = selectedServices;
    $scope.selectedEnvList = selectedEnvs;
    
    $scope.filterOptions = [{
      name: 'Default Filter',
      checked: false

    }, {
      name: 'Global Filter',
      checked: false
    }]

    $scope.roles = roles;
    $scope.services = services;
    $scope.envs = envs;

    $scope.userFiltersJson = [];

    $scope.saveNewFilter = function() {

      var userId = $sessionStorage.user.name;

      $scope.userFiltersJson.push({
        "userId": userId, 
        "roleFilter": $scope.selectedRolesList.join(","), 
        "serviceFilter": $scope.selectedServicesList.join(","),
        "envFilter": $scope.selectedEnvList.join(",") === "" ? null : $scope.selectedEnvList.join(","),
        "filterName": $scope.filterName,
        "defaultFlag": $scope.filterOptions[0].checked,
        "globalFlag": $scope.filterOptions[1].checked,
        "action": "I"
      });


      userService.postUserFilters($scope.userFiltersJson, userId)
        .then(
          function(response) {
            $uibModalInstance.close($scope.userFiltersJson[0]);
          },
          function(response) {
            $uibModalInstance.dismiss(response);
          }
        );
    };

    // This method is called when roles are selected on the modal
    $scope.selectedRoles = function(data) {
       $scope.safeApply(function() {
        $scope.selectedRolesList = data;
      });        
    };

    // This method is called when services are selected on the modal
    $scope.selectedServices = function(data) {
      $scope.safeApply(function() {
        $scope.selectedServicesList = data;
      });       
    };

    // This method is called when envs are selected on the modal
    $scope.selectedEnvs = function(data) {
      $scope.safeApply(function() {
        $scope.selectedEnvList = data;
      });      
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

}]);


ccwgApp.controller('DeleteFilterModalController', ['$scope', '$uibModalInstance', 'userService', 'userPrivilegeFilter', 'userFilterEntities', '$sessionStorage',
  function($scope, $uibModalInstance, userService, userPrivilegeFilter, userFilterEntities, $sessionStorage) {

    $scope.userPrivilegeFilter = userPrivilegeFilter;
    $scope.userFilterEntities = userFilterEntities;

    $scope.userFiltersJson = [];

    $scope.deleteFilter = function() {

      var userId = $sessionStorage.user.name;
      var deleteUserFilterEntity;

      $scope.userFilterEntities.some(function(userFilterEntity) {
        if(userFilterEntity.filterName == $scope.userPrivilegeFilter)
          deleteUserFilterEntity = userFilterEntity;
      });

      $scope.userFiltersJson.push(deleteUserFilterEntity);

      console.log($scope.userFiltersJson);


      userService.deleteUserFilters($scope.userFiltersJson, userId)
        .then(
          function(response) {
            $uibModalInstance.close();
          },
          function(response) {
            $uibModalInstance.dismiss(response);
          }
        );
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };
}]);


ccwgApp.controller('SaveFilterModalController', ['$scope', '$uibModalInstance', 'userService', 'selectedRoles', 'selectedServices', 'selectedEnvs', 'roles', 'services', 'envs', 'userPrivilegeFilter', 'userFilterEntities', '$sessionStorage',
  function($scope, $uibModalInstance, userService, selectedRoles, selectedServices, selectedEnvs, roles, services, envs, userPrivilegeFilter, userFilterEntities, $sessionStorage) {


  $scope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if(phase == '$apply' || phase == '$digest') {
        if(fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };

    $scope.filterName = userPrivilegeFilter;
   
    $scope.filterOptions = [{
      name: 'Default Filter',
      checked: false

    }, {
      name: 'Global Filter',
      checked: false
    }]

    $scope.selectedRolesList = selectedRoles;
    $scope.selectedServicesList = selectedServices;
    $scope.selectedEnvList = selectedEnvs;

    $scope.roles = roles;
    $scope.services = services;
    $scope.envs = envs;

    $scope.userPrivilegeFilter = userPrivilegeFilter;
    $scope.userFilterEntities = userFilterEntities;
    
    $scope.userFilterEntities.some(function(userFilterEntity) {
        if(userFilterEntity.filterName == $scope.userPrivilegeFilter) {
          $scope.filterOptions[0].checked = userFilterEntity.defaultFlag;
          $scope.filterOptions[1].checked = userFilterEntity.globalFlag;
        }          
    });

    $scope.updateFilterSelection = function(position, filterOptions) {
      angular.forEach(filterOptions, function(filterOption, index) {
        if (position != index)
          filterOption.checked = false;
      });
    }

    $scope.userFiltersJson = [];

    $scope.saveFilter = function() {

      var userId = $sessionStorage.user.name;

      var saveUserFilterEntity;

      $scope.userFilterEntities.some(function(userFilterEntity) {
        if(userFilterEntity.filterName == $scope.userPrivilegeFilter)
          saveUserFilterEntity = userFilterEntity;
      });

      saveUserFilterEntity.roleFilter = $scope.selectedRolesList.join(",");
      saveUserFilterEntity.serviceFilter = $scope.selectedServicesList.join(",");
      saveUserFilterEntity.envFilter = $scope.selectedEnvList.join(",") === "" ? null : $scope.selectedEnvList.join(",");
      saveUserFilterEntity.defaultFlag = $scope.filterOptions[0].checked;
      saveUserFilterEntity.globalFlag = $scope.filterOptions[1].checked;

      saveUserFilterEntity.action = "U";

      $scope.userFiltersJson.push(saveUserFilterEntity);

      userService.postUserFilters($scope.userFiltersJson, userId)
        .then(
          function(response) {
            $uibModalInstance.close($scope.userFiltersJson[0]);
          },
          function(response) {
            $uibModalInstance.dismiss(response);
          }
        );
    };

    // This method is called when roles are selected on the modal
    $scope.selectedRoles = function(data) {
      $scope.safeApply(function() {
        $scope.selectedRolesList = data;
      });
    };

    // This method is called when services are selected on the modal
    $scope.selectedServices = function(data) {
      $scope.safeApply(function() {
        $scope.selectedServicesList = data;
      });      
    };

    // This method is called when envs are selected on the modal
    $scope.selectedEnvs = function(data) {
      $scope.safeApply(function() {
        $scope.selectedEnvList = data;
      });      
    };

    $scope.cancel = function () {
      $uibModalInstance.dismiss('cancel');
    };

}]);


ccwgApp.controller('JustificationModalController', ['$scope', '$uibModalInstance', function($scope, $uibModalInstance) {

  console.log("Entering Justification Modal Controller");
  $scope.requestTitle;
  $scope.justification;

  $scope.addJustification = function() {
    $uibModalInstance.close({requestTitle: $scope.requestTitle, justification: $scope.justification});

  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

}]);