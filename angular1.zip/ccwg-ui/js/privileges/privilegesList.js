ccwgApp.controller('PrivilegeListController', ['$scope', '$uibModal', 'envService', 'privilegeService', 'lookupService', 'roleService', 'serviceRest', 'userService', '$sessionStorage', '$timeout', 'fileService', 'awsAccountService',
        function($scope, $uibModal, envService, privilegeService, lookupService, roleService, serviceRest, userService, $sessionStorage, $timeout, fileService, awsAccountService) {

  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };


  $scope.privileges = [];
  $scope.deltaPrivileges = [];
  $scope.entries = [];
  $scope.pristineEntries = [];
  $scope.entriesCount = 0;
  $scope.privilegeWorkingSetTitle;      // Set to null when no data set loaded, Gold Source for GS data, AWS Account Name<ARN> when AWS Account selected

  $scope.showSidebar = true;
  $scope.showProgressBar = false;
  $scope.filterText = "Hide Filter";
  $scope.filterIcon = 'glyphicon-menu-left';

  $scope.sidebarToggle = function() {
      $scope.showSidebar = !$scope.showSidebar;
      $scope.filterText = $scope.filterText === 'Hide Filter' ? 'Show Filter' : 'Hide Filter';
      $scope.filterIcon = $scope.filterIcon === 'glyphicon-menu-left' ? 'glyphicon-menu-right' : 'glyphicon-menu-left'
  };

  // Validation messages for Left Filter
  $scope.leftFilterValidation = {
      roleFilterInvalid: true,
      serviceFilterInvalid: true,
      envFilterInvalid: true
    };

  $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
  };  

  // The role Entities are used to retrive the roleId during createPrivilege()
  $scope.roleEntities = [];
  $scope.serviceEntities = [];
  $scope.serviceApiActionEntities = [];
  $scope.serviceApiActionsLoaded = false;

  // User privilege filter entities
  $scope.userFilterEntities = [];
  // List of filter names
  $scope.userPrivilegeFilters = [];
  // Currently selected filter name
  $scope.userPrivilegeFilter;

  // Pagination attributes
  $scope.currentPage = envService.read('currentPage');
  $scope.itemsPerPage = envService.read('itemsPerPage');
  $scope.maxSize = envService.read('maxSize');

  $scope.policies = [];
  // This is set to false if user switches role to ConfigurationManager
  $scope.policyEditDisable = true;

  $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

  $scope.showPrivilegeFilterSpinner = false;
  $scope.showPrivilegesSpinner = false;

  // Attributes for filters
  $scope.services = [];
  $scope.roles = [];
  $scope.envs = [];
  // List of AWS FINRA Accounts 
  $scope.awsAccountEntities = [];
  $scope.selectedAwsAccountEntity = {};
  $scope.selectedAwsAccountEnvs = [];
  $scope.awsAccountNames = [];  
  $scope.selectedAwsAccountNames = [];

  $scope.selectedRolesList = [];
  $scope.selectedServicesList = []; 
  $scope.selectedEnvList = [];
  $scope.rolesLoaded = false;
  $scope.servicesLoaded = false;
  $scope.envsLoaded = false;
  $scope.awsAccountsLoaded = false;
  // Roles to filter the privs table
  $scope.tableRolesList = [];

  // Back end pagination params
  $scope.privilegesCount;
  $scope.maxPageNumber;
  $scope.paginatedPageSize = 5000;

  // Creating a map between service name and unique Id, which will be used in column filters
  // We are creating this once during init and evertime we change column filter values, the id's remain the same
  // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
  $scope.serviceNameColumnIdMap = {};
  $scope.apiPrefixColumnIdMap = {};
  $scope.apiActionColumnIdMap = {};
  $scope.envColumnIdMap = {};

  // Help's us figure out which filter made the change
  // One of Column Filters ServiceName/ ApiPrefix/ Action GS/ Env
  // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
  $scope.columnFilterModified = {
    'serviceName': false,
    'apiPrefix': false,
    'actionGs': false,
    'env': false
  };

  //Setting for ng-dropdown-multiselect directive
  $scope.multiSelectSettings = {
      //closeOnSelect: true,
      //closeOnDeselect: true,
      //enableSearch: true,
      scrollableHeight: '300px',
      scrollable: true,
      externalIdProp: '',
      buttonClasses: 'btn btn-primary btn-xs'      
  };

  // ng-dropdown-multiselect event listeners
  $scope.serviceNameEventListeners = {
    //onItemSelect: onItemSelect,
    //onItemDeselect: onItemDeselect,
    //onSelectAll: onSelectAll,
    //onDeselectAll: onDeselectAll,
    onSelectionChanged: function() {
      if($scope.selectedTableServices.length > 0) {
        $scope.columnFilterModified = {
          'serviceName': true,
          'apiPrefix': false,
          'actionGs': false,
          'env': false
        };
      } else {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': false,
          'env': false
        };
      }      
    }
  };

  $scope.apiPrefixEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableApiPrefix.length > 0) {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': true,
          'actionGs': false,
          'env': false
        };
      } else {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': false,
          'env': false
        };
      }
    }
  };

  $scope.actionGsEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableActionGs.length > 0) {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': true,
          'env': false
        };
      } else {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': false,
          'env': false
        };
      }
    }
  };

  $scope.envEventListeners = {
    onSelectionChanged: function() {
      if($scope.selectedTableEnvs.length > 0) {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': false,
          'env': true
        };
      } else {
        $scope.columnFilterModified = {
          'serviceName': false,
          'apiPrefix': false,
          'actionGs': false,
          'env': false
        };
      }
    }
  };

  // Column Role filter attributes
  $scope.selectedPolicies = {}; 
  $scope.policyData = [ {id: 1, label: 'Allow'}, {id: 2, label: 'Deny'}];  

  $scope.dropdownFilterEvents = {
    onItemSelect: function(item, role) {
      //console.log(role);
      //console.log($scope.selectedPolicies);
    },
    onItemDeselect: function(item, role) {
      //console.log(role);
      //console.log($scope.selectedPolicies);
    },
    onInitDone: function(role) {
      // Initialize selected policies modal for each role that exist in $scope.tableRolesList
      /*
      $scope.tableRolesList.forEach(function(role) {
        $scope.selectedPolicies[role] = [];
      });
      */
      $scope.selectedPolicies[role] = []; // Rather than using $scope.tableRolesList, its easier to pass role to the directive and retrieve it on events.
    }

  };

  // Display Save & Delete buttons if filter isn't  global
  $scope.canUserEditFilter = true;

  $scope.$watch(function() {return $sessionStorage.user.permissions.length}, function() {
    // To allow filters to be editable
    if($.inArray('Admin', $sessionStorage.user.permissions) !== -1) {
      $scope.canUserEditFilter = true;      
    }
    else {
      $scope.canUserEditFilter = false;
    }
    // If user is in configuration manager role then allow edits to configs else disable them
    if($.inArray('ConfigurationManager', $sessionStorage.user.permissions) !== -1) {
      $scope.policyEditDisable = false;
    } else {
      $scope.policyEditDisable = true;
    }
  } );

  $scope.isCurrentUserAdmin = function() {
    return $.inArray('Admin', $sessionStorage.user.permissions) !== -1;
  }

  // Column Service filter attributes
  $scope.selectedTableServices = [];   
  $scope.servicesData = [];     // Data that gets displayed on Column Service Filter
  // Column Service Api Prefix filter attributes
  $scope.selectedTableApiPrefix = [];   
  $scope.apiPrefixData = [];     // Data that gets displayed on Column Api Prefix Filter
  // Column ServiceApi Action filter attributes
  $scope.selectedTableActionGs = [];   
  $scope.serviceApiActionsData = [];     // Data that gets displayed on Column Service Api Action Filter
  // Column Envs filter attributes
  $scope.selectedTableEnvs = [];   
  $scope.envsData = [];     // Data that gets displayed on Column Envs Filter


  $scope.getRoleId = function(roleName) {
    var id;
    // return roleId for a given roleName
    $scope.roleEntities.some(function(roleEntity) {
      if(roleEntity.roleName === roleName)
        id = roleEntity.id;
    });

    return id;
  }

  $scope.getRoleName = function(roleId) {
    var roleName;
    $scope.roleEntities.some(function(roleEntity) {
      if(roleEntity.id === roleId)
        roleName = roleEntity.roleName;
    });

    return roleName;
  }

  $scope.dirtyRecordFilter = function(i) {
    switch($scope.showDirtyRecordsOnly) {
        case 'off':
          return i;
        case 'on':
          return i.action == 'U';
      }

  };

/** Column Filter Code Start*/
  // Individula Role Filters in the table
  $scope.columnRoleFilter = function(i) {
    var roleColumnFilter = [];
    // Create a list of filter object roleName and policy
    for(var property in $scope.selectedPolicies) {
      if($scope.selectedPolicies.hasOwnProperty(property)) {
        if($scope.selectedPolicies[property].length > 0) {
          var rolePolicies = [];
          $scope.selectedPolicies[property].forEach(function (value) {
            if(value.id == 1)
              rolePolicies.push("Allow");
            else if(value.id == 2)
              rolePolicies.push("Deny");
          });

          roleColumnFilter.push({
            roleName: property,
            policies: rolePolicies
          });

        }
      }
    };

    var filterSatisfied = true;

    if(roleColumnFilter.length > 0) {
      roleColumnFilter.forEach(function(roleFilter) {
        // If the policy doesnt exist discard the entry
        if($.inArray(i[roleFilter.roleName].approvedValue, roleFilter.policies) === -1 ) {
          filterSatisfied = false;
        }          
      });
    };

    if(filterSatisfied) {
      return i;
    }
  }; 

  $scope.columnServiceFilter = function(i) {
    var serviceNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableServices.length > 0) {
      $scope.selectedTableServices.forEach(function(selectedEntry) {
        serviceNames.push(selectedEntry.label);
      });

      if($.inArray(i.serviceNameShort, serviceNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };

  $scope.columnApiPrefixFilter = function(i) {    
    var apiPrefixes = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableApiPrefix.length > 0) {
      $scope.selectedTableApiPrefix.forEach(function(selectedEntry) {
        apiPrefixes.push(selectedEntry.label);
      });

      if($.inArray(i.apiActionPrefix, apiPrefixes) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;
  };

  $scope.columnServiceApiActionFilter = function(i) {
    var serviceApiActionNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableActionGs.length > 0) {
      $scope.selectedTableActionGs.forEach(function(selectedEntry) {
        serviceApiActionNames.push(selectedEntry.label);
      });

      if($.inArray(i.apiActionName, serviceApiActionNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };

  $scope.columnEnvFilter = function(i) {    
    var envNames = [];
    var doesEntrySatisfyCriteria = true;

    if($scope.selectedTableEnvs.length > 0) {
      $scope.selectedTableEnvs.forEach(function(selectedEntry) {
        envNames.push(selectedEntry.label);
      });

      if($.inArray(i.environment, envNames) === -1)
        doesEntrySatisfyCriteria = false;
    }

    if(doesEntrySatisfyCriteria)
      return i;    
  };

  /** Column Filter Code End*/    

  /**
    (1) If envSupported is false  && user has Admin privileges, display Red background
    else only block configs don't display Red Background
    (2) Only display Red Background for violations, meaning "Allow" & Blank Priv configs, 
    for Deny configs no Red Background as there is no action to be taken.
  */
  $scope.privEnvConfigViolation = function(i, role) {
    //console.log('Priv:',i );
    if(i[role].envSupported === false 
      && $sessionStorage.user.permissions.indexOf('Admin') !== -1 
      && (i[role].approvedValue !== 'Deny')) {
      return true;
    } else {
      return false;
    }
  };

  $scope.revertPrivileges = function() {
    $scope.runPrivilegeFilter(); 
  };

  $scope.isEditDisabled = function(i, role) {
    // If we aren't in ConfigManager mode disable all edits.
    var editDisabled = false;

    if($scope.policyEditDisable) {
      editDisabled = true;
    }
    // If env is not supported & there is a violation ( approved value is Allow of blank) let Admin edit this field.
    // Any non admin should not be able to edit this field.
    if(i[role].envSupported === false) {
      // Non Admin disable edits
      if($sessionStorage.user.permissions.indexOf('Admin') === -1) {
        editDisabled = true;
      } 
      // Admin & approved value is Deny then disable Edits
      else if($sessionStorage.user.permissions.indexOf('Admin') !== -1 && i[role].approvedValue === 'Deny' ) {
        editDisabled = true;
      }    
    }
      
    // Here we are in edit mode but we cannot edit roles that have a proposed Value as they cannot be changed
    if(i[role].proposedValue) {
      editDisabled = true; // edit's are disabled
    }

    return editDisabled;
    
  }

  $scope.editPolicy = function(i, role) {
    console.log(i);

    // Retrieve the pristineEntry for the currently changed entry
    var pristineEntry;
    $scope.pristineEntries.some(function(entry) {
      if(entry.id === i.id && entry.environment === i.environment) {
        pristineEntry = entry;
      }
    });

    console.log('Pristine Entry: ', pristineEntry);

    // Role has never existed in privilege entries so a new role has been created
    if(!pristineEntry.hasOwnProperty(role)) {
      i[role].action = "U";
      i[role].roleId = $scope.getRoleId(role);
      i.action = "U";
    } else { // Role defined      
      // Check if pristineEntry has different policy for the current role, if it does then set action to be "U" on both role and entry
      if(i[role].approvedValue != pristineEntry[role].approvedValue) {
        i[role].action = "U";
        i[role].actualApprovedValue = pristineEntry[role].approvedValue;
      } else {
        delete i[role].action;
      }
    }
    // If any of the roles have been modified then set the privilege entry to be modified else set it to be un modified
    i.action = "I";
    $scope.tableRolesList.some(function(role) {
      if(i.hasOwnProperty(role) && i[role].action == "U") {
        i.action = "U";
      }
    });
  }; 

  $scope.checkSaveRevertValidity = function() {
    // Looping through entries to find out if any have been updated, if so enable Revert and Save buttons.
    var enable = false;
    if(typeof $scope.entries != 'undefined' && $scope.entries instanceof Array) {
      $scope.entries.filter(Boolean).forEach(function(entry) {
        if(entry.action == 'U') {
          enable = true;
        };
      });
    };
    return enable;
  };  

  //Return serviceNameShort from serviceFilterName, which is combo of serviceNameShort:serviceNameLong
  $scope.getServiceNameShort = function(serviceFilterName) {
    return serviceFilterName.split(":")[0];
  };


  $scope.clearColumnFilterAttributes = function() {
    console.log('Clear column filter attirbutes');
    $scope.selectedTableServices = [];
    $scope.selectedTableActionGs = [];
    $scope.selectedTableApiPrefix = [];
    $scope.selectedTableEnvs = [];
    $scope.searchKeyword = '';

    for(var property in $scope.selectedPolicies) {
      if($scope.selectedPolicies.hasOwnProperty(property)) {
        $scope.selectedPolicies[property] = [];
      }
    };
    //console.log($scope.selectedPolicies);
  };

  /*
    Watch change to privilege config table results and update the apiActionGS column filters with filtered values
    The filtered values will have to be sorted based on the filtered keywords
  */
  $scope.$watchCollection('filteredEntries', function() {
    $scope.updateColumnFilterValuesOnChange(); 
  });

  $scope.updateColumnFilterValuesOnChange = function() {
    // Resetting the Data that gets displayed on Serice/ApiPrefix/ApiAction/Env column filters
    var uniqueServiceNames = [];
    var uniqueApiPrefixes = [];
    var sortedServiceApiActionNames = [];
    var uniqueEnvs = [];
    
    $scope.filteredEntries.forEach(function(filteredEntry) {

      // Create Unique Service Names as multiple filtered entries can have same Service names
      // Only peform this operation if user isn't accessing Service name column filter
      if($scope.columnFilterModified.serviceName === false && uniqueServiceNames.indexOf(filteredEntry.serviceNameShort) === -1) {
        uniqueServiceNames.push(filteredEntry.serviceNameShort);
      }      
      // Creating unique Api Prefixes as multiple filtered entries can have same api prefix
      // Only peform this operation if user isn't accessing Api Prefix column filter
      if($scope.columnFilterModified.apiPrefix === false && uniqueApiPrefixes.indexOf(filteredEntry.apiActionPrefix) === -1) {
        uniqueApiPrefixes.push(filteredEntry.apiActionPrefix);
      };
      // Creating Api Action Names
      // Only peform this operation if user isn't accessing Service Api Action column filter
      if($scope.columnFilterModified.actionGs === false && sortedServiceApiActionNames.indexOf(filteredEntry.apiActionName) === -1) {
        sortedServiceApiActionNames.push(filteredEntry.apiActionName);
      };      
      // Creating unique Envs as multiple filtered entries can have same Env
      // Only peform this operation if user isn't accessing Env column filter
      if($scope.columnFilterModified.env === false && uniqueEnvs.indexOf(filteredEntry.environment) === -1) {
        uniqueEnvs.push(filteredEntry.environment);
      }
    });

    // Only reset column filter's if other filter has been modified, 
    // if current filter is being accessed by the user don't modify the values of current filter
    // If we don't do servicesData etc to [] then duplicates will appear in the column filters    
    
    if($scope.columnFilterModified.serviceName === false) {
      $scope.servicesData = [];
      $scope.createServiceNameColumnFilterValues(uniqueServiceNames.sort());
    }
    if($scope.columnFilterModified.apiPrefix === false) {
      $scope.apiPrefixData = [];
      $scope.createApiPrefixColumnFilterValues(uniqueApiPrefixes.sort());
    }
    if($scope.columnFilterModified.actionGs === false) {
      $scope.serviceApiActionsData = [];
      $scope.createApiActionColumnFilterValues(sortedServiceApiActionNames.sort());
    }
    if($scope.columnFilterModified.env === false) {
      $scope.envsData = [];
      $scope.createEnvColumnFilterValues(uniqueEnvs.sort());
    }   
  }

/*
    Creates Service Name column filter values. Initially we load all Service Names sorted.
    Later if the table get's filtered then this method get's called from watchCollection method 
    and only filtered Service Names are displayed
  */
  $scope.createServiceNameColumnFilterValues = function(sortedServiceNames) {
    // Setting serviceData array for service column table filter
    sortedServiceNames.forEach(function(serviceName) {
      $scope.servicesData.push({
        id: $scope.serviceNameColumnIdMap[serviceName],
        label: serviceName
      });
    });
  };

  /*
    Creates Api Prefix column filter values. Initially we load all Api Prefixes sorted.
    Later if the table get's filtered then this method get's called from watchCollection method 
    and only filtered Api Prefixes are displayed
  */
  $scope.createApiPrefixColumnFilterValues = function(sortedUniqueApiPrefixes) {
    sortedUniqueApiPrefixes.forEach(function(apiPrefix) {
      $scope.apiPrefixData.push({
        id: $scope.apiPrefixColumnIdMap[apiPrefix],
        label: apiPrefix
      });
    });
  };

  /*
    Creates Api Action GS column filter values based on api actions in the table
    Initially we load all api action names sorted
    Later if the table get's filtered then this method get's called from watchCollection method 
    and only filtered api action names are displayed
  */

  $scope.createApiActionColumnFilterValues = function(sortedServiceApiActionNames) {
    sortedServiceApiActionNames.forEach(function(apiActionName) {
      $scope.serviceApiActionsData.push({
        id: $scope.apiActionColumnIdMap[apiActionName],
        label: apiActionName
      });
    });
  };

  /*
    Creates Environment column filter values based on rows in the table
    Initially we load all Envs sorted
    Later if the table get's filtered then this method get's called from watchCollection method 
    and only filtered envs are displayed
  */
  $scope.createEnvColumnFilterValues = function(sortedEnvs) {
    sortedEnvs.forEach(function(env) {
      $scope.envsData.push({
        id: $scope.envColumnIdMap[env],
        label: env
      });
    });
  };


  $scope.createColumnTableFilter = function() {
    var serviceNames = [];
    $scope.selectedServicesList.forEach(function(service) {
      serviceNames.push($scope.getServiceNameShort(service));
    });
    // Creating map between serviceName ~ uniqueId 
    var serviceId = 1;
    serviceNames.forEach(function(serviceName) {
      $scope.serviceNameColumnIdMap[serviceName] = serviceId++;

    });
    // Create sorted column filter values for Service Name
    $scope.createServiceNameColumnFilterValues(serviceNames.sort());

    // Setting apiPrefixData array for service column table filter
    var uniqueApiPrefixes = [];
    $scope.selectedServicesList.forEach(function(service) {
        // Iterate over service entities and retrieve the serviceApiActions for the selected service
        $scope.serviceEntities.some(function(serviceEntity) {
          if(serviceEntity.serviceNameShort == $scope.getServiceNameShort(service)) {
            serviceEntity.serviceApiActionEntityList.forEach(function(serviceApiAction) {
              if(uniqueApiPrefixes.indexOf(serviceApiAction.apiActionPrefix) === -1) {
                uniqueApiPrefixes.push(serviceApiAction.apiActionPrefix);
              }
            });
          }
        });
    });
    // Creating map between apiPrefix ~ uniqueId
    var apiPrefixId = 1;
    uniqueApiPrefixes.forEach(function (apiPrefix) {
      $scope.apiPrefixColumnIdMap[apiPrefix] = apiPrefixId++;
    });
    // Create sorted column filter values for Api Prefix
    $scope.createApiPrefixColumnFilterValues(uniqueApiPrefixes.sort());

    // Setting serviceApiActionData array for service Api Action column table filter
    var sortedServiceApiActionNames = [];
    $scope.selectedServicesList.forEach(function(service) {
        // Iterate over service entities and retrieve the serviceApiActions for the selected service
        $scope.serviceEntities.some(function(serviceEntity) {
          if(serviceEntity.serviceNameShort == $scope.getServiceNameShort(service)) {
            serviceEntity.serviceApiActionEntityList.forEach(function(serviceApiAction) {
              sortedServiceApiActionNames.push(serviceApiAction.apiActionName);
            });
          }
        });
    });
    var apiActionId = 1;
    sortedServiceApiActionNames.forEach(function(apiActionName) {
      $scope.apiActionColumnIdMap[apiActionName] = apiActionId++;
    });
    // Create sorted column filter values for Api Action
    $scope.createApiActionColumnFilterValues(sortedServiceApiActionNames.sort());    

    // Setting EnvsData array for Envs column table filter
    var envs = [];
    $scope.selectedEnvList.forEach(function(env) {
      envs.push(env);
    });
    var envId = 1;
    envs.forEach(function(env) {
      $scope.envColumnIdMap[env] = envId++;
    });
    // Create sorted column filter values for Environment
    $scope.createEnvColumnFilterValues(envs.sort());
  };

  $scope.populateTableRoleList = function() {
    // The TableRolesList field holds the role names for the table. We are separating this from $scope.selectedRolesList which will be used for filter section only
    // If no roles are selected then it implies we are pulling in all the role data, so we are retrieving all roles from $scope.roleEntities
    $scope.tableRolesList = $scope.selectedRolesList;
    if($scope.tableRolesList.length === 0) {
      $scope.roleEntities.forEach(function(roleEntity) {
        $scope.tableRolesList.push(roleEntity.roleName);
      })
    }
  };


  /**
    Entries count is total number of Table rows after roles have been transposed
    Algo: Entries Count = (serviceApiActionsCount * envsCount)
    We don't include roles in algo coz they are transposed onto serviceApiActions
  */
  $scope.getEntriesCount = function(selectedServiceNames, selectedEnvs) {
    var serviceApiActionsCount = 0;
    var envsCount = selectedEnvs.length;

    // if selectedServiceNames is empty it means we are retrieving all services
    if(selectedServiceNames.length === 0) {
      serviceApiActionsCount = $scope.serviceApiActionEntities.length;
    } else {
      selectedServiceNames.forEach(function(selectedServiceName) {
        $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
          if(serviceApiActionEntity.serviceNameShort === selectedServiceName) {
            serviceApiActionsCount++;
          }
        });
      });
    };

    return serviceApiActionsCount * envsCount;
  };

  /**
    Transpose Deltas onto the GS privileges and show the updated Privilege Configs for AWS Accounts.
  */

  $scope.transposeDeltasOntoEntries = function() {    
    $scope.deltaPrivileges.forEach(function(deltaPrivilege) {
      var roleName = $scope.getRoleName(deltaPrivilege.ccwgRoleOrgId);
      // Loop through Entries to find the Delta Privilege  
      $scope.entries.forEach(function(entry) {
        // Check if serviceApiActionId && Env && Role match up, if so delta exists replace the existing value
        if(entry.id === deltaPrivilege.ccwgServiceApiActionGsId 
          && entry.environment === deltaPrivilege.environment
          && entry.hasOwnProperty(roleName)
          ) {          
          entry[roleName].approvedValue = deltaPrivilege.approvedValue;
          entry[roleName].createdBy = deltaPrivilege.createdBy;
          entry[roleName].createdDate = deltaPrivilege.createdDate;
          entry[roleName].privilegeId = deltaPrivilege.id;
          entry[roleName].lastApprovedDate = deltaPrivilege.lastApprovedDate;
          entry[roleName].proposedValue = deltaPrivilege.proposedValue;
          entry[roleName].updatedBy = deltaPrivilege.updatedBy;
          entry[roleName].updatedDate = deltaPrivilege.updatedDate;
          entry[roleName].ccwgFinraAwsAccountsId = deltaPrivilege.ccwgFinraAwsAccountsId;
          entry[roleName].delta = true;
        }
      });
    });
  };

/**
  We will be monitoring the $scope.entries and once all entries have been retrieved we 
*/

  $scope.$watch(function() {return $scope.entriesCreatedCount}, function() {
    console.log('Entries Created Count: ', $scope.entriesCreatedCount );
    if($scope.entriesCreatedCount !== undefined && $scope.entriesCreatedCount === $scope.entriesCount) {
      console.log("Entries count reached, running timeout");

      // We don't need to have additional check here for Aws Account coz deltaPrivileges would be [] if no Aws Account selected.
      // This doesn't impact performace.
      $scope.transposeDeltasOntoEntries();

      // Creating pristine entries once the total count has been reached.
      // We need to do this copy after the delta transpose
      Array.prototype.push.apply($scope.pristineEntries, angular.copy($scope.entries));
      
      $scope.showPrivilegesSpinner = false;
      // Progress bar dissapears after 3 seconds.
      $timeout(function(){$scope.showProgressBar = false;}, 3000);
    };
  });

  /* Filter retrieval of privileges */
  $scope.runPrivilegeFilter = function() {

    $scope.showPrivilegesSpinner = true;

    //$scope.entriesCount = 0;
    $scope.entries = [];
    $scope.pristineEntries = [];
    $scope.deltaPrivileges = [];
    $scope.servicesData = [];              // Data that gets displayed on Column Service Filter
    $scope.apiPrefixData = [];
    $scope.serviceApiActionsData = [];     // Data that gets displayed on Column ServiceApiAction Filter
    $scope.envsData = [];                  // Data that gets displayed on Column Envs Filter

    $scope.clearColumnFilterAttributes(); // Clear any column filter's if they exist

    // This count is incremented as we retrieve paginated privileges and call createEntry() method
    $scope.totalPaginatedCount = 0;
    $scope.entriesCreatedCount = 0;     

    console.log("Selected Roles " + $scope.selectedRolesList);
    console.log("Selected Services " + $scope.selectedServicesList);
    console.log("Environment values: " + $scope.selectedEnvList);

    // Populate Data for  service/ serviceApiActions/ Env column filters
    $scope.createColumnTableFilter();
    // Populate tableRoleList array, which holds the role column entries in the table
    $scope.populateTableRoleList();

    var selectedRoleIds = [];
    // Retrieving RoleId's from rolename
    $scope.selectedRolesList.forEach(function(role) {
      $scope.roleEntities.some(function(roleEntity) {
        if(role === roleEntity.roleName)
          selectedRoleIds.push(roleEntity.id);          
      });
    });

    var selectedServiceIds = [];
    // Retrieving ServiceId's from ServiceNames
    $scope.selectedServicesList.forEach(function(service) {
      $scope.serviceEntities.some(function(serviceEntity) {
        if($scope.getServiceNameShort(service) === serviceEntity.serviceNameShort)
          selectedServiceIds.push(serviceEntity.id);          
      });
    });

    var selectedEnvs = $scope.selectedEnvList.length === 0 ? $scope.envs : $scope.selectedEnvList; 


    // Check if AWS Account has been selected, if so then retrieve Deltas as well.
    // These deltas will later be transposed onto the actual Gold Source
    // Check if AWS Account has been selected, if so then working Title will be  <AWS Account Name> (<AWS Account ARN>) else Gold Source
    if($scope.selectedAwsAccountNames.length > 0) {
      // The selected envs will change based on GS or an AWS Account has been selected.
      selectedEnvs = new Array($scope.selectedAwsAccountEntity.environment);
      $scope.privilegeWorkingSetTitle = ': '+ $scope.selectedAwsAccountEntity.accountName + ' ( ' + $scope.selectedAwsAccountEntity.accountArn  + ' )';
      
      privilegeService.getPrivilegeDeltasForAwsAccount($scope.selectedAwsAccountEntity.id)
      .then(
            function(response) {
              $scope.deltaPrivileges =  response.data;
              console.log('Delta Privileges: ', $scope.deltaPrivileges);
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
        );    
    } else {
      $scope.privilegeWorkingSetTitle = ': Gold Source';
    };

    var selectedServiceNames = [];
    $scope.selectedServicesList.forEach(function(service) {
      selectedServiceNames.push($scope.getServiceNameShort(service));
    });

    $scope.entriesCount = $scope.getEntriesCount(selectedServiceNames, selectedEnvs);
    $scope.showProgressBar = true;
    console.log("Entries Count : " + $scope.entriesCount);

    /** Retrieve Privileges Count */
    privilegeService.getPrivilegesCount(selectedRoleIds, selectedServiceIds, selectedEnvs)
      .then(
        function(response) {
          $scope.privilegesCount = response.data;
          $scope.maxPageNumber = Math.ceil($scope.privilegesCount/ $scope.paginatedPageSize);
          if($scope.maxPageNumber === 0)
            $scope.maxPageNumber = 1;
          console.log('Privileges Count :' + $scope.privilegesCount);
          console.log('MaxPageNumber : ' + $scope.maxPageNumber);
          /*
          console.log('Count Selected Service Ids:' + selectedServiceIds);
          var size = 8;
          while(selectedServiceIds.length > 0) {
            $scope.getPaginatedPrivilegesUsingFilter(selectedRoleIds, selectedServiceIds.splice(0, size), $scope.selectedEnvList);
          }
          */
          $scope.getPaginatedPrivilegesUsingFilter(selectedRoleIds, selectedServiceIds, selectedEnvs);
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  /**
    Create a serviceApiAction per env as it exists in privilege
    Since Service Api Actions get displayed on the privs page, we need to create a service api action for env
    and later append role entity to it.

  */
  $scope.getPaginatedPrivilegesUsingFilter = function(selectedRoleIds, selectedServiceIds, selectedEnvs) {
    // Making sure $scope.entries is empty before we put more entires
    $scope.entries = [];
    $scope.pristineEntries = [];

    var selectedServiceNames = [];

    // Create a map of roleId + roleName
    var roleMap = {};

    // Iterate over selected roles list and create a map of roleName -> id
    // We are doing this coz privilegeEntity only has roleId and not roleName
    // roleMap will be used in addPrivilegeInfoToRoleProperty()
    $scope.selectedRolesList.forEach(function(roleName) {
        $scope.roleEntities.some(function(roleEntity) {
          if(roleEntity.roleName === roleName) {
            roleMap[roleName] = roleEntity.id;
          }
        });
    });

    // if $scope.selectedServicesList is empty it means we are retrieving all services
    if($scope.selectedServicesList.length === 0) {
      $scope.serviceEntities.forEach(function(serviceEntity) {
        selectedServiceNames.push(serviceEntity.serviceNameShort);
      });
    } else {
      $scope.selectedServicesList.forEach(function(service) {
        selectedServiceNames.push($scope.getServiceNameShort(service));
      });
      //Array.prototype.push.apply(selectedServiceNames, angular.copy($scope.selectedServicesList));
    };

    selectedServiceNames.forEach(function(selectedService) {
      Array.prototype.push.apply($scope.entries, $scope.createEntriesByService(selectedService, roleMap, selectedEnvs));
    });    


    var size = 8;
    // If lot of Service Id's are selected then there is a problem in back end with the IN Clause for Service Api Actions
    // We are restricting the Service Id's to 8 in one call
    // Below logic, splice() method cuts the serviceIds length by 8 after every loop.
    while(selectedServiceIds.length > 0) {

      var splitSelectedServiceIds = selectedServiceIds.splice(0, size);
      
      var pageSize;
      for(pageSize = 1; pageSize <= $scope.maxPageNumber; pageSize++) {
        // Retrieving filtered privileges
        privilegeService.getPrivilegesUsingFilter(selectedRoleIds, splitSelectedServiceIds, selectedEnvs, pageSize, $scope.paginatedPageSize)
          .then(
            function(response) {
              $scope.privileges =  response.data;
              $scope.addPrivilegeInfoToEntries();
              $scope.entriesCreatedCount = Math.round($scope.totalPaginatedCount / $scope.maxPageNumber);
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
          );
      }
    }
  };

  /** 
    As we retrieve privileges, we iterate over entries and add the newly retrieved privileges info to role property.
  */
  $scope.addPrivilegeInfoToEntries = function(roleMap) {

    // Create a map of roleId + roleName
    var roleMap = {};

    // Iterate over selected roles list and create a map of roleName -> id
    // We are doing this coz privilegeEntity only has roleId and not roleName
    // roleMap will be used in addPrivilegeInfoToRoleProperty()
    $scope.selectedRolesList.forEach(function(roleName) {
        $scope.roleEntities.some(function(roleEntity) {
          if(roleEntity.roleName === roleName) {
            roleMap[roleName] = roleEntity.id;
          }
        });
    });

    $scope.entries.forEach(function(entry) {
      $scope.addPrivilegeInfoToRoleProperty(entry, roleMap);
    });
  };

  /**
    Function which takes in the selected services and returns entriesByService
    Function returns serviceApiActions with transposed roles & Env
    Next step would be to provide privilege information for these roles
  */

  $scope.createEntriesByService = function(selectedService, roleMap, selectedEnvs) {
    
    var serviceApiActions = [];
    //var selectedEnvs = $scope.selectedEnvList.length === 0 ? $scope.envs : $scope.selectedEnvList; 

    // Retrieve list of service api actions for the selectedService
    $scope.serviceApiActionEntities.forEach(function(serviceApiActionEntity) {
      if(serviceApiActionEntity.serviceNameShort === selectedService) {
        serviceApiActions.push(JSON.parse(JSON.stringify(serviceApiActionEntity)));
      }
    });

    // Add selected roles as property to each serviceApiAction
    serviceApiActions.forEach(function(apiAction) {
      // Iterate over selected roles and add them as properties
      $scope.selectedRolesList.forEach(function(roleName) {
        apiAction[roleName] = {
            "proposedValue": null,
            "approvedValue": null,
            "lastApprovedDate": null,
            "roleId": roleMap[roleName],
            "rejectionFlag": null,
            "createdDate": null,
            "updatedDate": null,
            "createdBy": null,
            "updatedBy": null
          };
      })
    });

    var entriesByService = [];

    // Add selected Environment as value to environment variable to each serviceApiAction
    selectedEnvs.forEach(function(env) {
      serviceApiActions.forEach(function(apiAction) {
        apiAction.environment = env;
        entriesByService.push(angular.copy(apiAction));
      });
    });

    // Iterate over blank entries and figure out if the Role + Env combination is allowed for Config changes
    // If the Org Role doesn't have the Env in allowedEnvs array, then mark it as Env not Supported and have value as Deny
    // Also set envSupported flag as false
    var roleEnvMap = {};

    $scope.selectedRolesList.forEach(function(roleName) {
      $scope.roleEntities.some(function(roleEntity) {
        if(roleEntity.roleName === roleName) {
          roleEnvMap[roleName] = roleEntity.allowedEnvs;
        }
      });
    });
    entriesByService.forEach(function(entry) {
      $scope.selectedRolesList.forEach(function(roleName) {
        if(roleEnvMap[roleName] === null || roleEnvMap[roleName].indexOf(entry.environment) === -1) {
          entry[roleName].envSupported = false; 
        }
      });
    });
    return entriesByService;
  };

  /**
    Function takes an entry and add's privilege information to each role property
  */
  $scope.addPrivilegeInfoToRoleProperty = function(entry, roleMap) {

    // Iterate over selected roles and add privilege data to each role
    $scope.selectedRolesList.forEach(function(roleName) {
      // Iterate over privileges and find the priv with roleId + serviceApiActionId + env
      $scope.privileges.some(function(privilege) {
        if(privilege.ccwgServiceApiActionGsId === entry.id && privilege.environment === entry.environment && privilege.ccwgRoleOrgId === roleMap[roleName] ) {
          entry[roleName].proposedValue = privilege.proposedValue;
          entry[roleName].approvedValue = privilege.approvedValue;
          entry[roleName].lastApprovedDate = privilege.lastApprovedDate;
          entry[roleName].privilegeId = privilege.id;
          entry[roleName].roleId = privilege.ccwgRoleOrgId;
          entry[roleName].rejectionFlag = privilege.rejectionFlag;
          entry[roleName].createdDate = privilege.createdDate;
          entry[roleName].updatedDate = privilege.updatedDate;
          entry[roleName].createdBy = privilege.createdBy;
          entry[roleName].updatedBy = privilege.updatedBy;
        }
      });
    });

    // We keep track of total number of entries used in calculating progress bar count.
    $scope.totalPaginatedCount++;
  }; 

  /** Section to Save privileges */ 
  $scope.createPrivilege = function(roleId, serviceApiActionId, environment, approvedValue, proposedValue, action,
                                  rejectionFlag, createdDate, updatedDate, createdBy, updatedBy, id, requestTitle, justification) {
    var privilege = {};
    privilege.ccwgRoleOrgId = roleId;
    privilege.ccwgServiceApiActionGsId = serviceApiActionId;
    privilege.environment = environment;
    privilege.approvedValue = approvedValue;
    privilege.proposedValue = proposedValue;
    if(id !== null) {
      privilege.id = id; 
    }
    privilege.rejectionFlag = (typeof rejetionFlag === 'undefined') ? null : rejectionFlag;
    privilege.createdDate = createdDate || null,
    privilege.updatedDate = updatedDate || null,
    privilege.createdBy = createdBy || null,
    privilege.updatedBy = updatedBy || null,         
    privilege.action = action;

    // requestTitle and justification are used in PrivilegeReview Entity to group multiple priv reviews
    privilege.requestTitle = requestTitle;
    privilege.justification = justification;


    if($scope.selectedAwsAccountNames.length > 0) {
      privilege.ccwgFinraAwsAccountsId = $scope.selectedAwsAccountEntity.id;

    };

    return privilege;

  };


  $scope.editJustificationOpen = function() {

    var modalInstance = $uibModal.open({
      templateUrl: 'justificationModal.html',
      controller: 'JustificationModalController',
      resolve: {
      }
    });

    modalInstance.result
      .then(
        function(justificationInfo) {
          $scope.savePrivileges(justificationInfo);
        }, 
        function(response) {
          console.log(response);
          if(response != 'cancel' && response != 'backdrop click' && response != 'escape key press') {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }      
      });
  };


  $scope.savePrivileges = function(justificationInfo) {
    console.log("Saving privileges!");
    $scope.showPrivilegesSpinner = true;
    var updatedPrivs = [];
    var updatedEntries = [];
    // Step1: Get list of updated entries
    $scope.entries.forEach(function(entry) {
      if(entry.action == 'U')
        updatedEntries.push(entry);
    });

    // Loop through updatedEntires and find roles that have been updated for each Entry and create a list of privilege entries to be created/updated.
    updatedEntries.forEach(function(entry) {

      // For each entry find the role property that has been updated or newly created(roles which don't have privilegeId fall in this criteria)
      // Create a new privilege entry which is combination of privId + roleId + serviceApiActionId + env, and send proposedValue and approvedValue
      $scope.tableRolesList.some(function(role) {
        // role policy has been updated, check inside if its a new policy being created or change to existing policy
        if(entry.hasOwnProperty(role) && entry[role].action == "U") {

          // Case where we are dealing with Account specific deviations
          // In this case even if entry has privilegeId as property, we need to create a new delta privilege as it referes to gold source privilege
          // Only if the ccwgFinraAwsAccountsId exists, should it be treated as an Account privilege, all others will fall under new privilege bucket
          if($scope.selectedAwsAccountNames.length > 0) {
            if(entry[role].hasOwnProperty("privilegeId") && entry[role].delta === true) {
              // proposed value is in approvedValue field
              // existing approved value is in entry[role].actualApprovedValue, which was set in editPolicy() method
              updatedPrivs.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, entry[role].actualApprovedValue, entry[role].approvedValue, "U",
                            entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, entry[role].privilegeId, 
                            justificationInfo.requestTitle, justificationInfo.justification));
            } else {
              // new policy is being created for the role.
              // A slight tweak to below new policy is that since this is deviation from GS, the actualApprovedValue isn't null but GS value
              updatedPrivs.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, entry[role].actualApprovedValue, entry[role].approvedValue, "I", 
                            entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, null,
                            justificationInfo.requestTitle, justificationInfo.justification));
            }
          }

          else { // Case where we are dealing with Gold Source and not Account specific deviations
            // If privilegeId exists, existing policy is being changed;
            if(entry[role].hasOwnProperty("privilegeId")) {
              // proposed value is in approvedValue field
              // existing approved value is in entry[role].actualApprovedValue, which was set in editPolicy() method
              updatedPrivs.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, entry[role].actualApprovedValue, entry[role].approvedValue, "U",
                            entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, entry[role].privilegeId, 
                            justificationInfo.requestTitle, justificationInfo.justification));
            } else { // new policy is being created for the role.
              updatedPrivs.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, null, entry[role].approvedValue, "I", 
                            entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, null,
                            justificationInfo.requestTitle, justificationInfo.justification));

            } 
          }         
        }
      });
    });

   // console.log(updatedPrivs);

    // Note: upatedPrivs  ServiceApiActionEntity has transposed fields, hence we had to add annotation"@JsonIgnoreProperties(ignoreUnknown=true)" on backend.
    privilegeService.postPrivileges(updatedPrivs)
      .then(
        function(response) {
          $scope.runPrivilegeFilter();
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
  };

  /* Export Privileges Config */

  $scope.exportPrivConfigs = function(entries) {
    console.log("Exporting Privileges");
    //console.log(entries);
  
    var privileges = [];

    // Loop through updatedEntires and find roles that have been updated for each Entry and create a list of privilege entries to be created/updated.
    entries.forEach(function(entry) {

      // For each entry find the role property that has been updated or newly created(roles which don't have privilegeId fall in this criteria)
      // Create a new privilege entry which is combination of privId + roleId + serviceApiActionId + env, and send proposedValue and approvedValue
      $scope.tableRolesList.some(function(role) {
        // role policy has been updated, check inside if its a new policy being created or change to existing policy
        if(entry.hasOwnProperty(role)) {
          // If privilegeId exists, existing policy is being changed;          

          if(entry[role].hasOwnProperty("privilegeId")) {
            privileges.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, entry[role].approvedValue, entry[role].proposedValue, "U",
                          entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, entry[role].privilegeId, 
                          null, null));
          } else { // new policy is being created for the role.
            privileges.push($scope.createPrivilege(entry[role].roleId, entry.id, entry.environment, null, entry[role].proposedValue, "I", 
                          entry[role].rejectionFlag, entry[role].createdDate, entry[role].updatedDate, entry[role].createdBy, entry[role].updatedBy, null,
                          null, null));
          }          
        }
      });
    });

    fileService.exportPrivConfigsFile(privileges)
        .then(
            function(response) {
                var type = response.headers('Content-Type');
                var disposition = response.headers('Content-Disposition');
                var defaultFileName = "";
                //console.log(disposition);
                if (disposition) {
                    var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                    if (match[1])
                        defaultFileName = match[1];
                }
                //console.log(defaultFileName);
                defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                //console.log("DefaultFileName : " + defaultFileName);

                var blob = new Blob([response.data], {type: type});
                saveAs(blob, defaultFileName);
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
        );
  };

  /* Filter Section start */

  $scope.selectFilter = function(userPrivilegeFilter) {

    console.log("Filter changed: " + userPrivilegeFilter);    

    var userFilterEntitySelected;
    $scope.userFilterEntities.forEach(function(userFilterEntity) {
      if(userFilterEntity.filterName === userPrivilegeFilter)
        userFilterEntitySelected = userFilterEntity;
    });

    if(userFilterEntitySelected.globalFlag && !$scope.isCurrentUserAdmin() ) {
      $scope.canUserEditFilter = false;
    } else {
      $scope.canUserEditFilter = true;
    }

    if(userFilterEntitySelected.roleFilter != null) {
      var roleFilterValues = userFilterEntitySelected.roleFilter.split(',');
      $scope.selectedRolesList = roleFilterValues;
    } else {
      $scope.selectedRolesList = [];
    }

    if(userFilterEntitySelected.serviceFilter != null) {
      var serviceFilterValues = userFilterEntitySelected.serviceFilter.split(',');
      $scope.selectedServicesList = serviceFilterValues;
    } else {
      $scope.selectedServicesList = [];
    }

    if(userFilterEntitySelected.envFilter != null) {
      var envFilterValues = userFilterEntitySelected.envFilter.split(',');
      $scope.selectedEnvList = envFilterValues;
    } else {
      $scope.selectedEnvList = [];
    }
  };  

  // Determines if Run Filter button is enabled or disabled
  $scope.isRunFilterDisabled = function() {
    return $scope.leftFilterValidation.serviceFilterInvalid ||
            $scope.leftFilterValidation.roleFilterInvalid ||
              ($scope.leftFilterValidation.envFilterInvalid && $scope.selectedAwsAccountEnvs.length == 0);
  };

  // Clear Privilege Screen & Left Filters
  $scope.clearPrivilegeScreen = function() {
    $scope.selectedRoles([]);
    $scope.selectedServices([]);
    $scope.selectedEnvs([]);

    $scope.userPrivilegeFilter = null;

    $scope.entries = [];
    $scope.entriesCount = 0;

    $scope.selectedAwsAccountNames = [];
    $scope.selectedAwsAccountEnvs = [];

    $scope.privilegeWorkingSetTitle = '';
  }

  $scope.selectedRoles = function(data) {
    $scope.selectedRolesList = data;

      // Check if atleast one role has been selected, if not flag as validation error
      if($scope.selectedRolesList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.roleFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.roleFilterInvalid = false;
         });
      }
  };

  $scope.selectedServices = function(data) {
    $scope.selectedServicesList = data;

    // Check if atleast one Service has been selected, if not flag as validation error
      if($scope.selectedServicesList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.serviceFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.serviceFilterInvalid = false;
         });
      }
  };

  $scope.selectedEnvs = function(data) {
    $scope.selectedEnvList = data;

    // Check if atleast one Env has been selected, if not flag as validation error
      if($scope.selectedEnvList.length == 0) {
         $scope.safeApply(function() {
          $scope.leftFilterValidation.envFilterInvalid = true;
         }); 
      } else {
        $scope.safeApply(function() {
          $scope.leftFilterValidation.envFilterInvalid = false;
         });
      }
  };

  $scope.updateAwsAccountName = function(data) {

    $scope.safeApply(function() {
      $scope.selectedAwsAccountNames = data;
      $scope.selectedAwsAccountEnvs = [];
      // Figure out the selected Aws Account Entity by splitting the string by :
      // The selected Aws Account Entity is used to display the Env and also to fetch deltas
      if($scope.selectedAwsAccountNames.length > 0) {
        var awsOrg = $scope.selectedAwsAccountNames[0].split(":", 3)[0];
        var awsAccountName = $scope.selectedAwsAccountNames[0].split(":", 3)[1];
        var awsAccountArn = $scope.selectedAwsAccountNames[0].split(":", 3)[2];
      
        // Figuring out Aws Account Entity
        $scope.awsAccountEntities.forEach(function(awsAccount) {
          if(awsAccountName === awsAccount.accountName && awsOrg === awsAccount.org && awsAccountArn === awsAccount.accountArn) {
            $scope.selectedAwsAccountEntity = awsAccount;
            $scope.selectedAwsAccountEnvs.push(awsAccount.environment);
            //console.log('selected entity: ', $scope.selectedAwsAccountEntity);
          }
        });
      }      
    });  
  };

  $scope.retrievePrivsFilters = function(defaultFilter,  runPrivilegeFilterFlag) {
    // Setting the privilege filter names to empty array as during push this will cause duplicates
    $scope.userPrivilegeFilters = [];

    userService.getUserFilters($sessionStorage.user.name)
      .then(
        function(response) {
          $scope.userFilterEntities = response.data;
          $scope.userFilterEntities.forEach(function(userFilterEntity) {
            $scope.userPrivilegeFilters.push(userFilterEntity.filterName);
          });

          if(defaultFilter) {
            $scope.userFilterEntities.some(function(userFilterEntity) {
              if(userFilterEntity.filterName === defaultFilter.filterName) {
                $scope.userPrivilegeFilter = userFilterEntity.filterName;
                $scope.selectedRolesList = (userFilterEntity.roleFilter != null) ? userFilterEntity.roleFilter.split(',') : [];
                $scope.selectedServicesList = (userFilterEntity.serviceFilter != null) ? userFilterEntity.serviceFilter.split(',') : [];
                $scope.selectedEnvList = (userFilterEntity.envFilter != null) ? userFilterEntity.envFilter.split(',') : [];
              }
            });

            if(runPrivilegeFilterFlag) {
              $scope.runPrivilegeFilter();
            };


          } else {
            // loop through the userFilterEntities and retrieve the first default filter
            var defaultUserFilterEntity;
            $scope.userFilterEntities.some(function(userFilterEntity) {
              if(userFilterEntity.defaultFlag) {
                defaultUserFilterEntity = userFilterEntity;
                // Since we found a default filter, the user can Edit/ Delete filter as well.
                $scope.canUserEditFilter = true;                
              }
            });
            // If defaultUserFilterEntity is defined then run the filter based on logic 
            // If none defined then do nothing.
            if(typeof defaultUserFilterEntity !== "undefined" ) {
              $scope.userPrivilegeFilter = defaultUserFilterEntity.filterName;
              $scope.selectedRolesList = (defaultUserFilterEntity.roleFilter != null) ? defaultUserFilterEntity.roleFilter.split(',') : [];
              $scope.selectedServicesList = (defaultUserFilterEntity.serviceFilter != null) ? defaultUserFilterEntity.serviceFilter.split(',') : [];
              $scope.selectedEnvList = (defaultUserFilterEntity.envFilter != null) ? defaultUserFilterEntity.envFilter.split(',') : [];

              if(runPrivilegeFilterFlag) {
                $scope.runPrivilegeFilter();
              };
            }            
          }
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );    

  };

  // Modal to save new filter
  $scope.saveNewFilterOpen = function() {
    var modalInstance = $uibModal.open({
      templateUrl: 'html/privileges/saveNewFilterModal.html',
      controller: 'SaveNewFilterModalController',
      resolve: {
        selectedRoles: function(){ return $scope.selectedRolesList},
        selectedServices: function(){ return $scope.selectedServicesList},
        selectedEnvs: function(){ return $scope.selectedEnvList},
        envs: function(){ return $scope.envs},
        services: function(){ return $scope.services},
        roles: function(){ return $scope.roles}
      }
    });

    modalInstance.result
      .then(
        function(privsFilter) {
          $scope.retrievePrivsFilters(privsFilter, true);
        }, 
        function(response) {
          if(response != 'cancel' && response != 'backdrop click' && response != 'escape key press') {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }      
      });
  };

  // Modal to delete existing filters
  $scope.deleteFilterOpen = function() {
    var modalInstance = $uibModal.open({
      templateUrl: 'html/privileges/deleteFilterModal.html',
      controller: 'DeleteFilterModalController',
      resolve: {
        userPrivilegeFilter: function(){ return $scope.userPrivilegeFilter},
        userFilterEntities: function(){ return $scope.userFilterEntities}
      }
    });

    modalInstance.result
      .then(
        function() {
          $scope.retrievePrivsFilters(null, true);
        }, 
        function(response) {
          if(response != 'cancel' && response != 'backdrop click' && response != 'escape key press') {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }         
      });
  };  

  // Modal to Save existing filters
  $scope.saveFilterOpen = function() {
    var modalInstance = $uibModal.open({
      templateUrl: 'html/privileges/saveFilterModal.html',
      controller: 'SaveFilterModalController',
      resolve: {
        selectedRoles: function(){ return $scope.selectedRolesList},
        selectedServices: function(){ return $scope.selectedServicesList},
        selectedEnvs: function(){ return $scope.selectedEnvList},
        envs: function(){ return $scope.envs},
        services: function(){ return $scope.services},
        roles: function(){ return $scope.roles},
        userPrivilegeFilter: function(){ return $scope.userPrivilegeFilter},
        userFilterEntities: function(){ return $scope.userFilterEntities}
      }
    });

    modalInstance.result
      .then(
        function(privsFilter) {
          $scope.retrievePrivsFilters(privsFilter, true);
        }, 
        function(response) {
          if(response != 'cancel' && response != 'backdrop click' && response != 'escape key press') {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }         
      });
  };  

  /* Filter Section End*/


  /**
    Initialize method which does the following
      (1) Retrieves RoleEntities and populates $scope.roles
      (2) Retrieves ServiceEntities and populates $scope.services
      (3) Retrieves ServiceApiActions and populates $scope.serviceApiActionEntities
      (4) Runs privilegeFilter method to get default privileges based on default filters
  */
  $scope.initialize = function() {   

    $scope.showPrivilegeFilterSpinner = true; 

    // Retrieve role entities which can be used later to create privileges 
    roleService.getRoles()
      .then(
        function(response) {          
          $scope.roleEntities = response.data;
          $scope.roleEntities.forEach(function(roleEntity) {
            if(roleEntity.isActive === true) {
              $scope.roles.push(roleEntity.roleName);
            }            
          });
          $scope.rolesLoaded = true;

          // Sorting the Roles Filter values to be alphabetic
          $scope.roles.sort();
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    serviceRest.getServices()
      .then(
        function(response) {          
          $scope.serviceEntities = response.data;
          $scope.serviceEntities.forEach(function(serviceEntity) {
            if(serviceEntity.isActive === true) {
              $scope.services.push(serviceEntity.serviceNameShort + ":" + serviceEntity.serviceNameLong);
            }            
          });    
          $scope.servicesLoaded = true; 
          // Sorting the Service Filter values to be alphabetic
          $scope.services.sort();   

          $scope.showPrivilegeFilterSpinner = false;
          // Service api takes the longest, hence run this once all services are retrieved.
          // todo: add a watch to check services & api actions and once both retrieve run this method.          
          //Retrieve user privilege filters 
          $scope.retrievePrivsFilters(null, true);  
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );

    serviceRest.getServiceApiActions()
      .then(
        function(response) {
          $scope.serviceApiActionEntities = response.data;
          $scope.serviceApiActionsLoaded = true;      
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );      

    // Adding envs creation here coz lookup service takes some time to load envs.
    lookupService.retrieveReferences()
      .then(
        function(response) {
          $scope.envs = response.environments;
          $scope.policies = response.privilegesSettingValues;
          $scope.envsLoaded = true;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }

      );

    awsAccountService.getAwsAccounts()
        .then(
            function(response) {
              //console.log('AwsAccounts Retrieved: ', response.data);
              $scope.awsAccountEntities = response.data;
              $scope.awsAccountEntities.forEach(function(awsAccount) {
                if(awsAccount.isActive === true) {
                  $scope.awsAccountNames.push(awsAccount.org + ":" + awsAccount.accountName + ":" + awsAccount.accountArn);
                }                
              });
              $scope.awsAccountsLoaded = true;
            },
            function(response) {
              alert( "failure message: " + JSON.stringify({data: response.data}));
            }
      );
  };

  $scope.initialize();
}]);