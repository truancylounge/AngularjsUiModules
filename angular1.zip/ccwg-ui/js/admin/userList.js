ccwgApp.controller('UserListController', ['$scope', '$http', '$uibModal', 'envService', 'userService', '$sessionStorage', 'lookupService',
        function($scope, $http, $uibModal, envService, userService, $sessionStorage, lookupService) {
    $scope.users = [];
    $scope.userRoles = [];
    $scope.auxiliaryRoles = [];
    $scope.teamAssociations = [];
    $scope.sortType = 'updatedDate'; // set the default sort type
    $scope.sortReverse  = true;  // set the default sort order

    $scope.showDirtyRecordsOnly = 'off'; // Initially show all the records, if this flag changes only show dirty records

    // Pagination attributes
    $scope.currentPage = envService.read('currentPage');
    $scope.itemsPerPage = envService.read('itemsPerPage');
    $scope.maxSize = envService.read('maxSize');

    // Active button attirbutes
    $scope.activeButtonStatus = 'disable';

    // Alert after Users have been saved
    $scope.showSuccessAlert = false;
    $scope.savedUsers = 0;
    $scope.alertTimeout = envService.read('alertTimeout');

    $scope.showUsersSpinner = false;

    $scope.closeAlert = function() {
      $scope.showSuccessAlert = false;
      $scope.savedUsers = 0;
    };

    /*
      Watch change to user table results and update the column filters with filtered values
      The filtered values will have to be sorted based on the filtered keywords
    */
    $scope.$watchCollection('filteredUsers', function() {
      $scope.updateColumnFilterValuesOnChange(); 
    });

    /* Column filter section - start */

    //Setting for ng-dropdown-multiselect directive
    // Table Column filters
    $scope.multiSelectSettings = {
        //closeOnSelect: true,
        //closeOnDeselect: true,
        scrollableHeight: '300px',
        scrollable: true,
        externalIdProp: '',
        buttonClasses: 'btn btn-primary btn-xs'
    };

    // Creating a map between UserIds and unique Id, which will be used in column filters
    // We are creating this once during init and evertime we change column filter values, the id's remain the same
    // This logic was introducted because checkbox wasn't getting selected after filtering coz the id's were different
    $scope.userIdColumnIdMap = {};
    $scope.userNameColumnIdMap = {};
    $scope.coreRoleColumnIdMap = {};
    $scope.auxRoleColumnIdMap = {};
    $scope.teamColumnIdMap = {};

    $scope.clearColumnFilterAttributes = function() {
      console.log('Clear column filter attirbutes');
      $scope.selectedTableUserIds = [];
      $scope.selectedTableUserNames = [];
      $scope.selectedTableCoreRoles = [];
      $scope.selectedTableAuxRoles = [];
      $scope.selectedTableTeams = [];
      $scope.searchKeyword = '';
      $scope.columnFilterModified = {
        'userId': false,
        'userName': false,
        'coreRole': false,
        'auxRole': false,
        'team': false
      };
    };

    // Help's us figure out which filter made the change
    // One of Column Filters User Id/ User Name/ Core Roles/ Aux Roles/ Team
    // The requirement is to not modify the filter values that are currently set and modify all other filters based on result set
    $scope.columnFilterModified = {
      'userId': false,
      'userName': false,
      'coreRole': false,
      'auxRole': false,
      'team': false
    };

    // Column filter userId
    $scope.userIdsData = [];
    $scope.selectedTableUserIds = [];
    // ng-dropdown-multiselect event listeners
    $scope.userIdEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableUserIds.length > 0) {
          $scope.columnFilterModified = {'userId': true,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        } else {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        }      
      }
    };

    $scope.columnUserIdFilter = function(i) {
      var userIds = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableUserIds.length > 0) {
        $scope.selectedTableUserIds.forEach(function(selectedEntry) {
          userIds.push(selectedEntry.label);
        });

        if($.inArray(i.userId, userIds) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column filter userName
    $scope.userNamesData = [];
    $scope.selectedTableUserNames = [];
    // ng-dropdown-multiselect event listeners
    $scope.userNameEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableUserNames.length > 0) {
          $scope.columnFilterModified = {'userId': false,'userName': true,'coreRole': false,'auxRole': false,'team': false};
        } else {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        }      
      }
    };

    $scope.columnUserNameFilter = function(i) {
      var userNames = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableUserNames.length > 0) {
        $scope.selectedTableUserNames.forEach(function(selectedEntry) {
          userNames.push(selectedEntry.label);
        });

        if($.inArray(i.userName, userNames) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column filter core roles
    $scope.coreRolesData = [];
    $scope.selectedTableCoreRoles = [];
    // ng-dropdown-multiselect event listeners
    $scope.coreRoleEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableCoreRoles.length > 0) {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': true,'auxRole': false,'team': false};
        } else {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        }      
      }
    };

    $scope.columnCoreRoleFilter = function(i) {
      var coreRoles = [];
      var doesEntrySatisfyCriteria = false;

      if($scope.selectedTableCoreRoles.length > 0) {
        $scope.selectedTableCoreRoles.forEach(function(selectedEntry) {
          coreRoles.push(selectedEntry.label);
        });

        $.each(coreRoles, function(index, coreRole) {
          // Core Role was found in User Role so select this row
          if(i.userRoles.indexOf(coreRole) >= 0) {
            doesEntrySatisfyCriteria = true;
          }
        });
      } else {
        doesEntrySatisfyCriteria = true;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column filter aux roles
    $scope.auxRolesData = [];
    $scope.selectedTableAuxRoles = [];
    // ng-dropdown-multiselect event listeners
    $scope.auxRoleEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableAuxRoles.length > 0) {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': true,'team': false};
        } else {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        }      
      }
    };

    $scope.columnAuxRoleFilter = function(i) {
      var auxRoles = [];
      var doesEntrySatisfyCriteria = false;

      if($scope.selectedTableAuxRoles.length > 0) {
        $scope.selectedTableAuxRoles.forEach(function(selectedEntry) {
          auxRoles.push(selectedEntry.label);
        });

        $.each(auxRoles, function(index, auxRole) {
          // Core Role was found in User Role so select this row
          if(i.auxiliaryRoles.indexOf(auxRole) >= 0) {
            doesEntrySatisfyCriteria = true;
          }
        });
      } else {
        doesEntrySatisfyCriteria = true;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    // Column filter team
    $scope.teamsData = [];
    $scope.selectedTableTeams = [];
    // ng-dropdown-multiselect event listeners
    $scope.teamEventListeners = {
       onSelectionChanged: function() {
        if($scope.selectedTableTeams.length > 0) {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': true};
        } else {
          $scope.columnFilterModified = {'userId': false,'userName': false,'coreRole': false,'auxRole': false,'team': false};
        }      
      }
    };

    $scope.columnTeamFilter = function(i) {
      var teams = [];
      var doesEntrySatisfyCriteria = true;

      if($scope.selectedTableTeams.length > 0) {
        $scope.selectedTableTeams.forEach(function(selectedEntry) {
          teams.push(selectedEntry.label);
        });

        if($.inArray(i.teamAssociation, teams) === -1)
          doesEntrySatisfyCriteria = false;
      }

      if(doesEntrySatisfyCriteria)
        return i;
    };

    $scope.createColumnTableFilter = function() {
      var uniqueUserIds = $scope.getGenericFieldValues($scope.users, 'userId');
      // Creating a map between userId ~ uniqueId
      $scope.createGenericColumnMap(uniqueUserIds, $scope.userIdColumnIdMap);       
      $scope.createGenericColumnFilterValues(uniqueUserIds.sort(), $scope.userIdsData, $scope.userIdColumnIdMap);     
      
      var uniqueUserNames = $scope.getGenericFieldValues($scope.users, 'userName');
      // Creating a map between userName ~ uniqueId
      $scope.createGenericColumnMap(uniqueUserNames, $scope.userNameColumnIdMap);
      $scope.createGenericColumnFilterValues(uniqueUserNames.sort(), $scope.userNamesData, $scope.userNameColumnIdMap);

      var uniqueCoreRoles = [];
      $scope.users.forEach(function(i) {
        var roles = i.userRoles.split(",");
        roles.forEach(function(role) {
          if(uniqueCoreRoles.indexOf(role) === -1) {
            uniqueCoreRoles.push(role);
          }
        });
      });
      // Creating a map between core roles ~ uniqueId
      $scope.createGenericColumnMap(uniqueCoreRoles, $scope.coreRoleColumnIdMap);
      $scope.createGenericColumnFilterValues(uniqueCoreRoles.sort(), $scope.coreRolesData, $scope.coreRoleColumnIdMap);

      var uniqueAuxRoles = [];
      $scope.users.forEach(function(i) {
        var roles = i.auxiliaryRoles.split(",");
        roles.forEach(function(role) {
          if(uniqueAuxRoles.indexOf(role) === -1) {
            uniqueAuxRoles.push(role);
          }
        });
      });
      // Creating a map between core roles ~ uniqueId
      $scope.createGenericColumnMap(uniqueAuxRoles, $scope.auxRoleColumnIdMap);
      $scope.createGenericColumnFilterValues(uniqueAuxRoles.sort(), $scope.auxRolesData, $scope.auxRoleColumnIdMap);


      var uniqueTeams = $scope.getGenericFieldValues($scope.users, 'teamAssociation');
      // Creating a map between team ~ uniqueId
      $scope.createGenericColumnMap(uniqueTeams, $scope.teamColumnIdMap);
      $scope.createGenericColumnFilterValues(uniqueTeams.sort(), $scope.teamsData, $scope.teamColumnIdMap);
    };

    /*
     Function takes collection & field name of an element in collection and returns unique list of field values
     This is a generic function to create column filter values.
    */
    $scope.getGenericFieldValues = function(genericCollection, fieldName) {
      var uniqueFieldValues = [];
      genericCollection.forEach(function(i) {
        if(uniqueFieldValues.indexOf(i[fieldName]) === -1) {
          uniqueFieldValues.push(i[fieldName]);
        }
      });
      
      return uniqueFieldValues.sort();
    };

    /*
      Creates generic column map for $scope.userIdColumnIdMap, $scope.userNameColumnIdMap, $scope.coreRoleColumnIdMap etc
      Function takes unique column values & column map
    */

    $scope.createGenericColumnMap = function(genericColumnValues, genericColumnMap) {
      var id = 1;
      genericColumnValues.forEach(function(value) {
        genericColumnMap[value] = id++;
      });
    };

    /*
      Create Generic Column Filter values.
      Function takes genericColumnValues, genericColumnData, genericColumnIdMap and populates column data
    */
    $scope.createGenericColumnFilterValues = function(genericColumnValues, genericColumnData, genericColumnIdMap) {
      genericColumnData.splice(0, genericColumnData.length); // Removing all elements from the array
      genericColumnValues.forEach(function(value) {
        genericColumnData.push({
          id: genericColumnIdMap[value],
          label: value
        });
      });
    };

    $scope.updateColumnFilterValuesOnChange = function() {
      // Only reset column filter's if other filter has been modified, 
      // if current filter is being accessed by the user don't modify the values of current filter
      // If we don't do userIdsData etc to [] then duplicates will appear in the column filters 
      if($scope.columnFilterModified.userId === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredUsers, 'userId'), 
          $scope.userIdsData, 
          $scope.userIdColumnIdMap);
      };

      if($scope.columnFilterModified.userName === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredUsers, 'userName'), 
          $scope.userNamesData, 
          $scope.userNameColumnIdMap);
      };

      if($scope.columnFilterModified.coreRole === false) {
        var uniqueCoreRoles = [];
        $scope.filteredUsers.forEach(function(i) {
          var roles = i.userRoles.split(",");
          roles.forEach(function(role) {
            if(uniqueCoreRoles.indexOf(role) === -1) {
              uniqueCoreRoles.push(role);
            }
          });
        });

        $scope.createGenericColumnFilterValues(uniqueCoreRoles.sort(), $scope.coreRolesData, $scope.coreRoleColumnIdMap);
      };

      if($scope.columnFilterModified.auxRole === false) {
        var uniqueAuxRoles = [];
        $scope.filteredUsers.forEach(function(i) {
          var roles = i.auxiliaryRoles.split(",");
          roles.forEach(function(role) {
            if(uniqueAuxRoles.indexOf(role) === -1) {
              uniqueAuxRoles.push(role);
            }
          });
        });
        $scope.createGenericColumnFilterValues(uniqueAuxRoles.sort(), $scope.auxRolesData, $scope.auxRoleColumnIdMap);
      };

      if($scope.columnFilterModified.team === false) {
        $scope.createGenericColumnFilterValues(
          $scope.getGenericFieldValues($scope.filteredUsers, 'teamAssociation'), 
          $scope.teamsData, 
          $scope.teamColumnIdMap);
      }
    };

    /* Column Filter section - End */

    $scope.getUserName = function(userId) {
      var userName;
      if(userId !== undefined) {
        $sessionStorage.users.some(function(user) {
          if(user.userId.toUpperCase() === userId.toUpperCase()) 
            userName = user.userName;
        });
      }

      return userName;
    };

    $scope.checkSaveRevertValidity = function() {
      // Looping through users to find out if user has been updated, if so enable Revert and Save buttons.
      var enable = false;
      $scope.users.forEach(function(user) {
        if(user.action === 'U' || user.action === 'I') {
          enable = true;
        };
      });

      return enable;
    }; 

    $scope.isActiveToggle = function(i) {
      // "some" returns true as soon as any of the callbacks, executed in array order, return true, short-circuiting the execution of the rest.
      $scope.users.some(function(user) {
        if(user.id === i.id) {
          user.action = 'U';
        };
      });    
    };    

    $scope.activeFilter = function (user) {
        switch($scope.activeButtonStatus) {
          case 'disable': 
            return user;
          case 'off':
            return user.isActive == false;
          case 'on':
            return user.isActive == true;
        }
    }; 

    $scope.dirtyRecordFilter = function(user) {
      switch($scope.showDirtyRecordsOnly) {
          case 'off':
            return user;
          case 'on':
            return (user.action === 'U' || user.action === 'I');
        }

    };

    $scope.editRolesOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/admin/displayRolesModal.html',
        controller: 'EditRolesModalController',
        size: 'sm',
        resolve: {
          currentUser: function(){ return i;}
        }
      });
    };    

    $scope.editUserOpen = function(i) {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/admin/editUserModal.html',
        controller: 'EditUserModalController',
        resolve: {
          editUser: function(){ return i;},
          users: function() { return $scope.users;},
          userRoles: function() {return $scope.userRoles;},
          auxiliaryRoles: function() {return $scope.auxiliaryRoles;},
          teamAssociations: function() {return $scope.teamAssociations;}
        }
      });
    };    

    $scope.addUserOpen = function() {
      var modalInstance = $uibModal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'html/admin/addUserModal.html',
        controller: 'AddUserModalController',
        resolve: {
          users: function() { return $scope.users;},
          userRoles: function() {return $scope.userRoles;},
          auxiliaryRoles: function() {return $scope.auxiliaryRoles;},
          teamAssociations: function() {return $scope.teamAssociations;}
        }
      });
    };    

    $scope.revertUsers= function() {
      console.log("Reverting users back to original copy from server.")
      $scope.retrieveAllUsers();
    };

    $scope.retrieveAllUsers = function() {
      $scope.showUsersSpinner = true;
      userService.getUsers()
        .then(
          function(response) {
            $scope.users = response.data;
            $scope.createColumnTableFilter();
            $scope.showUsersSpinner = false;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );

      lookupService.retrieveReferences()
        .then(
          function(response) {
            $scope.userRoles = response.userRoles;
            $scope.auxiliaryRoles = response.auxiliaryRoles;
            $scope.teamAssociations =response.teamAssociations;
          },
          function(response) {
            alert( "failure message: " + JSON.stringify({data: response.data}));
          }
        );  
    };        

    $scope.updateUsers = function() {

      userService.postUsers($scope.users)
              .then(
                function(response) {

                  // Setting the Alert params
                  $scope.showSuccessAlert = true;
                  $scope.users.forEach(function(user) {
                    if(user.action === 'U' || user.action === 'I') 
                      $scope.savedUsers++;
                  });
                  
                  $scope.retrieveAllUsers();
                },
                function(response) {
                  alert( "failure message: " + JSON.stringify({data: response.data}));
                }
              );
     }; 

    $scope.retrieveAllUsers();
 
    
}]);