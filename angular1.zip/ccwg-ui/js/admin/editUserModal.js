ccwgApp.controller('EditUserModalController', ['$scope', '$uibModalInstance', 'editUser', 'users', 'userRoles', 'auxiliaryRoles', 'teamAssociations',
        function($scope, $uibModalInstance, editUser, users, userRoles, auxiliaryRoles, teamAssociations) {

  $scope.userRoles = userRoles;
  $scope.userRolesExist = true;

  $scope.auxiliaryRoles = auxiliaryRoles;
  $scope.teamAssociations = teamAssociations;

  $scope.userId = editUser.userId;
  $scope.selectedRolesList = editUser.userRoles.split(",");
  $scope.selectedAuxiliaryRolesList = editUser.auxiliaryRoles != null ? editUser.auxiliaryRoles.split(",") : [];

  $scope.userName = editUser.userName;
  $scope.email = editUser.email;
  $scope.description = editUser.description;
  $scope.teamAssociation = editUser.teamAssociation;
  
  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  // This method is called when User roles are selected on the modal
  $scope.selectedUserRoles = function(data) {
    $scope.selectedRolesList = data;
    if($scope.selectedRolesList.length === 0) {
      $scope.safeApply(function() {
        $scope.userRolesExist = false;
      });
      
    } else {
      $scope.safeApply(function() {
        $scope.userRolesExist = true;
      });
    }
  };

  $scope.selectedAuxiliaryRoles = function(data) {
    $scope.selectedAuxiliaryRolesList = data;
  }

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addUser = function() {
    users.some(function(user) {
      if(user.id == editUser.id) {
        user.userRoles = $scope.selectedRolesList.toString();
        user.auxiliaryRoles = $scope.selectedAuxiliaryRolesList.toString();
        user.userName = $scope.userName;
        user.email = $scope.email;
        user.description = $scope.description;
        user.teamAssociation = $scope.teamAssociation;
        user.action = 'U';
      };
    });

    $uibModalInstance.close();
  };    
}]);

ccwgApp.controller('AddUserModalController', ['$scope', '$uibModalInstance', 'users', 'userRoles', 'auxiliaryRoles', 'teamAssociations',  
  function($scope, $uibModalInstance, users, userRoles, auxiliaryRoles, teamAssociations) {

  $scope.userRoles = userRoles;
  $scope.userRolesExist = true;

  $scope.auxiliaryRoles = auxiliaryRoles;
  $scope.teamAssociations = teamAssociations;

  $scope.selectedRolesList = ['ReadOnly'];
  $scope.selectedAuxiliaryRolesList = [];

  $scope.userId;
  $scope.userName;
  $scope.email;
  $scope.description;
  $scope.teamAssociation;
 
  $scope.safeApply = function(fn) {
    var phase = this.$root.$$phase;
    if(phase == '$apply' || phase == '$digest') {
      if(fn && (typeof(fn) === 'function')) {
        fn();
      }
    } else {
      this.$apply(fn);
    }
  };

  // This method is called when User roles are selected on the modal
  $scope.selectedUserRoles = function(data) {
    $scope.selectedRolesList = data;
    if($scope.selectedRolesList.length === 0) {
      $scope.safeApply(function() {
        $scope.userRolesExist = false;
      });
      
    } else {
      $scope.safeApply(function() {
        $scope.userRolesExist = true;
      });
    }
  };

  $scope.selectedAuxiliaryRoles = function(data) {
    $scope.selectedAuxiliaryRolesList = data;
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };

  $scope.addUser = function() {
    users.push({
      "userId": $scope.userId,
      "userName": $scope.userName, 
      "userRoles": $scope.selectedRolesList.toString(),
      "auxiliaryRoles": $scope.selectedAuxiliaryRolesList.toString(),
      "email": $scope.email,
      "description": $scope.description,
      "teamAssociation": $scope.teamAssociation,
      "action": 'I',
      "isActive": true
    });

    $uibModalInstance.close();
  };
    
}]);

ccwgApp.controller('EditRolesModalController', ['$scope', '$uibModalInstance', 'currentUser',  function($scope, $uibModalInstance, currentUser) {

  $scope.user = currentUser;
  $scope.roles = currentUser.userRoles.split(",");

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
}]);