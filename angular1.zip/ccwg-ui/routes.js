// ROUTES
ccwgApp.config(function ($routeProvider) {
	$routeProvider

	.when('/', {
		templateUrl: 'html/dashboard/dashboard.html',
		controller: 'dashboardController'
	})

	.when('/roleList', {
		templateUrl: 'html/roles/roleList.html',
		controller: 'RoleListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/awsServiceManagement', {
		templateUrl: 'html/services/serviceList.html',
		controller: 'ServiceListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/awsBulkUploadServices', {
		templateUrl: 'html/services/bulkUploadServices.html',
		controller: 'ServiceBulkUploadController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/awsBulkUploadServiceApiActions', {
		templateUrl: 'html/serviceApiActions/bulkUploadServiceApiActions.html',
		controller: 'ServiceApiActionBulkUploadController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/awsServiceEvaluations/:serviceId', {
		templateUrl: 'html/serviceEvaluations/serviceEvaluation.html',
		controller: 'ServiceEvaluationController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/awsServiceApiActions/:serviceId', {
		templateUrl: 'html/serviceApiActions/serviceApiAction.html',
		controller: 'ServiceApiActionController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})	

	.when('/awsPrivilegeList', {
		templateUrl: 'html/privileges/privilegesList.html',
		controller: 'PrivilegeListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})	

	.when('/awsPrivilegeApprovals', {
		templateUrl: 'html/privilegeReviews/privilegeReviewsList.html',
		controller: 'PrivilegeReviewsListController',
		requiresAuthentication: true,
        permissions: ["Approver"]
	})	

	.when('/bulkPrivilegeReviewList/:requestTitle', {
		templateUrl: 'html/privilegeReviews/bulkPrivilegeReviewsList.html',
		controller: 'BulkPrivilegeReviewsListController',
		requiresAuthentication: true,
        permissions: ["Approver"]
	})	

	.when('/awsPrivilegeApprovalFinalizing', {
		templateUrl: 'html/privilegeReviews/privilegeApprovalsList.html',
		controller: 'PrivilegeApprovalsListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/bulkPrivilegeApprovalList/:requestTitle', {
		templateUrl: 'html/privilegeReviews/bulkPrivilegeApprovalsList.html',
		controller: 'BulkPrivilegeApprovalsListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})	

	.when('/awsPrivilegeApprovalFinalizingHistory', {
		templateUrl: 'html/privilegeReviews/privilegeApprovalsHistoryList.html',
		controller: 'PrivilegeApprovalsHistoryListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/bulkPrivilegeApprovalListHistory/:requestTitle', {
		templateUrl: 'html/privilegeReviews/bulkPrivilegeApprovalsHistoryList.html',
		controller: 'BulkPrivilegeApprovalsHistoryListController',
		requiresAuthentication: true,
        permissions: ["ConfigurationManager", "Approver", "Admin", "ReadOnly"]
	})

	.when('/awsBulkUploadPrivileges', {
		templateUrl: 'html/privileges/privilegesBulkUpload.html',
		controller: 'PrivilegeBulkUploadController',
		requiresAuthentication: true,
        permissions: ["Admin", "ConfigurationManager"]
	})				

	.when('/userManagement', {
		templateUrl: 'html/admin/userList.html',
		controller: 'UserListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/tagList', {
		templateUrl: 'html/tags/tagList.html',
		controller: 'TagListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/awsAccountList', {
		templateUrl: 'html/accounts/awsAccountList.html',
		controller: 'AwsAccountListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})	

	.when('/iamPolicyMgmt', {
		templateUrl: 'html/iamPolicy/iamPolicyMgmt.html',
		controller: 'IamPolicyMgmtController',
		requiresAuthentication: true,
        permissions: ["IAMAdmin"]
	})	

	.when('/iamPolicySmltr', {
		templateUrl: 'html/iamPolicy/iamPolicySmltr.html',
		controller: 'IamPolicySmltrController',
		requiresAuthentication: true,
        permissions: ["IAMAdmin"]
	})	

	.when('/announcementList', {
		templateUrl: 'html/announcements/announcementList.html',
		controller: 'AnnouncementListController',
		requiresAuthentication: true,
        permissions: ["NewsModerator", "Admin"]
	})

	.when('/announcementEventList', {
		templateUrl: 'html/announcements/announcementEventList.html',
		controller: 'AnnouncementEventListController',
		requiresAuthentication: true,
        permissions: ["Admin"]
	})

	.when('/privError', {
		templateUrl: 'html/error/privError.html',
		controller: 'PrivErrorController'
	})	

	.when('/error', {
		templateUrl: 'html/error/error.html',
		controller: 'GenericErrorController',
		resolve: {
			errorJson: function(httpInterceptor) {
				return httpInterceptor.getErrorJson();
			}
		}
	})	

});

ccwgApp.config(['$httpProvider', function($httpProvider) {
	//$httpProvider.defaults.useXDomain = true;
    //delete $httpProvider.defaults.headers.common['X-Requested-With'];

    //console.log('Http Prov', $httpProvider );

	if (!$httpProvider.defaults.headers.get) {
	    $httpProvider.defaults.headers.get = {};
	}
	//disable IE ajax request caching
	//$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';      
  	//$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
  	//$httpProvider.defaults.headers.get.Pragma = 'no-cache';
  	
  	$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache, no-store, must-revalidate';
	$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	$httpProvider.defaults.headers.get['Expires'] = '0';   



	$httpProvider.interceptors.push('httpInterceptor');

}]);

ccwgApp.config(function(envServiceProvider) {
	// set the domains and variables for each environment
	envServiceProvider.config({
		domains: {
			local: ['local'],
			development: ['dev'],
			qc: ['qc'],
			production: ['prod']

		},
		vars: {
			local: {
				lookupUrl: 'http://localhost:9000/ccwg/lookups',
				roleUrl: 'http://localhost:9000/ccwg/roles',
				
				serviceUrl: 'http://localhost:9000/ccwg/services',
				serviceBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/upload/services',
				serviceBulkUploadFileInfoUrl: 'http://localhost:9000/ccwg/fileservice/serviceBulkUploadFilesInfo',
				serviceBulkUploadFilesDownloadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/serviceBulkUploadFiles',
				serviceSampleBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/serviceBulkSampleFile',
				
				serviceApiActionUrl: 'http://localhost:9000/ccwg/serviceApiActions',
				serviceApiActionBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/upload/serviceApiActions',
				serviceApiActionBulkUploadFileInfoUrl: 'http://localhost:9000/ccwg/fileservice/apiActionBulkUploadFilesInfo',
				serviceApiActionBulkUploadFilesDownloadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/apiActionBulkUploadFiles',
				serviceApiActionSampleBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/apiActionBulkSampleFile',
				
				privilegeUrl: 'http://localhost:9000/ccwg/privileges',
				privilegeCountUrl: 'http://localhost:9000/ccwg/privileges/count',
				userUrl: 'http://localhost:9000/ccwg/users',
				healthCheckUrl: 'http://localhost:9000/ccwg/health',
				privilegeReviewUrl: 'http://localhost:9000/ccwg/privilegeReviews',
				privilegeApprovalUrl: 'http://localhost:9000/ccwg/privilegeReviews/approvals',
				privilegeBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/upload/privileges',
				privilegeSampleBulkUploadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/privilegeBulkSampleFile',
				privilegeBulkUploadFileInfoUrl: 'http://localhost:9000/ccwg/fileservice/privBulkUploadFilesInfo',
				privilegeBulkUploadFilesDownloadUrl: 'http://localhost:9000/ccwg/fileservice/downloads/privilegeBulkUploadFiles',

				exportPrivilegeConfigUrl: 'http://localhost:9000/ccwg/fileservice/downloads/exportPrivileges',

				tagUrl: 'http://localhost:9000/ccwg/tags',
				tagDashboardUrl: 'http://localhost:9000/ccwg/tags/dashboard',

				awsAccountUrl: 'http://localhost:9000/ccwg/awsAccounts',

				announcementUrl: 'http://localhost:9000/ccwg/announcements',
				announcementEventUrl: 'http://localhost:9000/ccwg/announcementEvents',
				
				helpUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737',
				releaseNotesUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737#CloudCompliancePortal(CCP)-ReleaseHistory(akaReleased)',
				splunkDashboardUrl: 'https://splunk.finra.org/en-US/app/AWS_Compliance/AwsComplianceMain',

				dashboardServiceInfoUrl: 'http://localhost:9000/ccwg/dashboard/serviceInfo',
				dashboardApiActionInfoUrl: 'http://localhost:9000/ccwg/dashboard/apiActionInfo',
				dashboardRolesInfoUrl: 'http://localhost:9000/ccwg/dashboard/roleInfo',
				dashboardPrivilegeInfoUrl: 'http://localhost:9000/ccwg/dashboard/privilegeInfo',
				dashboardPrivilegeRequestSummaryUrl: 'http://localhost:9000/ccwg/dashboard/privilegeRequestSummary',
				dashboardAnnouncementsUrl: 'http://localhost:9000/ccwg/dashboard/announcements',
				iamPolicyUrl: 'http://localhost:9000/ccwg/iamPolicy',
				iamPolicyWorkingCopyUrl: 'http://localhost:9000/ccwg/iamPolicyWorkingCopy',

				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10,
				alertTimeout: 8000,
				privilegeReviewMaxPageSize: 3000


			},
			development: {
				lookupUrl: 'https://appsec.dev.finra.org/ccwg-1.0/lookups',
				roleUrl: 'https://appsec.dev.finra.org/ccwg-1.0/roles',
				
				serviceUrl: 'https://appsec.dev.finra.org/ccwg-1.0/services',
				serviceBulkUploadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/upload/services',
				serviceBulkUploadFileInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/serviceBulkUploadFilesInfo',								
				serviceBulkUploadFilesDownloadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkUploadFiles',
				serviceSampleBulkUploadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkSampleFile',
				
				serviceApiActionUrl: 'https://appsec.dev.finra.org/ccwg-1.0/serviceApiActions',
				serviceApiActionBulkUploadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/upload/serviceApiActions',
				serviceApiActionBulkUploadFileInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/apiActionBulkUploadFilesInfo',
				serviceApiActionBulkUploadFilesDownloadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkUploadFiles',
				serviceApiActionSampleBulkUploadUrl: 'https:/appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkSampleFile',
				
				privilegeUrl: 'https://appsec.dev.finra.org/ccwg-1.0/privileges',
				privilegeCountUrl: 'https://appsec.dev.finra.org/ccwg-1.0/privileges/count',
				userUrl: 'https://appsec.dev.finra.org/ccwg-1.0/users',
				healthCheckUrl: 'https://appsec.dev.finra.org/ccwg-1.0/health',
				privilegeReviewUrl: 'https://appsec.dev.finra.org/ccwg-1.0/privilegeReviews',
				privilegeApprovalUrl: 'https://appsec.dev.finra.org/ccwg-1.0/privilegeReviews/approvals',
				privilegeBulkUploadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/upload/privileges',
				privilegeSampleBulkUploadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkSampleFile',
				privilegeBulkUploadFileInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/privBulkUploadFilesInfo',
				privilegeBulkUploadFilesDownloadUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkUploadFiles',

				exportPrivilegeConfigUrl: 'https://appsec.dev.finra.org/ccwg-1.0/fileservice/downloads/exportPrivileges',

				tagUrl: 'https://appsec.dev.finra.org/ccwg-1.0/tags',
				tagDashboardUrl: 'https://appsec.dev.finra.org/ccwg-1.0/tags/dashboard',

				awsAccountUrl: 'https://appsec.dev.finra.org/ccwg-1.0/awsAccounts',

				announcementUrl: 'https://appsec.dev.finra.org/ccwg-1.0/announcements',
				announcementEventUrl: 'https://appsec.dev.finra.org/ccwg-1.0/announcementEvents',

				helpUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737',
				releaseNotesUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737#CloudCompliancePortal(CCP)-ReleaseHistory(akaReleased)',
				splunkDashboardUrl: 'https://splunk.finra.org/en-US/app/AWS_Compliance/AwsComplianceMain',

				dashboardServiceInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/serviceInfo',
				dashboardApiActionInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/apiActionInfo',
				dashboardRolesInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/roleInfo',
				dashboardPrivilegeInfoUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/privilegeInfo',
				dashboardPrivilegeRequestSummaryUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/privilegeRequestSummary',
				dashboardAnnouncementsUrl: 'https://appsec.dev.finra.org/ccwg-1.0/dashboard/announcements',

				iamPolicyUrl: 'https://appsec.dev.finra.org/ccwg-1.0/iamPolicy',
				iamPolicyWorkingCopyUrl: 'https://appsec.dev.finra.org/ccwg-1.0/iamPolicyWorkingCopy',

				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10,
				alertTimeout: 8000,
				privilegeReviewMaxPageSize: 3000

			},
			qc: {
				lookupUrl: 'https://appsec.qa.finra.org/ccwg-1.0/lookups',
				roleUrl: 'https://appsec.qa.finra.org/ccwg-1.0/roles',
				
				serviceUrl: 'https://appsec.qa.finra.org/ccwg-1.0/services',
				serviceBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/upload/services',
				serviceBulkUploadFileInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/serviceBulkUploadFilesInfo',		
				serviceBulkUploadFilesDownloadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkUploadFiles',							
				serviceSampleBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkSampleFile',
				
				serviceApiActionUrl: 'https://appsec.qa.finra.org/ccwg-1.0/serviceApiActions',
				serviceApiActionBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/upload/serviceApiActions',
				serviceApiActionBulkUploadFileInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/apiActionBulkUploadFilesInfo',
				serviceApiActionBulkUploadFilesDownloadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkUploadFiles',
				serviceApiActionSampleBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkSampleFile',
				
				privilegeUrl: 'https://appsec.qa.finra.org/ccwg-1.0/privileges',
				privilegeCountUrl: 'https://appsec.qa.finra.org/ccwg-1.0/privileges/count',
				userUrl: 'https://appsec.qa.finra.org/ccwg-1.0/users',
				healthCheckUrl: 'https://appsec.qa.finra.org/ccwg-1.0/health',
				privilegeReviewUrl: 'https://appsec.qa.finra.org/ccwg-1.0/privilegeReviews',
				privilegeApprovalUrl: 'https://appsec.qa.finra.org/ccwg-1.0/privilegeReviews/approvals',
				privilegeBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/upload/privileges',
				privilegeSampleBulkUploadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkSampleFile',
				privilegeBulkUploadFileInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/privBulkUploadFilesInfo',
				privilegeBulkUploadFilesDownloadUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkUploadFiles',
				
				exportPrivilegeConfigUrl: 'https://appsec.qa.finra.org/ccwg-1.0/fileservice/downloads/exportPrivileges',

				tagUrl: 'https://appsec.qa.finra.org/ccwg-1.0/tags',
				tagDashboardUrl: 'https://appsec.qa.finra.org/ccwg-1.0/tags/dashboard',

				awsAccountUrl: 'https://appsec.qa.finra.org/ccwg-1.0/awsAccounts',

				announcementUrl: 'https://appsec.qa.finra.org/ccwg-1.0/announcements',
				announcementEventUrl: 'https://appsec.qa.finra.org/ccwg-1.0/announcementEvents',

				helpUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737',
				releaseNotesUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737#CloudCompliancePortal(CCP)-ReleaseHistory(akaReleased)',
				splunkDashboardUrl: 'https://splunk.finra.org/en-US/app/AWS_Compliance/AwsComplianceMain',

				dashboardServiceInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/serviceInfo',
				dashboardApiActionInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/apiActionInfo',
				dashboardRolesInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/roleInfo',
				dashboardPrivilegeInfoUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/privilegeInfo',
				dashboardPrivilegeRequestSummaryUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/privilegeRequestSummary',
				dashboardAnnouncementsUrl: 'https://appsec.qa.finra.org/ccwg-1.0/dashboard/announcements',

				iamPolicyUrl: 'https://appsec.qa.finra.org/ccwg-1.0/iamPolicy',
				iamPolicyWorkingCopyUrl: 'https://appsec.qa.finra.org/ccwg-1.0/iamPolicyWorkingCopy',

				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10,
				alertTimeout: 8000,
				privilegeReviewMaxPageSize: 3000

			},
			production: {
				lookupUrl: 'https://appsec.finra.org/ccwg-1.0/lookups',
				roleUrl: 'https://appsec.finra.org/ccwg-1.0/roles',
				
				serviceUrl: 'https://appsec.finra.org/ccwg-1.0/services',
				serviceBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/upload/services',
				serviceBulkUploadFileInfoUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/serviceBulkUploadFilesInfo',
				serviceBulkUploadFilesDownloadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkUploadFiles',
				serviceSampleBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/serviceBulkSampleFile',
				
				serviceApiActionUrl: 'https://appsec.finra.org/ccwg-1.0/serviceApiActions',
				serviceApiActionBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/upload/serviceApiActions',
				serviceApiActionBulkUploadFileInfoUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/apiActionBulkUploadFilesInfo',
				serviceApiActionBulkUploadFilesDownloadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkUploadFiles',
				serviceApiActionSampleBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/apiActionBulkSampleFile',
				
				privilegeUrl: 'https://appsec.finra.org/ccwg-1.0/privileges',
				privilegeCountUrl: 'https://appsec.finra.org/ccwg-1.0/privileges/count',
				userUrl: 'https://appsec.finra.org/ccwg-1.0/users',
				healthCheckUrl: 'https://appsec.finra.org/ccwg-1.0/health',
				privilegeReviewUrl: 'https://appsec.finra.org/ccwg-1.0/privilegeReviews',
				privilegeApprovalUrl: 'https://appsec.finra.org/ccwg-1.0/privilegeReviews/approvals',
				privilegeBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/upload/privileges',
				privilegeSampleBulkUploadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkSampleFile',
				privilegeBulkUploadFileInfoUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/privBulkUploadFilesInfo',
				privilegeBulkUploadFilesDownloadUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/privilegeBulkUploadFiles',
				
				exportPrivilegeConfigUrl: 'https://appsec.finra.org/ccwg-1.0/fileservice/downloads/exportPrivileges',

				tagUrl: 'https://appsec.finra.org/ccwg-1.0/tags',
				tagDashboardUrl: 'https://appsec.finra.org/ccwg-1.0/tags/dashboard',

				awsAccountUrl: 'https://appsec.finra.org/ccwg-1.0/awsAccounts',

				announcementUrl: 'https://appsec.finra.org/ccwg-1.0/announcements',
				announcementEventUrl: 'https://appsec.finra.org/ccwg-1.0/announcementEvents',

				helpUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737',
				releaseNotesUrl: 'https://wiki.finra.org/confluence/pages/viewpage.action?pageId=949158737#CloudCompliancePortal(CCP)-ReleaseHistory(akaReleased)',
				splunkDashboardUrl: 'https://splunk.finra.org/en-US/app/AWS_Compliance/AwsComplianceMain',

				dashboardServiceInfoUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/serviceInfo',
				dashboardApiActionInfoUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/apiActionInfo',
				dashboardRolesInfoUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/roleInfo',
				dashboardPrivilegeInfoUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/privilegeInfo',
				dashboardPrivilegeRequestSummaryUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/privilegeRequestSummary',
				dashboardAnnouncementsUrl: 'https://appsec.finra.org/ccwg-1.0/dashboard/announcements',

				iamPolicyUrl: 'https://appsec.finra.org/ccwg-1.0/iamPolicy',
				iamPolicyWorkingCopyUrl: 'https://appsec.finra.org/ccwg-1.0/iamPolicyWorkingCopy',

				currentPage: 1,
				itemsPerPage: 10,
				maxSize: 10,
				alertTimeout: 8000,
				privilegeReviewMaxPageSize: 3000

			}

		}
	});

	envServiceProvider.check();
});

ccwgApp.run(['$rootScope', '$location', 'authService', 'roleService', 'serviceRest', 'envService', '$http', '$sessionStorage',
	function ($rootScope, $location, authService, roleService, serviceRest, envService, $http, $sessionStorage) {
	
	envService.set('local');

	authService.init();

    // Create a local storage of all the user's and their names
    $http({
        method: 'GET',
        url: envService.read('userUrl')
    }).then(
        function(response) {
          var userEntities = response.data;
          var userIds = [];
          $sessionStorage.users = [];

          var getFirstUserName = function(userId) {
            var userName;
            userEntities.some(function(userEntity) {
              if(userEntity.userId === userId)
                userName = userEntity.userName;                
            });

            return userName;
          };

          // Get unique list of userIds
          userEntities.forEach(function(userEntity) {
            if(userIds.indexOf(userEntity.userId) === -1) {
              userIds.push(userEntity.userId);
            }
          });

          // Create map of unique userId and userName
          userIds.forEach(function(userId) {
            
            $sessionStorage.users.push({
              userId:  userId,
              userName: getFirstUserName(userId)
            });
          });

          console.log("Complete Users Loadging......");
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }       

    );
	

    // Retrieve role entities which can be used later to create privileges 
    roleService.getRoles()
      .then(
        function(response) {
          $rootScope.roleEntities = response.data;
        },
        function(response) {
          alert( "failure message: " + JSON.stringify({data: response.data}));
        }
      );
}]);