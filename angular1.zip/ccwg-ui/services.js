ccwgApp.factory('httpInterceptor', ['$q', '$location', '$sessionStorage', function($q, $location, $sessionStorage) {
  var errorJson;
  return {
    'response': function (response) {
      //console.log('Response Object:', response);

      // From the response select the Auxiliary Roles which figure out if we need to display Announcement Section.      
      if(response.headers('X-CCWG-AUX-ROLES') && $sessionStorage.user) {
         var auxiliaryRoles = $.map(response.headers('X-CCWG-AUX-ROLES').slice(1, -1).split(","), $.trim); // Remove first and last character and split ','
          // To remove the length 1 empty element, which get's generated when we use split on an empty js array.
          var filteredRoles = [];

          auxiliaryRoles.forEach(function(role) {
            if(role.trim() != '') {
              filteredRoles.push(role);
            }
          });
          //auxiliaryRoles = auxiliaryRoles.filter(entry => entry.trim() != '');
          $sessionStorage.user.auxiliaryRoles = filteredRoles;
      };
      
      //console.log('Response Interceptor');      
      return response;
    },
    'request': function (config) {
      //console.log('Request Interceptor');
      config.headers['sAMAccountName'] = "K25850";
      //console.log('Request:', config);
      //console.log('Request Url:', config.url);
      return config;
    },
    'responseError': function(response) {
      console.log("Error Response Interceptor: ", response);

      // This is error during file processing, so lets get the json error response from blob
      if(response.config.responseType === 'arraybuffer') {
        // Decoding ArrayBuffer into a string and using JSON.parse()
        var decodedString = String.fromCharCode.apply(null, new Uint8Array(response.data));
        errorJson = JSON.parse(decodedString);;
      } else {
        errorJson = response.data;
      };      

      // Response status is set to -1 in angularjs if request timesout
      // During refresh of a page multiple times, all requests will time out and as a result the error page was being displayed
      // hack in place to direct to error.html only if its a legit error and not a timeout.
      // A sideeffect of this would be if the server is down, then response status = -1 and it get's treated as a timeout as well.
      if(response.status <= 0) {
        console.log('Request timedout!!');
      } else {
        $location.path('/error');
      }      
        
      return response;
    },
    'getErrorJson': function() {
      return errorJson;
    }
  }
}]);